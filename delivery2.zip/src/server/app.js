const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const fs = require('fs');
const app = express();
const YAML = require('yaml');
//joining path of directory 
// const directoryPath = path.join(__dirname, 'media');
//to handle JSON payloads
app.use(bodyParser.json());
/*
    Create a new file and dumping the yaml data into that file.
    and then returning the file path to the client.
 */
app.post('/api/createData', (req, res) => {
    function getDateString() {
        const date = new Date();
        const year = date.getFullYear();
        const month = `${date.getMonth() + 1}`.padStart(2, '0');
        const day = `${date.getDate()}`.padStart(2, '0');
        return `${year}${month}${day}`
    }
    let name = Math.random().toString(36).replace(/[^a-z]+/g, '').substr(0, 25) + getDateString()
    let dir = './media/' + name + '.yaml';
    const doc = new YAML.Document();
    doc.contents = req.body;
    // let yamlStr = yaml.safeDump(req.body);
    try {
        return new Promise(function (resolve, reject) {
            fs.writeFile(dir, doc.toString(), function (err) {
                if (err) reject(err);
                else resolve(dir);
            });
        }).then(data => {
            res.status(201).send(data)
        })
    } catch (err) {
        res.send(err);
    }

});
app.get("/api/getyamlfiles", (req, res) => {
    function createdDate(dir, file) {
        const { birthtime, size } = fs.statSync(dir + file)
        // console.log(fs.statSync(file))
        return {
            name: file, birthtime, size: size / 1000 + 'kb'
        }
    }
    let directoryPath = "./media/"
    //passsing directoryPath and callback function
    fs.readdir(directoryPath, function (err, files) {
        //handling error
        if (err) {
            return console.log('Unable to scan directory: ' + err);
        }
        let response = []
        //listing all files using forEach
        files.forEach(function (file) {
            // Do whatever you want to do with the file
            response.push(createdDate(directoryPath, file))
        });
        if (response.length > 0) {
            res.status(200).send(response)
        } else {
            res.status(300).send('no file found')
        }
    });
})

app.use(express.static('public'));

app.use((req, res, next) => {
    res.sendFile(path.resolve(__dirname, '..', '..', 'public', 'index.html'));
});


module.exports = app;