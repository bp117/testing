import React from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter, Switch, Route } from 'react-router-dom';
import 'react-tabs/style/react-tabs.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Container } from 'react-bootstrap';
import Home from './home';
import { Create } from './create';
import { Edit } from './edit';
import { NotFound } from './not_found';

import rootReducer from './store/reducers';
import { createStore } from 'redux';
import { Provider } from 'react-redux';
const store = createStore(
  rootReducer,
  window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__()
);

const App = () => {
  return (
    <BrowserRouter>
      <Container className='my-4'>
        <Switch>
          <Route exact path='/create' component={Create} />
          <Route exact path='/edit' component={Edit} />
          <Route exact path='/' component={Home} />
          <Route component={NotFound} />
        </Switch>
      </Container>
    </BrowserRouter>
  );
};

ReactDOM.render(
  <React.StrictMode>
    <Provider store={store}>
      <App />
    </Provider>
  </React.StrictMode>,
  document.getElementById('root')
);
