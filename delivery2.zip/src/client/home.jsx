import React from 'react';
import { Tab, Tabs, TabList, TabPanel } from 'react-tabs';
import BasicInfoTab from './Tabs/BasicInfoTab';
import TemplateInfoTab from './Tabs/templateInfoTab';
import NormalizationTab from './Tabs/normalizationTab';
import HistoryTab from './Tabs/history';
function App() {
  return (
    <Tabs>
      <TabList>
        <Tab>Basic Data</Tab>
        <Tab>Content Template</Tab>
        <Tab>Normalization</Tab>
        <Tab>History</Tab>
      </TabList>
      <TabPanel>
        <BasicInfoTab />
      </TabPanel>
      <TabPanel>
        <TemplateInfoTab />
      </TabPanel>
      <TabPanel>
        <NormalizationTab />
      </TabPanel>
      <TabPanel>
        <HistoryTab />
      </TabPanel>
    </Tabs>
  );
}
export default App;
