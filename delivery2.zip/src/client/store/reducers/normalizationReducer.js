const Normalization = (state = {
    // FieldName: '',
    // Order: ''
}, action) => {
    switch (action.type) {
        case "NormalizationDataChanged":
            console.log(state)
            console.log(action.payload)
            return { ...state, [action.payload.name]: action.payload.inputValue }
            break;
        default:
            return state
            break;
    }

}
export default Normalization