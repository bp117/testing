import BasicDataReducer from "./BasicDataReducer"
import TemplateDataReducer from "./TemplateDataReducer"
import NormalizationReducer from "./normalizationReducer"
import { combineReducers } from "redux"
const rootReducer = combineReducers({
    BasicDataReducer,
    TemplateDataReducer,
    NormalizationReducer
})
export default rootReducer;