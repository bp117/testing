const TemplateData = (state = {
    // TemplateID: "",
    // XSLTTemplateID: "",
    // EngFromAddressLabel: "",
    // EngCustomerSegment: "",
    // EngLanguage: "",
    // SpaFromAddressLabel: "",
    // SpaCustomerSegment: "",
}, action) => {
    switch (action.type) {
        case "TemplateDataChanged":
            console.log(state)
            console.log(action.payload)
            return { ...state, [action.payload.name]: action.payload.inputValue }
            break;
        default:
            return state
            break;
    }

}
export default TemplateData