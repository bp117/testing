const BasicData = (state = {
    // MessageTypeID: '',
    // SLATargetPercent: '',
    // importanceFlag: '',
}, action) => {
    switch (action.type) {
        case "BasicDataChanged":
            console.log(state)
            console.log(action.payload)
            return { ...state, [action.payload.name]: action.payload.inputValue }
            break;
        default:
            return state
            break;
    }

}
export default BasicData