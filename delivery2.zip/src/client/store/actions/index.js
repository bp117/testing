export const BasicDataChanged = (inputValue) => {
    return {
        type: 'BasicDataChanged',
        payload: inputValue
    }
}

export const TemplateDataChanged = (inputValue) => {
    return {
        type: 'TemplateDataChanged',
        payload: inputValue
    }
}
export const NormalizationDataChanged = (inputValue) => {
    return {
        type: 'NormalizationDataChanged',
        payload: inputValue
    }
}
export const historyfromAPI = (history) => {
    return {
        type: 'GOTHISTORYFROMAPI',
        payload: inputValue
    }
}
