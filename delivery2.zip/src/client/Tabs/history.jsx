import React, { useState, useEffect } from 'react';
import { Table, Row, Col, Button } from 'react-bootstrap';
// import { NormalizationDataChanged } from '../store/actions';
import { useSelector, useDispatch } from 'react-redux';
function NormalizationTab() {
  const [history, setHistory] = useState({});
  const dispatch = useDispatch();
  //   const stateData = useSelector((state) => state);
  useEffect(() => {
    async function fetchMyAPI() {
      let response = await fetch('api/getyamlfiles');
      response = await response.json();
      setHistory(response);
    }

    fetchMyAPI();
  }, []);
  return (
    <Row className='text-center'>
      <Col>
        <Table striped bordered hover size='sm'>
          <thead>
            <tr>
              <th>#</th>
              <th>File Name</th>
              <th>Created At</th>
              <th>Size</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {history.length > 0 ? (
              history.map((item, index) => {
                return (
                  <tr key={index}>
                    <td>{index + 1}</td>
                    <td>{item.name}</td>
                    <td>{item.birthtime}</td>
                    <td>{item.size}</td>
                    <td>
                      <Button variant='primary'>Load</Button>{' '}
                    </td>
                  </tr>
                );
              })
            ) : (
              <tr></tr>
            )}
          </tbody>
        </Table>
      </Col>
    </Row>
  );
}
export default NormalizationTab;
