import React from 'react';
import SignIn from '../../@jumbo/components/Common/authComponents/SignIn';

const Login = () => <SignIn variant="standard" wrapperVariant="bgColor" />;

export default Login;
