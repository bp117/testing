import React from 'react';
import SignUp from '../../@jumbo/components/Common/authComponents/SignUp';

const Register = () => <SignUp variant="standard" wrapperVariant="bgColor" />;

export default Register;
