package com.kafka.utility;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkaSearchApplicationTests {

	@Test
	void contextLoads() {
	}

}
