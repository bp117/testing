---
name: Enhancement Requests
about: Use this for enhancement requests
title: ''
labels: enhancement
assignees: ''

---

<!--

Thank you for using node-oracledb.

Review existing enhancement requests: https://github.com/oracle/node-oracledb/labels/enhancement

Please answer these questions so we can help you.

Use Markdown syntax, see https://help.github.com/github/writing-on-github/basic-writing-and-formatting-syntax

-->

1. Describe your new request in detail

2. Give supporting information about tools and operating systems.  Give relevant product version numbers
