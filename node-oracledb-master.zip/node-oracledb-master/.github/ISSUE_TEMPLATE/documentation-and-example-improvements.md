---
name: Documentation and Example Improvements
about: Use this to suggest changes to documentation and examples
title: ''
labels: enhancement
assignees: ''

---

<!--

Thank you for using node-oracledb.

Please answer these questions so we can help you.

Use Markdown syntax, see https://help.github.com/github/writing-on-github/basic-writing-and-formatting-syntax

-->


1. What is the link to the documentation section that needs improving?

2. Describe the confusion

3. Suggest changes that would help
