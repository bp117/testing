import React, { useState } from 'react';
import { Form, Row, Col, Button } from 'react-bootstrap';
import { NormalizationDataChanged } from '../store/actions';
import { useSelector, useDispatch } from 'react-redux';
function NormalizationTab() {
  const Rstate = useSelector((state) => state.Normalization);
  const dispatch = useDispatch();
  const [FieldName, setFieldName] = useState(Rstate.FieldName);
  const [Order, setOrder] = useState(Rstate.Order);
  const stateData = useSelector((state) => state);
  const [Edited, setEdited] = useState(stateData.History.Edited);
  const Submit = (e) => {
    e.preventDefault();
    const url = Edited ? '/api/updateData' : '/api/createData';
    try {
      response = fetch(url, {
        method: Edited ? 'put' : 'post',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(stateData),
      });
    } catch (err) {
      return false;
    }
  };
  return (
    <Form>
      <Row className='text-center'>
        <Col sm={12} md={5}>
          <Form.Group controlId='exampleForm.ControlInput1'>
            <Form.Label>Field Name</Form.Label>
            <Form.Control
              name='FieldName'
              onChange={(e) => {
                setFieldName(e.target.value);
                dispatch(
                  NormalizationDataChanged({
                    inputValue: e.target.value,
                    name: e.target.name,
                  })
                );
              }}
              value={FieldName}
              placeholder='Field Name'
            />
          </Form.Group>
        </Col>
        <Col sm={12} md={5}>
          <Form.Group controlId='exampleForm.ControlInput1'>
            <Form.Label>Order</Form.Label>
            <Form.Control
              name='Order'
              onChange={(e) => {
                setOrder(e.target.value);
                dispatch(
                  NormalizationDataChanged({
                    inputValue: e.target.value,
                    name: e.target.name,
                  })
                );
              }}
              value={Order}
              placeholder='Order ID'
            />
          </Form.Group>
        </Col>
        <Col className='mt-2 pt-4'>
          <Button variant='primary'>+</Button> <Button variant='info'>-</Button>{' '}
        </Col>
      </Row>
      <Row className='text-center'>
        <Col sm={12}>
          <Button onClick={Submit} variant='primary' type='submit'>
            Submit
          </Button>
        </Col>
      </Row>
    </Form>
  );
}
export default NormalizationTab;
