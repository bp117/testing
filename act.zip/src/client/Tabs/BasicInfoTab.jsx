import React, { useState, useEffect } from 'react';
import { Form, Row, Col } from 'react-bootstrap';
import { useSelector, useDispatch } from 'react-redux';
import { BasicDataChanged } from '../store/actions';
function BasicInfoTab() {
  const Rstate = useSelector((state) => state.BasicData);
  // useEffect(() => {
  //   console.log(Rstate);
  // });]

  const dispatch = useDispatch();
  const [MessageID, setMessageID] = useState(Rstate.MessageTypeID);
  const [SLATargetPercant, setSLATargetPercant] = useState(
    Rstate.SLATargetPercent
  );
  const [Importance, setImportance] = useState(Rstate.importanceFlag);
  const [MessageDescription, setMessageDescription] = useState(
    Rstate.MessageDescription
  );
  const [AlertsSLAMinuttes, setAlertsSLAMinuttes] = useState(
    Rstate.AlertsSLAMinuttes
  );
  const [Active, setActive] = useState(Rstate.ActiveFlag);
  const [SORApplicationID, setSORApplicationID] = useState(
    Rstate.SORApplicationID
  );
  const [MessageIdentifier, setMessageIdentifier] = useState(
    Rstate.MessageIdentifier
  );
  const [ImplicitsubFlag, setImplicitsubFlag] = useState(
    Rstate.ImplicitsubFlag
  );
  const [CreatorDate, setCreatorDate] = useState(Rstate.CreatorDate);
  const [MessageTypeSubcode, setMessageTypeSubcode] = useState(
    Rstate.MessageTypeSubcode
  );
  const [BrandingRequiredFlag, setBrandingRequiredFlag] = useState(
    Rstate.BrandingRequiredFlag
  );
  return (
    <Form>
      <Row>
        <Col>
          <Form.Group controlId='MessageID'>
            <Form.Label>Message Type ID</Form.Label>
            <Form.Control
              name='MessageTypeID'
              onChange={(e) => {
                setMessageID(e.target.value);
                dispatch(
                  BasicDataChanged({
                    inputValue: e.target.value,
                    name: e.target.name,
                  })
                );
              }}
              value={MessageID}
              placeholder='Message Type ID'
            />
          </Form.Group>
        </Col>
        <Col>
          <Form.Group controlId='SLATargetPercent'>
            <Form.Label>SLA Target Percent</Form.Label>
            <Form.Control
              name='SLATargetPercent'
              onChange={(e) => {
                setSLATargetPercant(e.target.value);
                dispatch(
                  BasicDataChanged({
                    inputValue: e.target.value,
                    name: e.target.name,
                  })
                );
              }}
              value={SLATargetPercant}
              placeholder='Percentage'
            />
          </Form.Group>
        </Col>
        <Col>
          <Form.Group controlId='importanceFlag'>
            <Form.Label>Importance/Urgent Flag</Form.Label>
            <Form.Control
              as='select'
              name='importanceFlag'
              onChange={(e) => {
                setImportance(e.target.value);
                dispatch(
                  BasicDataChanged({
                    inputValue: e.target.value,
                    name: e.target.name,
                  })
                );
              }}
              value={Importance}
            >
              <option>Select</option>
              <option>Yes</option>
              <option>No</option>
            </Form.Control>
          </Form.Group>
        </Col>
      </Row>
      <Row>
        <Col>
          <Form.Group controlId='messageDescription'>
            <Form.Label>Message Description</Form.Label>
            <Form.Control
              name='MessageDescription'
              onChange={(e) => {
                setMessageDescription(e.target.value);
                dispatch(
                  BasicDataChanged({
                    inputValue: e.target.value,
                    name: e.target.name,
                  })
                );
              }}
              value={MessageDescription}
              placeholder='Message Description'
            />
          </Form.Group>
        </Col>
        <Col>
          <Form.Group controlId='AlertsSLAMinuttes'>
            <Form.Label>Alerts SLA Minuttes</Form.Label>
            <Form.Control
              name='AlertsSLAMinuttes'
              onChange={(e) => {
                setAlertsSLAMinuttes(e.target.value);
                dispatch(
                  BasicDataChanged({
                    inputValue: e.target.value,
                    name: e.target.name,
                  })
                );
              }}
              value={AlertsSLAMinuttes}
              placeholder='Alerts SLA Minuttes'
            />
          </Form.Group>
        </Col>
        <Col>
          <Form.Group controlId='ActiveFlag'>
            <Form.Label>Active Flag</Form.Label>
            <Form.Control
              as='select'
              name='ActiveFlag'
              onChange={(e) => {
                setActive(e.target.value);
                dispatch(
                  BasicDataChanged({
                    inputValue: e.target.value,
                    name: e.target.name,
                  })
                );
              }}
              value={Active}
            >
              <option>Select</option>
              <option>Yes</option>
              <option>No</option>
            </Form.Control>
          </Form.Group>
        </Col>
      </Row>
      <Row>
        <Col>
          <Form.Group controlId='SORID'>
            <Form.Label>SOR Application ID</Form.Label>
            <Form.Control
              name='SORApplicationID'
              onChange={(e) => {
                setSORApplicationID(e.target.value);
                dispatch(
                  BasicDataChanged({
                    inputValue: e.target.value,
                    name: e.target.name,
                  })
                );
              }}
              value={SORApplicationID}
              placeholder='SOR App ID'
            />
          </Form.Group>
        </Col>
        <Col>
          <Form.Group controlId='MessageIdentifier'>
            <Form.Label>Message Identifier</Form.Label>
            <Form.Control
              name='MessageIdentifier'
              onChange={(e) => {
                setMessageIdentifier(e.target.value);
                dispatch(
                  BasicDataChanged({
                    inputValue: e.target.value,
                    name: e.target.name,
                  })
                );
              }}
              value={MessageIdentifier}
              placeholder='Message Identifier'
            />
          </Form.Group>
        </Col>
        <Col>
          <Form.Group controlId='ImplicitsubFlag'>
            <Form.Label>Implicit sub Flag</Form.Label>
            <Form.Control
              as='select'
              name='ImplicitsubFlag'
              onChange={(e) => {
                setImplicitsubFlag(e.target.value);
                dispatch(
                  BasicDataChanged({
                    inputValue: e.target.value,
                    name: e.target.name,
                  })
                );
              }}
              value={ImplicitsubFlag}
            >
              <option>Select</option>
              <option>Yes</option>
              <option>No</option>
            </Form.Control>
          </Form.Group>
        </Col>
      </Row>
      <Row>
        <Col>
          <Form.Group controlId='CreatorDate'>
            <Form.Label>Creator Date</Form.Label>
            <Form.Control
              name='CreatorDate'
              onChange={(e) => {
                setCreatorDate(e.target.value);
                dispatch(
                  BasicDataChanged({
                    inputValue: e.target.value,
                    name: e.target.name,
                  })
                );
              }}
              value={CreatorDate}
              placeholder='Creator Date'
            />
          </Form.Group>
        </Col>
        <Col>
          <Form.Group controlId='exampleForm.ControlInput1'>
            <Form.Label>Message Type Subcode</Form.Label>
            <Form.Control
              name='MessageTypeSubcode'
              onChange={(e) => {
                setMessageTypeSubcode(e.target.value);
                dispatch(
                  BasicDataChanged({
                    inputValue: e.target.value,
                    name: e.target.name,
                  })
                );
              }}
              value={MessageTypeSubcode}
              placeholder='Message Type Subcode'
            />
          </Form.Group>
        </Col>
        <Col>
          <Form.Group controlId='BrandingRequiredFlag'>
            <Form.Label>Branding Required Flag</Form.Label>
            <Form.Control
              as='select'
              name='BrandingRequiredFlag'
              onChange={(e) => {
                setBrandingRequiredFlag(e.target.value);
                dispatch(
                  BasicDataChanged({
                    inputValue: e.target.value,
                    name: e.target.name,
                  })
                );
              }}
              value={BrandingRequiredFlag}
            >
              <option>Select</option>
              <option>Yes</option>
              <option>No</option>
            </Form.Control>
          </Form.Group>
        </Col>
      </Row>
    </Form>
  );
}
export default BasicInfoTab;
