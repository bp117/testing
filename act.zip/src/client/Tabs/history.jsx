import React, { useState, useEffect } from 'react';
import { Table, Row, Col, Button } from 'react-bootstrap';
import {
  BasicDataLoaded,
  NormalizationDataLoaded,
  TemplateDataLoaded,
  historyDataLoaded,
} from '../store/actions';
import { useSelector, useDispatch } from 'react-redux';
function NormalizationTab() {
  const [history, setHistory] = useState({});
  const dispatch = useDispatch();
  //   const stateData = useSelector((state) => state);
  useEffect(() => {
    async function fetchMyAPI() {
      let response = await fetch('api/getyamlfiles');
      response = await response.json();
      setHistory(response);
    }
    fetchMyAPI();
  }, []);
  function FindID(e) {
    e.preventDefault();
    const url = '/api/' + e.target.id;
    const FileName = e.target.id;
    try {
      response = fetch(url, {
        method: 'get',
        headers: {
          'Content-Type': 'application/json',
        },
        // body: JSON.stringify(stateData),
      })
        .then((response) => response.json())
        .then((data) => {
          dispatch(BasicDataLoaded(data.BasicData));
          dispatch(TemplateDataLoaded(data.TemplateData));
          dispatch(NormalizationDataLoaded(data.Normalization));
          dispatch(
            historyDataLoaded({
              Edited: true,
              EditedAt: new Date().toLocaleDateString(),
              FileName: FileName,
            })
          );
          // console.log(data);
        })
        .catch((err) => {
          console.log(err);
        });
    } catch (err) {
      return false;
    }
  }
  return (
    <Row className='text-center'>
      <Col>
        <Table striped bordered hover size='sm'>
          <thead>
            <tr>
              <th>#</th>
              <th>File Name</th>
              <th>Created At</th>
              <th>Size</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {history.length > 0 ? (
              history.map((item, index) => {
                return (
                  <tr key={index}>
                    <td>{index + 1}</td>
                    <td>{item.name}</td>
                    <td>{item.birthtime}</td>
                    <td>{item.size}</td>
                    <td id={item.name}>
                      <Button id={item.name} onClick={FindID} variant='primary'>
                        Load
                      </Button>{' '}
                    </td>
                  </tr>
                );
              })
            ) : (
              <tr></tr>
            )}
          </tbody>
        </Table>
      </Col>
    </Row>
  );
}
export default NormalizationTab;
