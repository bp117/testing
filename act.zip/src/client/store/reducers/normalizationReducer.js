const Normalization = (state = {
    // FieldName: '',
    // Order: ''
}, action) => {
    switch (action.type) {
        case "NormalizationDataChanged":
            return { ...state, [action.payload.name]: action.payload.inputValue }
            break;
        case "NORMALIZATIONDATAFOUNDFROMYAML":
            return action.payload
            break;
        default:
            return state
            break;
    }

}
export default Normalization