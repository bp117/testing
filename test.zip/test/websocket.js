
const WebSocket = require("ws");

let wsServer = null;
let activeClient = null;
const startServer = ()=>{
    wsServer = new WebSocket.Server({port: 5829})
    wsServer.on("connection", client=>{
        activeClient = client;
        client.on("close", ()=>{ activeClient = null; console.log("CLIENT DISCONNECTED!") })
        console.log("NEW CONNECTION")
    });
    wsServer.on("close", ()=>{
        activeClient = null;
        wsServer = null;
    })
    wsServer.on("listening", ()=>{
        console.log("LISTENING ON PORT 5829")
    })
}

const closeServer = ()=>{
    if(activeClient){
        activeClient.close();
        activeClient = null;
    }
    if(wsServer){
        wsServer.close();
        wsServer = null;
    }   
}

const sendToActiveClient = (data)=>{
    if(activeClient){
        activeClient.send(JSON.stringify(data));
    }
    else {
        console.error("NO ACTIVE CLIENT CONNECTED TO SEND THE DATA");
    }
    data = null;
}

const isServerRunning = ()=>{
    return !!wsServer;
}

startServer()
