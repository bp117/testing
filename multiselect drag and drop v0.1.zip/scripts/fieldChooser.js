(function($) {
    $.fn.fieldChooser = function (data, options)
    {
        var _options = options;
        if(typeof options !== 'object'){
            _options = {};
        }

        var isClone = typeof _options.clone === "boolean" ? _options.clone : false;
        var headingDestination1 = typeof _options.firstDestinationHeading === "string" ? _options.firstDestinationHeading : "";
        var headingDestination2 = typeof _options.secondDestinationHeading === "string" ? _options.secondDestinationHeading : "";
        var sourceHeading = typeof _options.sourceHeading === "string" ? _options.sourceHeading : "";;
        var sourceKey = typeof _options.sourceKey === "string" ? _options.sourceKey : "source";;
        var keyDestination1 = typeof _options.firstDestinationKey === "string" ? _options.firstDestinationKey : "destination1";
        var keyDestination2 = typeof _options.secondDestinationKey === "string" ? _options.secondDestinationKey : "destination2";
        

        var _data = data.map(function(el){
            el.id = getId();
            if(Array.isArray(el.in)){
                if(isClone){
                    if(el.in.length === 0){
                        el.in.push(0)
                    }
                }
                else {
                    if(el.in.length === 0){
                        el.in.push(0)
                    }
                    else {
                        el.in = [el.in[0]];
                    }
                }
                
            }
            else{
                el.in = [0];
            }
            return el;
        });

        var initElement = this;
        this.addClass('jqplugin-master-container');
        initElement.append(`
            <div class="jqplugin-source-parent-container jqplugin-parent-container">
                ${sourceHeading === '' ? '' : `<div class="jqplugin-heading-container">${sourceHeading}</div>`}
                <div class="jqplugin-search-container">
                    <input type="text" placeholder="Search" class="jqplugin-search-input" />
                </div>
                <div class="jqplugin-source-container jqplugin-container"></div>
                <div class="jqplugin-source-selectall">
                    Select All
                </div>
            </div>
        `);
        initElement.append(`
            <div class="jqplugin-first-destination-parent-container jqplugin-parent-container">
                ${headingDestination1 === '' ? '' : `<div class="jqplugin-heading-container">${headingDestination1}</div>`}
                <div class="jqplugin-search-container">
                    <input type="text" placeholder="Search" class="jqplugin-search-input"/>
                </div>
                <div class="jqplugin-first-destination-container jqplugin-container"></div>
                <div class="jqplugin-container-deleteall">
                    Delete All
                </div>
            </div>
        `);
        initElement.append(`
            <div class="jqplugin-second-destination-parent-container jqplugin-parent-container">
                ${headingDestination2 === '' ? '' : `<div class="jqplugin-heading-container">${headingDestination2}</div>`}
                <div class="jqplugin-search-container">
                    <input type="text" placeholder="Search" class="jqplugin-search-input" />
                </div>
                <div class="jqplugin-second-destination-container jqplugin-container"></div>
                <div class="jqplugin-container-deleteall">
                    Delete All
                </div>
            </div>
        `);
        
        var sourceDiv = initElement.find(".jqplugin-source-container");
        var firstDestination = initElement.find(".jqplugin-first-destination-container");
        var secondDestination = initElement.find(".jqplugin-second-destination-container");

        function getId(length = 20) {
            var result           = '';
            var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
            var charactersLength = characters.length;
            for ( var i = 0; i < length; i++ ) {
               result += characters.charAt(Math.floor(Math.random() * charactersLength));
            }
            return result;
        }

        function modifyItemObject(data, id, moveTo){
            return data.map(function(el){
                if(el.id === id){
                    if(Array.isArray(el.in)){
                        if(!el.in.includes(moveTo)){
                            if(isClone){
                                el.in.push(moveTo);
                            }
                            else {
                                el.in = [moveTo];
                            }
                        }
                    }
                    else{
                        el.in = [moveTo];
                    }
                }
                return el;
            });
        }

        function setData(data){
            _data = data;
        }
        function getData(){
            return _data;
        }

        function appendInContainer(data, source, c){
            source.append('<div class="jqpn-listitem '+c+'" data-id="'+data.id+'">'+data.label+'</div>');
        }

        function buildData(data){
            sourceDiv.empty();
            firstDestination.empty();
            secondDestination.empty();
            _data.forEach(element => {
                if(!element.in || element.in.includes(0)){
                    appendInContainer(element, sourceDiv, 'jqpn-source-listitem')
                }
                if(element.in && element.in.includes(1)){
                    appendInContainer(element, firstDestination, '')
                }
                if(element.in && element.in.includes(2)){
                    appendInContainer(element, secondDestination, '')
                }
            });
            initSearch()
        }

        function initSortable(){
            var _selectorInitiator = ".jqplugin-source-container, .jqplugin-first-destination-container, .jqplugin-second-destination-container";
            var _connectsWith = ".jqplugin-first-destination-container, .jqplugin-second-destination-container";
            
            initElement.find(_selectorInitiator).sortable({
                connectWith: _connectsWith,
                delay: 150,
                revert: 0,
                helper: function (e, item) {
                    if(!item.hasClass("jqpn-source-listitem")){
                        e.cancel();
                    }
                    if (!item.hasClass('jqpn-selected')) {
                        item.addClass('jqpn-selected').siblings().removeClass('jqpn-selected');
                    }
                    var elements = item.parent().children('.jqpn-selected').clone();
                    item.data('multidrag', elements)
                    var helper = $('<div/>');
                    return helper.append(elements);
                },
                receive: function(e, ui){
                    var elements = ui.item.data('multidrag');
                    var receiverIndex = $(this).hasClass("jqplugin-first-destination-container") ? 1 : 2;
                    elements.each(function(el){
                        var id = $(this).attr('data-id');
                        var updatedData = modifyItemObject(getData(), id, receiverIndex);
                        setData(updatedData);
                    });
                    ui.item.after(elements).remove();
                    buildData(getData());
                }
            
            });
        }

        function initSelectHandler(){
            sourceDiv.on('click', '.jqpn-listitem', function (e) {
                if (e.ctrlKey || e.metaKey) {
                    $(this).toggleClass("jqpn-selected");
                } else {
                    $(this).addClass("jqpn-selected").siblings().removeClass('jqpn-selected');
                }
            });
        }

        function deleteFn(id, targetIndex){
            var modifiedData = getData().map(function(el){
                if(el.id === id && Array.isArray(el.in) && el.in.includes(targetIndex)){
                    var index = el.in.indexOf(targetIndex);
                    el.in.splice(index, 1);
                    if(!el.in.includes(0)) {
                        el.in.push(0);
                    }
                }
                return el;
            });
            setData(modifiedData);
        }

        function bindDeleteHandlers(){
            [firstDestination, secondDestination].forEach(function(des, desIndex){
                var targetIndex = desIndex+1;
                des.on("click", ".jqpn-listitem", function(){
                    var id = $(this).attr("data-id");
                    deleteFn(id, targetIndex);
                    buildData(getData());
                });
            })
        }

        function initSearchHander() {
            initElement.find(".jqplugin-search-input").on("keyup", function(){
                var val = this.value.toLowerCase();
                var targetEl = $(this).closest(".jqplugin-parent-container").find(".jqplugin-container");
                targetEl.find(".jqpn-listitem").each(function(){
                    if($(this).html().toLowerCase().indexOf(val) !== -1){
                        $(this).show().removeClass("jqpn-listitem-hidden");
                    }
                    else{
                        $(this).hide().addClass("jqpn-listitem-hidden");
                    }
                });
            })
        }

        function initSearch() {
            initElement.find(".jqplugin-search-input").keyup();
        }

        function initSelectAll() {
            initElement.find(".jqplugin-source-selectall").on("click", function(){
                var listItems = sourceDiv.find(".jqpn-listitem").not(".jqpn-listitem-hidden");
                var selected = sourceDiv.find(".jqpn-listitem.jqpn-selected").not(".jqpn-listitem-hidden").length;
                if(selected === 0){
                    listItems.addClass("jqpn-selected");
                }
                else{
                    listItems.removeClass("jqpn-selected");
                }
            });
        }

        function initDeleteAll() {
            initElement.find(".jqplugin-container-deleteall").on("click", function(){
                var containerDiv = $(this).closest(".jqplugin-parent-container").find(".jqplugin-container");
                var targetIndex = containerDiv.hasClass("jqplugin-first-destination-container") ? 1 : 2;
                var allItems = containerDiv.find(".jqpn-listitem").not(".jqpn-listitem-hidden");
                allItems.each(function(){
                    var itemId = $(this).attr("data-id");
                    deleteFn(itemId, targetIndex);
                })
                buildData(getData());
            })
        }
        
        bindDeleteHandlers();
        initSortable();
        initSelectHandler();
        buildData(getData());
        initSearchHander();
        initSelectAll();
        initDeleteAll();

        return {
            value: function(){
                var _o = {
                    [sourceKey]: [],
                    [keyDestination1]: [],
                    [keyDestination2]: []
                };
                var d = getData();
                d.forEach(function(o){
                    var __o = {
                        value: o.value,
                        label: o.label
                    };
                    if(o.in.includes(0)){
                        _o[sourceKey].push(__o)
                    }
                    else if(o.in.includes(1)){
                        _o[keyDestination1].push(__o)
                    }
                    else if(o.in.includes(2)){
                        _o[keyDestination2].push(__o)
                    }
                })
                return _o;
            }
        }
    }
}(jQuery));