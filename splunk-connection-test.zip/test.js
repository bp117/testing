const splunkjs = require("splunk-sdk");
let service = new splunkjs.Service({username:"admin", password:"celsoppe", host:"localhost", port:8089});
service.login(function(err, success){
    if(err){
        throw err;
    }
    let savedSearches = service.savedSearches();
    savedSearches.fetch(function(err, resp){
        if(err){
            throw err;
        }
        console.log("saved searches ", [...resp.list()].map(t=>({name:t.name, search:t._properties.search})))
    })
    console.log("LOGIN SUCCESS ", success)
});
