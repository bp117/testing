/*
Make sure that default value for the dropdown should be the among the ones it actually has
Use like below:
export const DEFAULTS = {
    BasicData: {
      MessageTypeID: 'fewfwf',
      SLATargetPercent: 'fewf',
      AlertsSLAMinuttes: 'ewfwf',
      MessageDescription: 'fwefwf',
      SORApplicationID: 'fwefwwfwf',
      CreatorDate: 'fwefwf',
      MessageTypeSubcode: 'fwefwf',
      MessageIdentifier: 'fw',
      ActiveFlag: 'Yes',
      BrandingRequiredFlag: 'Yes',
      ImplicitsubFlag: 'Yes',
      importanceFlag: 'No'
    },
    TemplateData: {
      htmlEmail: {
        TemplateID: 'Hello',
        XSLTTemplateID: 'world',
        EngAddressLabel: 'this',
        SpaAddressLabel: 'sample',
        SpaCustomerSegment: 'info',
        EngCustomerSegment: 'is',
        EngLanguage: 'Spa'
      },
      plainTextEmail: {
        TemplateID: 'Hello',
        XSLTTemplateID: 'world',
        EngAddressLabel: 'this',
        SpaAddressLabel: 'sample',
        SpaCustomerSegment: 'info',
        EngCustomerSegment: 'is',
        EngLanguage: 'Spa'
      },
      secureInbox: {
        TemplateID: 'Hello',
        XSLTTemplateID: 'world',
        EngAddressLabel: 'this',
        SpaAddressLabel: 'sample',
        SpaCustomerSegment: 'info',
        EngCustomerSegment: 'is',
        EngLanguage: 'Spa'
      },
      sms: {
        TemplateID: 'Hello',
        XSLTTemplateID: 'world',
        EngAddressLabel: 'this',
        SpaAddressLabel: 'sample',
        SpaCustomerSegment: 'info',
        EngCustomerSegment: 'is',
        EngLanguage: 'Spa'
      },
      push: {
        TemplateID: 'Hello',
        XSLTTemplateID: 'world',
        EngAddressLabel: 'this',
        SpaAddressLabel: 'sample',
        SpaCustomerSegment: 'info',
        EngCustomerSegment: 'is',
        EngLanguage: 'Spa'
      }
    },
    Normalization: [
      {
        id: 0,
        fieldName: 'f1',
        order: 'o1'
      },
      {
        id: 1,
        fieldName: 'f1',
        order: 'o1'
      },
      {
        id: 2,
        fieldName: 'f3',
        order: 'o3'
      }
    ]
  };

*/

export const DEFAULTS = {
    BasicData: {
      MessageTypeID: '',
      SLATargetPercent: '',
      AlertsSLAMinuttes: '',
      MessageDescription: '',
      SORApplicationID: '',
      CreatorDate: '',
      MessageTypeSubcode: '',
      MessageIdentifier: '',
      ActiveFlag: '',
      BrandingRequiredFlag: '',
      ImplicitsubFlag: '',
      importanceFlag: ''
    },
    TemplateData: {
      htmlEmail: {
        TemplateID: '',
        XSLTTemplateID: '',
        EngAddressLabel: '',
        SpaAddressLabel: '',
        SpaCustomerSegment: '',
        EngCustomerSegment: '',
        EngLanguage: 'Eng'
      },
      plainTextEmail: {
        TemplateID: '',
        XSLTTemplateID: '',
        EngAddressLabel: '',
        SpaAddressLabel: '',
        SpaCustomerSegment: '',
        EngCustomerSegment: '',
        EngLanguage: 'Eng'
      },
      secureInbox: {
        TemplateID: '',
        XSLTTemplateID: '',
        EngAddressLabel: '',
        SpaAddressLabel: '',
        SpaCustomerSegment: '',
        EngCustomerSegment: '',
        EngLanguage: 'Eng'
      },
      sms: {
        TemplateID: '',
        XSLTTemplateID: '',
        EngAddressLabel: '',
        SpaAddressLabel: '',
        SpaCustomerSegment: '',
        EngCustomerSegment: '',
        EngLanguage: 'Eng'
      },
      push: {
        TemplateID: '',
        XSLTTemplateID: '',
        EngAddressLabel: '',
        SpaAddressLabel: '',
        SpaCustomerSegment: '',
        EngCustomerSegment: '',
        EngLanguage: 'Eng'
      }
    },
    Normalization: [
      {
        id: 0,
        fieldName: '',
        order: ''
      }
    ]
  };