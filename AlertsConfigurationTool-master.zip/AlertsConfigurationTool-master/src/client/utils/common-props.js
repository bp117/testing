export const commonProps = {
    maxLength: 3,
    minLength: 20,
    required: 'required'
}