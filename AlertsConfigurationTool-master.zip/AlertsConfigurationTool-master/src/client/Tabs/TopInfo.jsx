import React from 'react';
import { connect } from 'react-redux';
import { get } from 'lodash';
import {Alert} from '@material-ui/lab';

const TopInfo = (props) => {
    const {
        History
    } = props;

    const fileName = get(History, 'sessionData.fileName');
    const editType = get(History, 'sessionData.editType');
    let status = editType === "edit" ? "Editing" : editType === "review" ? "Reviewing" : "";

    if(!fileName) {
        return null;
    }
    return (
        <div style={{margin: '30px 0'}}>
            <Alert severity='info'>
                {/* <Alert.Heading></Alert.Heading> */}
                {status} <strong>{fileName}</strong>
            </Alert>
        </div>
    )
}

function mapStateToProps(state) {
    return state;
}
export default connect(mapStateToProps, null)(TopInfo);
