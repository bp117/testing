import React, { useState, useEffect } from 'react';
import { useSnackbar } from 'notistack';
import {
  makeStyles,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Tooltip,
  IconButton,
  Icon
} from '@material-ui/core';

import {
  RateReview as ReviewIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  GetApp as DownloadIcon
} from '@material-ui/icons';

import {useHistory} from 'react-router-dom';
import dayjs from 'dayjs';
import { useSelector, useDispatch } from 'react-redux';
import Axios from 'axios';
import {
  BasicDataLoaded,
  NormalizationDataLoaded,
  TemplateDataLoaded,
  historyDataLoaded,
} from '../store/actions';
import {responseToDownload} from '../utils/download';

const useStyles = makeStyles({
  table: {
    minWidth: 650,
  },
  errorContainer: {
    padding: '20px'
  }
});


function NormalizationTab(props) {
  const classes = useStyles();
  const h = useHistory();
  const [history, setHistory] = useState({});
  const [responsedata, setResponseData] = useState({});
  const { enqueueSnackbar, closeSnackbar } = useSnackbar();

  const dispatch = useDispatch();

  async function fetchMyAPI() {
    try {
      let response = await fetch('api/getyamlfiles', {cache: "no-store"});
      response = await response.json();
      if(Array.isArray(response)){
        setHistory(response);
      }
      else{
        setHistory([]);
      }
    }
    catch(err) {
      setHistory([]);
    }
    
  }

  useEffect(() => {
    fetchMyAPI();
  }, []);

  const DeleteFile = (e, itemName) => {
    const url = '/api/' + itemName;
    try {
      response = fetch(url, {
        method: 'delete',
        headers: {
          'Content-Type': 'application/json',
        },
      })
      .then((response) => response.json())
      .then((data) => {
        enqueueSnackbar("Details deleted successfully", {variant: "info"})
        fetchMyAPI();
      }).catch((err) => {
        enqueueSnackbar("Something went wrong, please try again later!", {variant: 'error'})
        console.log(err);
      });
    }
    catch (err) {
      return false;
    }
  };

  function FindID(e, type, itemName) {
    e.preventDefault();
    const url = '/api/' + itemName;
    const FileName = itemName
    try {
      response = fetch(url, {
        method: 'get',
        headers: {
          'Content-Type': 'application/json',
        },
      })
      .then((response) => response.json())
      .then((data) => {
        dispatch(BasicDataLoaded(data.BasicData));
        dispatch(TemplateDataLoaded(data.TemplateData));
        dispatch(NormalizationDataLoaded(data.Normalization));
        dispatch(
          historyDataLoaded({
            ...data.History,
            Edited: true,
            EditedAt: new Date().toLocaleDateString(),
            FileName: FileName,
            sessionData: {
              editType: type,
              fileName: itemName
            }
          })
        );
        h.push('/create');
        enqueueSnackbar(`Details fetched for ${type === "edit" ? "edit" : "review"}`, {variant: "info"});
      })
      .catch((err) => {
        enqueueSnackbar("Something went wrong, please try again later!", {variant: 'error'})
        console.log(err);
      });
    } catch (err) {
      return false;
    }
  }

  

  async function Downloadyaml(e, fileName, extension) {
    e.preventDefault();
    const url = '/api/download/'+extension+'/' + fileName;
    fetch(url, {
      method: 'get',
      headers: {
        'Content-Type': 'application/json',
      },
    })
    .then((response) => response.json())
    .then((data) => {
      if(extension === "yaml"){
        enqueueSnackbar("YAML file downloaded successfully", {variant: "info"})
        responseToDownload(data.yaml, fileName);
      }
      if(extension === "sql"){
        enqueueSnackbar("DML file downloaded successfully", {variant: "info"})
        responseToDownload(data.sql, fileName.replace('.yaml', '.sql'));
      }
    })
    .catch((err) => {
      enqueueSnackbar("Something went wrong, please try again later!", {variant: 'error'})
      console.log(err);
    });
  }

  return (
    <TableContainer component={Paper}>
      <Table className={classes.table} aria-label="simple table">
        <TableHead>
          <TableRow>
            <TableCell>#</TableCell>
            <TableCell>File Name</TableCell>
            <TableCell>Created At</TableCell>
            <TableCell>Size</TableCell>
            <TableCell>Status</TableCell>
            <TableCell align="right">Action</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
        {history.length > 0 ? (
              history.map((item, index) => {
                return (
                  <TableRow key={index}>
                    <TableCell>{index + 1}</TableCell>
                    <TableCell>{item.name}</TableCell>
                    <TableCell>{dayjs(item.birthtime).format('HH:mm:ss - DD, MMM YYYY')}</TableCell>
                    <TableCell>{item.size}</TableCell>
                    <TableCell>{item.fileInfo.status}</TableCell>
                    <TableCell align="right" padding="none">
                      {
                        item.fileInfo.status === "SENT_FOR_REVIEW" && (
                          <Tooltip title="Review">
                            <IconButton aria-label="delete" onClick={(e) => FindID(e, "review", item.name)}>
                              <ReviewIcon />
                            </IconButton>
                          </Tooltip>
                        )
                      }

                      <Tooltip title="Edit">
                        <IconButton aria-label="delete" onClick={(e) => FindID(e, "edit", item.name)}>
                          <EditIcon />
                        </IconButton>
                      </Tooltip>

                      <Tooltip title="Delete Permanently">
                        <IconButton aria-label="delete" onClick={(e) => DeleteFile(e, item.name)} >
                          <DeleteIcon />
                        </IconButton>
                      </Tooltip>

                      <Tooltip title="Download YAML">
                        <IconButton aria-label="delete" onClick={(e) => Downloadyaml(e, item.name, 'yaml')} >
                          <DownloadIcon />
                        </IconButton>
                      </Tooltip>

                      <Tooltip title="Download DML">
                        <IconButton aria-label="delete" onClick={(e) => Downloadyaml(e, item.name, 'sql')}>
                          <DownloadIcon />
                        </IconButton>
                      </Tooltip>


                    </TableCell>
                    
                  </TableRow>
                )
        })
        ) : (
          <div className={classes.errorContainer}>
            <p>No records found to display</p>  
          </div>
        )}
        </TableBody>
      </Table>
    </TableContainer>
  );
}
export default NormalizationTab;
