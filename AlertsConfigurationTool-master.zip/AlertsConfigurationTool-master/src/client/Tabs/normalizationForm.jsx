import React, { useState, useEffect } from 'react';
import {
  Grid,
  Button,
  IconButton
} from '@material-ui/core';
import {
  Add as AddIcon,
  Remove as RemoveIcon
} from '@material-ui/icons';
import { NormalizationDataChanged } from '../store/actions';
import { useSelector, useDispatch } from 'react-redux';
import TextField from '../components/TextField/index';

function NormalizationForm(props) {
  //   const Rstate = useSelector((state) => state.Normalization);
  const dispatch = useDispatch();
  const [FieldName, setFieldName] = useState(props.values.fieldName || '');
  const [Order, setOrder] = useState(props.values.order || '');
  const {
    index,
    formsLength
  } = props;
  //   const stateData = useSelector((state) => state);

  const removeHandler = (e,i) => {
    if(formsLength === 1) {
      return;
    }
    props.remove(e,i);
  }

  return (
    <Grid container spacing={3}>
      <Grid item md={5}>
          <TextField 
              variant="outlined" 
              label="Field Name"
              name='fieldName'
              fullWidth
              onChange={(e) => {
                setFieldName(e.target.value);
                dispatch(
                  NormalizationDataChanged({
                    inputValue: e.target.value,
                    id: props.values.id,
                    name: e.target.name,
                  })
                );
              }}
              value={FieldName}
              placeholder='Field Name'
            />
      </Grid>
      <Grid item md={5}>
          <TextField 
              variant="outlined" 
              label="Order"
              name='order'
              fullWidth
              onChange={(e) => {
                setOrder(e.target.value);
                dispatch(
                  NormalizationDataChanged({
                    inputValue: e.target.value,
                    id: props.values.id,
                    name: e.target.name,
                  })
                );
              }}
              value={Order}
              placeholder='Order'
            />
      </Grid>
      <Grid item md={2}>
        <IconButton color="primary" onClick={props.increment}>
          <AddIcon />
        </IconButton> {' '}
        <IconButton disabled={formsLength === 1} onClick={(e) => removeHandler(e, index)}>
          <RemoveIcon />
        </IconButton>
      </Grid>
    </Grid>
  )
}
export default NormalizationForm;
