import React, { useState, useEffect } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { NormalizationFormAdding } from '../store/actions';
import NormalizationForm from './normalizationForm';


const NormalizationTab = (props) => {
  console.log(props);
  const [forms, setForms] = useState({forms: []})
  

  useEffect(() => {
    setForms({forms: props.Normalization})
  }, []);

  


  const increment = (e) => {
    let _forms = forms.forms;
    _forms.push({
      id: _forms.length,
      fieldName: '',
      order: '',
    });
    setForms({forms: _forms})
    props.NormalizationFormAdding(_forms);
  };


  const removeFn = (e, index) => {
    let _forms = forms.forms;
    _forms.splice(index, 1);
    setForms({forms: _forms});
    props.NormalizationFormAdding(_forms);
  };

  return (
    <>
        {forms &&
          forms.forms.map((form, index) => {
            return (
              <NormalizationForm
                formsLength={forms.forms.length}
                key={form.id}
                index={index}
                values={form}
                increment={increment}
                remove={removeFn}
              />
            );
          })}
    </>
  );
}


function mapStateToProps(state) {
  return state;
}


function mapDispatchToProps(dispatch) {
  return bindActionCreators({ NormalizationFormAdding }, dispatch);
}


export default connect(mapStateToProps, mapDispatchToProps)(NormalizationTab);
