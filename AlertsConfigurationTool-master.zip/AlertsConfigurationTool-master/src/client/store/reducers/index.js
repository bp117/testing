import BasicData from "./BasicDataReducer"
import TemplateData from "./TemplateDataReducer"
import Normalization from "./normalizationReducer"
import History from "./historyReducer"
import { combineReducers } from "redux"
const rootReducer = combineReducers({
    BasicData,
    TemplateData,
    Normalization,
    History
})
export default rootReducer;