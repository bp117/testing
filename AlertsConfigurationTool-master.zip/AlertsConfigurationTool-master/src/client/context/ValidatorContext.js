import React from 'react';
const ValidatorContext = React.createContext(null);
export default ValidatorContext;