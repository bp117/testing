import React, {useState} from 'react';
import { Tab, Tabs, TabList, TabPanel } from 'react-tabs';

import HistoryTab from './Tabs/history';

function Inbox() {

  const [tabIndex, selectTabIndex] = useState(0);

  return (
    <div>
        <HistoryTab />
    </div>
  );
}
export default Inbox;
