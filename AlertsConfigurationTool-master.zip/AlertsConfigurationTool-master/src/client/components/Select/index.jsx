import React from 'react';
import {
    Select,
    FormHelperText
} from '@material-ui/core';
import ValidatorContext from '../../context/ValidatorContext';

const OverridenSelect = (props) => {
    const {isValidateForm} = React.useContext(ValidatorContext);
    const value = props.value;
    const [isDirty, setIsDirty] = React.useState(!!props.value);
    let helperText = "";
    if(isDirty || isValidateForm){
        if(value.length === 0){
            helperText = "This field can not be empty";
        }
        else {
            helperText = "";
        }
    }
    else {
        helperText = "";
    }
    return (
        <>
            <Select 
                {...props}
                error = {helperText !== ""}
                onChange={(e) => {
                    setIsDirty(true);
                    props.onChange(e)
                }}
            />
            {helperText && <FormHelperText error>{helperText}</FormHelperText>}
        </>
    )
}

export default OverridenSelect;