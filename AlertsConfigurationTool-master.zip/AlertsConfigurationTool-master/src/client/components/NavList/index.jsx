import React from 'react';
import { NavLink } from "react-router-dom";
import clsx from 'clsx';
import {
    makeStyles,
    Drawer,
    List,
    Divider,
    IconButton,
    ListItem,
    ListItemIcon,
    ListItemText,
    Collapse,
  } from '@material-ui/core';

import ExpandLess from '@material-ui/icons/ExpandLess';
import ExpandMore from '@material-ui/icons/ExpandMore';
import ChevronLeft from '@material-ui/icons/ChevronLeft';

import {
  MoveToInbox as MoveToInboxIcon,
  Notifications as NotificationsIcon,
  AddAlert as AddAlertIcon
} from '@material-ui/icons';

const DRAWER_WIDTH = 240;
const useStyles = makeStyles((theme) => ({
    toolbarIcon: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'flex-end',
      padding: '0 8px',
      ...theme.mixins.toolbar,
    },
    heading: {
      fontSize: '30px',
      fontWeight: 'bold',
      color: '#5f5f5f',
      letterSpacing: '2px',
      flex: 1,
      textAlign: 'center'
    },
    drawerPaper: {
      position: 'relative',
      whiteSpace: 'nowrap',
      width: DRAWER_WIDTH,
      transition: theme.transitions.create('width', {
        easing: theme.transitions.easing.sharp,
        duration: theme.transitions.duration.enteringScreen,
      }),
    },
    drawerPaperClose: {
      overflowX: 'hidden',
      transition: theme.transitions.create('width', {
        easing: theme.transitions.easing.sharp,
        duration: theme.transitions.duration.leavingScreen,
      }),
      width: theme.spacing(7),
      [theme.breakpoints.up('sm')]: {
        width: theme.spacing(9),
      },
    },
    root: {
        width: '100%',
        maxWidth: 360,
        backgroundColor: theme.palette.background.paper,
    },
    nested: {
        paddingLeft: theme.spacing(4),
    },
}));

const NavList = (props) => {
    const {
        open: isDrawerOpen,
        handleDrawerClose,
    } = props;
    const classes = useStyles();
    const [open, setOpen] = React.useState(true);
    const handleClick = () => {
        setOpen(!open);
    };
    return (
        <Drawer
        variant="permanent"
        classes={{
          paper: clsx(classes.drawerPaper, !isDrawerOpen && classes.drawerPaperClose),
        }}
        open={isDrawerOpen}
      >
        <div className={classes.toolbarIcon}>
          <span className={classes.heading}>ACT</span>
          <IconButton onClick={handleDrawerClose}>
            <ChevronLeft />
          </IconButton>
        </div>
        <Divider />
        <List>
            <ListItem button component={NavLink} to="/inbox" activeClassName="Mui-selected">
                <ListItemIcon>
                    <MoveToInboxIcon />
                </ListItemIcon>
                <ListItemText primary="My Inbox" />
            </ListItem>

            <ListItem button  onClick={handleClick} >
                <ListItemIcon>
                    <NotificationsIcon />
                </ListItemIcon>
                <ListItemText primary="Alerts"/>
                {open ? <ExpandLess /> : <ExpandMore />}
            </ListItem>
            <Collapse in={open} timeout="auto" unmountOnExit>
                <List component="div" disablePadding>
                    <ListItem activeClassName="Mui-selected" button component={NavLink} to="/create"  className={classes.nested}>
                        <ListItemIcon>
                            <AddAlertIcon />
                        </ListItemIcon>
                        <ListItemText primary="Create"/>
                    </ListItem>
                    
                </List>
            </Collapse>
            
            </List>
        <Divider />
      </Drawer>
    )
}

export default NavList;