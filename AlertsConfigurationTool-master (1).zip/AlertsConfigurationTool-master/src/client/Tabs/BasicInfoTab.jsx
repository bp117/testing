import React, { useState, useEffect } from 'react';
import {
  Grid,
  FormControl,
  InputLabel,
  MenuItem
} from '@material-ui/core';
import { useSelector, useDispatch } from 'react-redux';
import { BasicDataChanged } from '../store/actions';
import TextField from '../components/TextField/index';
import Select from '../components/Select/index';


function BasicInfoTab() {
  const Rstate = useSelector((state) => state.BasicData);

  const dispatch = useDispatch();
  const [MessageID, setMessageID] = useState(Rstate.MessageTypeID || '');
  const [SLATargetPercant, setSLATargetPercant] = useState(
    Rstate.SLATargetPercent || ''
  );
  const [Importance, setImportance] = useState(Rstate.importanceFlag || '');
  const [MessageDescription, setMessageDescription] = useState(
    Rstate.MessageDescription || ''
  );
  const [AlertsSLAMinuttes, setAlertsSLAMinuttes] = useState(
    Rstate.AlertsSLAMinuttes || ''
  );
  const [Active, setActive] = useState(Rstate.ActiveFlag || '');
  const [SORApplicationID, setSORApplicationID] = useState(
    Rstate.SORApplicationID || ''
  );
  const [MessageIdentifier, setMessageIdentifier] = useState(
    Rstate.MessageIdentifier || ''
  );
  const [ImplicitsubFlag, setImplicitsubFlag] = useState(
    Rstate.ImplicitsubFlag || ''
  );
  const [CreatorDate, setCreatorDate] = useState(Rstate.CreatorDate || '');
  const [MessageTypeSubcode, setMessageTypeSubcode] = useState(
    Rstate.MessageTypeSubcode || ''
  );
  const [BrandingRequiredFlag, setBrandingRequiredFlag] = useState(
    Rstate.BrandingRequiredFlag || ''
  );
  return (
    <div>
      <Grid container spacing={3}>
        <Grid item md>
          <TextField 
              fullWidth
              variant="outlined" 
              label="Message Type ID"
              name='MessageTypeID'
              onChange={(e) => {
                setMessageID(e.target.value);
                dispatch(
                  BasicDataChanged({
                    inputValue: e.target.value,
                    name: e.target.name,
                  })
                );
              }}
              value={MessageID}
              placeholder='Message Type ID'
            />
        </Grid>
        <Grid item md>
          <TextField 
              variant="outlined" 
              label="SLA Target Percent"
              name='SLATargetPercent'
              fullWidth
              onChange={(e) => {
                setSLATargetPercant(e.target.value);
                dispatch(
                  BasicDataChanged({
                    inputValue: e.target.value,
                    name: e.target.name,
                  })
                );
              }}
              value={SLATargetPercant}
              placeholder='Percentage'
            />
        </Grid>
        <Grid item md>
          <FormControl variant="outlined" fullWidth>
            <InputLabel id="importanceFlag">Importance/Urgent Flag</InputLabel>
            <Select
              labelId="importanceFlag"
              id="importanceFlag"
              name="importanceFlag"
              onChange={(e) => {
                setImportance(e.target.value);
                dispatch(
                  BasicDataChanged({
                    inputValue: e.target.value,
                    name: e.target.name,
                  })
                );
              }}
              value={Importance}
              label="Importance/Urgent Flag"
            >
              <MenuItem value={''}>Select</MenuItem>
              <MenuItem value={'Yes'}>Yes</MenuItem>
              <MenuItem value={'No'}>No</MenuItem>
            </Select>
          </FormControl>
        </Grid>
      </Grid>
      <Grid container spacing={3}>
        <Grid item md>
            <TextField 
              fullWidth
              variant="outlined" 
              label="Message Description"
              name='MessageDescription'
              onChange={(e) => {
                setMessageDescription(e.target.value);
                dispatch(
                  BasicDataChanged({
                    inputValue: e.target.value,
                    name: e.target.name,
                  })
                );
              }}
              value={MessageDescription}
              placeholder='Message Description'
            />
        </Grid>
        <Grid item md>
          <TextField 
              variant="outlined" 
              label="Alerts SLA Minuttes"
              name='AlertsSLAMinuttes'
              fullWidth
              onChange={(e) => {
                setAlertsSLAMinuttes(e.target.value);
                dispatch(
                  BasicDataChanged({
                    inputValue: e.target.value,
                    name: e.target.name,
                  })
                );
              }}
              value={AlertsSLAMinuttes}
              placeholder='Alerts SLA Minuttes'
            />
        </Grid>
        <Grid item md>
          <FormControl variant="outlined" fullWidth>
            <InputLabel id="ActiveFlag">Active Flag</InputLabel>
            <Select
              labelId="ActiveFlag"
              id="ActiveFlag"
              name="ActiveFlag"
              onChange={(e) => {
                setActive(e.target.value);
                dispatch(
                  BasicDataChanged({
                    inputValue: e.target.value,
                    name: e.target.name,
                  })
                );
              }}
              value={Active}
              label="Active Flag"
            >
              <MenuItem value={''}>Select</MenuItem>
              <MenuItem value={'Yes'}>Yes</MenuItem>
              <MenuItem value={'No'}>No</MenuItem>
            </Select>
          </FormControl>
        </Grid>
      </Grid>
      <Grid container spacing={3}>
        <Grid item md>
            <TextField 
              fullWidth
              variant="outlined" 
              label="SOR Application ID"
              name='SORApplicationID'
              onChange={(e) => {
                setSORApplicationID(e.target.value);
                dispatch(
                  BasicDataChanged({
                    inputValue: e.target.value,
                    name: e.target.name,
                  })
                );
              }}
              value={SORApplicationID}
              placeholder='SOR App ID'
            />
        </Grid>
        <Grid item md>
          <TextField 
              fullWidth
              variant="outlined" 
              label="Message Identifier"
              name='MessageIdentifier'
              onChange={(e) => {
                setMessageIdentifier(e.target.value);
                dispatch(
                  BasicDataChanged({
                    inputValue: e.target.value,
                    name: e.target.name,
                  })
                );
              }}
              value={MessageIdentifier}
              placeholder='Message Identifier'
            />
        </Grid>
        <Grid item md>
        <FormControl variant="outlined" fullWidth>
            <InputLabel id="ImplicitsubFlag">Implicit sub Flag</InputLabel>
            <Select
              labelId="ImplicitsubFlag"
              id="ImplicitsubFlag"
              name="ImplicitsubFlag"
              onChange={(e) => {
                setImplicitsubFlag(e.target.value);
                dispatch(
                  BasicDataChanged({
                    inputValue: e.target.value,
                    name: e.target.name,
                  })
                );
              }}
              value={ImplicitsubFlag}
              label="Implicit sub Flag"
            >
              <MenuItem value={''}>Select</MenuItem>
              <MenuItem value={'Yes'}>Yes</MenuItem>
              <MenuItem value={'No'}>No</MenuItem>
            </Select>
          </FormControl>
        </Grid>
      </Grid>
      <Grid container spacing={3}>
        <Grid item md>
            <TextField 
              fullWidth
              variant="outlined" 
              label="Creator Date"
              name='CreatorDate'
              onChange={(e) => {
                setCreatorDate(e.target.value);
                dispatch(
                  BasicDataChanged({
                    inputValue: e.target.value,
                    name: e.target.name,
                  })
                );
              }}
              value={CreatorDate}
              placeholder='Creator Date'
            />
        </Grid>
        <Grid item md>
          <TextField 
              fullWidth
              variant="outlined" 
              label="Message Type Subcode"
              name='MessageTypeSubcode'
              onChange={(e) => {
                setMessageTypeSubcode(e.target.value);
                dispatch(
                  BasicDataChanged({
                    inputValue: e.target.value,
                    name: e.target.name,
                  })
                );
              }}
              value={MessageTypeSubcode}
              placeholder='Message Type Subcode'
            />
        </Grid>
        <Grid item md>
          <FormControl variant="outlined" fullWidth>
            <InputLabel id="BrandingRequiredFlag">Branding Required Flag</InputLabel>
            <Select
              labelId="BrandingRequiredFlag"
              id="BrandingRequiredFlag"
              name="BrandingRequiredFlag"
              onChange={(e) => {
                setBrandingRequiredFlag(e.target.value);
                dispatch(
                  BasicDataChanged({
                    inputValue: e.target.value,
                    name: e.target.name,
                  })
                );
              }}
              value={BrandingRequiredFlag}
              label="Branding Required Flag"
            >
              <MenuItem value={''}>Select</MenuItem>
              <MenuItem value={'Yes'}>Yes</MenuItem>
              <MenuItem value={'No'}>No</MenuItem>
            </Select>
          </FormControl>

        </Grid>
      </Grid>
    </div>
  );
}
export default BasicInfoTab;
