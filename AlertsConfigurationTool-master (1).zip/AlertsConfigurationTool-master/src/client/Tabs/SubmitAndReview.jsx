import React, {useState, useEffect} from 'react';
import { useSnackbar } from 'notistack';
import { connect } from 'react-redux';
import ValidatorContext from '../context/ValidatorContext';
import {VALIDATORS} from '../utils/validators';
import {
    TextField,
    Grid,
    FormControl,
    InputLabel,
    Select,
    MenuItem,
    Button,
    Form
} from '@material-ui/core';
const SubmitAndReview = (props) => {
    const [history, setHistory] = useState({});
    const [reviewAction, setReviewAction] = useState('ADDED_REMARKS');
    const [review, setReview] = useState('');
    const { enqueueSnackbar, closeSnackbar } = useSnackbar();
    const {isValidateForm, setValidateForm} = React.useContext(ValidatorContext);


    useEffect(() => {
        setHistory(props.History)
        const reviews = props.History && props.History.fileInfo && props.History.fileInfo.reviews ? props.History.fileInfo.reviews : "";
        setReview(reviews)
    }, []);

    const Submit = async (e, historyArg) => {

        e.preventDefault();
        const url = props.History.Edited
          ? '/api/updateData'
          : '/api/createData';
        const method = props.History.Edited ? 'put' : 'post';
        const stateData = {
          BasicData: props.BasicData,
          History: historyArg,
          TemplateData: props.TemplateData,
          Normalization: props.Normalization,
        };

        let isError = false;
        const basicSelect = ["ActiveFlag", "BrandingRequiredFlag", "ImplicitsubFlag", "importanceFlag"];
        const templateSelect = ["EngLanguage"];

        Object.keys(stateData).forEach((page) => {
            if(page === "History") return;
            Object.keys(stateData[page]).forEach(section => {

                if(typeof stateData[page][section] === "string"){
                    if(VALIDATORS[section]){
                        // Validation rules to be picked from validators.js
                        const rules = VALIDATORS[section];
                        const value = stateData[page][section];
                        if(Array.isArray(rules)){
                            for(let index = 0; index < rules.length; index++){
                                if(!rules[index].handler(value)){
                                    isError = true;
                                    break;
                                }
                            }
                        }
                    }
                    else{
                        // Default validation rules
                        if(basicSelect.includes(section)){
                            if(stateData[page][section] === ""){
                                isError = true;
                            }
                        }
                        else{
                            if(stateData[page][section].length < 3 || stateData[page][section].length > 20){
                                isError = true;
                            }
                        }
                    }
                    
                }
                else if(typeof stateData[page][section] === "object") {
                    Object.keys(stateData[page][section]).forEach((field) => {   
                        if(VALIDATORS[field]){
                            // Validation rules to be picked from validators.js
                            const rules = VALIDATORS[field];
                            const value = stateData[page][section][field];
                            if(Array.isArray(rules)){
                                for(let index = 0; index < rules.length; index++){
                                    if(!rules[index].handler(value)){
                                        isError = true;
                                        break;
                                    }
                                }
                            }
                        }
                        else{
                            // Default validation rules
                            if(templateSelect.includes(field)){
                                if(stateData[page][section][field] === ""){
                                    isError = true;
                                }
                            }
                            else{
                                if(stateData[page][section][field].length < 3 || stateData[page][section][field] > 20){
                                    isError = true;
                                }
                            }
                        }
                        
                    })
                }
            })
        })

        if(isError) {
            setValidateForm(true);
            enqueueSnackbar("Please fill all the fields correctly in the forms", {
                variant: "error"
            })
            return;
        }
        else {
            setValidateForm(false);
        }

        const activity = historyArg.fileInfo.status;
        const mapping = {
            APPROVED: 'Details approved and saved',
            REJECTED: 'Details rejected and saved',
            ADDED_REMARKS: 'Remarks added and saved',
            SAVED: 'Details saved',
            SENT_FOR_REVIEW: 'Details are sent for review'
        }
    
        delete stateData.History.sessionData;
        try {
          const response = await fetch(url, {
            method,
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify(stateData),
          });
          enqueueSnackbar(mapping[activity], {variant: 'info'})
        } catch (err) {
            console.log(err);
            enqueueSnackbar("Something went wrong, please try again later!", {variant: 'error'})
            return false;
        }
        
    };
    
    
    const submitInterceptor = (e, actionInput ,reviewInput) => {
        var obj = {...history};
        if(!obj.fileInfo) {
          obj.fileInfo = {};
        }
    
        if(!obj.fileInfo.reviews) {
          obj.fileInfo.reviews = "";
        }
    
        obj.fileInfo.status = actionInput;
        obj.fileInfo.reviews += reviewInput;
          
        Submit(e, obj);
    }
    
    const denyReview = () => {
        window.location.reload();
    }


    return (
        <div>
            <Grid container style={{marginTop: '40px'}}>
                    {
                    (history && history.sessionData && history.sessionData.editType === "review") ? (
                        <>
                        <Grid item md={6}>
                        <FormControl variant="outlined" fullWidth>
                            <InputLabel id="reviewActionLabel">Action</InputLabel>
                            <Select
                            labelId="reviewActionLabel"
                            id="reviewActionLabel"
                            value={reviewAction} 
                            onChange={(e) => setReviewAction(e.target.value)}
                            label="Action"
                            >
                                <MenuItem value={'APPROVED'}>Approve</MenuItem>
                                <MenuItem value={'REJECTED'}>Reject</MenuItem>
                                <MenuItem value={'ADDED_REMARKS'}>Add Remarks</MenuItem>
                            </Select>
                        </FormControl>
                        
                            {
                            reviewAction === "ADDED_REMARKS" && (
                                <TextField 
                                    multiline
                                    className="mt-20"
                                    variant="outlined" 
                                    label="Remarks"
                                    fullWidth
                                    value={review} 
                                    onChange={(e) => setReview(e.target.value)} 
                                    placeholder='Remarks'
                                    rows={5}
                                />
                            )
                            }
                            </Grid>
                            <Grid item md={6}>
                            <div className="mt-20 text-right">
                                <Button variant="contained"  onClick={(e) => submitInterceptor(e, reviewAction, review)} color='primary'>
                                    Submit
                                </Button>{' '}
                                <Button variant="contained" onClick={denyReview} color='secondary'>
                                    Cancel
                                </Button>
                            </div>
                        </Grid>      
                        </>
                    ) : (
                        <>
                        <Grid item md={6}>
                        {
                            ["ADDED_REMARKS", "APPROVED", "REJECTED"].includes(history.fileInfo && history.fileInfo.status) && (
                                <TextField 
                                    variant="outlined" 
                                    label="Added Remarks"
                                    fullWidth
                                    value={review} 
                                    inputProps={{
                                        readonly: true,
                                        readOnly: "readOnly"
                                    }}
                                    rows={5}
                                    multiline
                                />
                            )
                        }
                        </Grid>
                        <Grid item md={6}>
                        <div className="mt-20 text-right">
                            <Button variant="contained" onClick={(e) => submitInterceptor(e, "SAVED", "")} color='primary'>
                                Save
                            </Button>{' '}
                            <Button variant="contained" onClick={(e) => submitInterceptor(e, "SENT_FOR_REVIEW", "")} color='primary'>
                                Save And Submit For Review
                            </Button>{' '}
                            <Button variant="contained" onClick={denyReview} color='secondary'>
                                Cancel
                            </Button>
                        </div>
                        </Grid>
                        </>
                    )
                    }
            </Grid>
        </div>
    )
}

function mapStateToProps(state) {
    return state;
}

export default connect(mapStateToProps, null)(SubmitAndReview);