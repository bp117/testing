import React, { useState } from 'react';
import {
  Grid,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Button
} from '@material-ui/core';
import TextField from '../components/TextField/index';


import ExpandMoreIcon from '@material-ui/icons/ExpandMore';

import { TemplateDataChanged, MassTemplateDataChanged } from '../store/actions';
import { useSelector, useDispatch } from 'react-redux';


const SingleTemplate = (props) => {

  const {
    type,
    value,
    setValue,
    duplicateFields
  } = props;
  
  return (
    <div>
      
      <Grid container spacing={3}>
        <Grid item md>
        <TextField 
              fullWidth
              variant="outlined" 
              label="Template ID"
              name='TemplateID'
              onChange={(e) => {
                setValue(e.target.value, e.target.name, type);
              }}
              value={value.TemplateID}
              placeholder='Template ID'
            />
        </Grid>
        <Grid item md>
        <TextField 
              fullWidth
              variant="outlined" 
              label="XSLT Template ID"
              name='XSLTTemplateID'
              onChange={(e) => {
                setValue(e.target.value, e.target.name, type);
              }}
              value={value.XSLTTemplateID}
              placeholder='XSLT Template ID'
            />
        </Grid>
      </Grid>
      <Grid container spacing={3} className="mt-20">
        <Grid item md={12}>
          <h3>English</h3>
          <Grid container spacing={3} className="mt-10">
            <Grid item md>
                <TextField 
                  fullWidth
                  variant="outlined" 
                  label="From Address label"
                  name='EngAddressLabel'
                  onChange={(e) => {
                    setValue(e.target.value, e.target.name, type);
                  }}
                  value={value.EngAddressLabel}
                  placeholder='From Address'
                />
            </Grid>
            <Grid item md>
                <TextField 
                  fullWidth
                  variant="outlined" 
                  label="Customer Segment"
                  name='EngCustomerSegment'
                  onChange={(e) => {
                    setValue(e.target.value, e.target.name, type);
                  }}
                  value={value.EngCustomerSegment}
                  placeholder='Customer Segment'
                />
            </Grid>
            <Grid item md>
              <FormControl variant="outlined" fullWidth>
                <InputLabel id="EngLanguage">Language</InputLabel>
                <Select
                  labelId="EngLanguage"
                  id="EngLanguage"
                  name="EngLanguage"
                  onChange={(e) => {
                    setValue(e.target.value, e.target.name, type);
                  }}
                  value={value.EngLanguage}
                  label="Language"
                >
                  <MenuItem value={'Eng'}>Eng</MenuItem>
                  <MenuItem value={'Spa'}>Spa</MenuItem>
                </Select>
              </FormControl>
            </Grid>
          </Grid>
        </Grid>
        <Grid item md={12}>
          <h3>Spanish</h3>
          <Grid container spacing={3}  className="mt-10">
            <Grid item md>
                <TextField 
                  fullWidth
                  variant="outlined" 
                  label="From Address label"
                  name='SpaAddressLabel'
                  onChange={(e) => {
                    setValue(e.target.value, e.target.name, type);
                  }}
                  value={value.SpaAddressLabel}
                  placeholder='From Address'
                />
            </Grid>
            <Grid item md>
                <TextField 
                  fullWidth
                  variant="outlined" 
                  label="Customer Segment"
                  name='SpaCustomerSegment'
                  onChange={(e) => {
                    setValue(e.target.value, e.target.name, type);
                  }}
                  value={value.SpaCustomerSegment}
                  placeholder='Customer Segment'
                />
            </Grid>
          </Grid>
        </Grid>
      </Grid>
      <div className="mt-20">
        <Button color="primary" variant="contained" onClick={() => duplicateFields(type)}>
          Clone Template To Others
        </Button>
      </div>
    </div>
  );
}

function TemplateInfo() {
  const Rstate = useSelector((state) => state.TemplateData);
  const dispatch = useDispatch();
  const getDetails = (key) => ({
    TemplateID: Rstate[key].TemplateID || '',
    XSLTTemplateID: Rstate[key].XSLTTemplateID || '',
    EngAddressLabel: Rstate[key].EngAddressLabel || '',
    SpaAddressLabel: Rstate[key].SpaAddressLabel || '',
    SpaCustomerSegment: Rstate[key].SpaCustomerSegment || '',
    EngCustomerSegment: Rstate[key].EngCustomerSegment || '',
    EngLanguage: Rstate[key].EngLanguage || 'Eng'
  });
  const [details, setDetails] = useState({
    htmlEmail: {
      ...getDetails("htmlEmail"),
    },
    plainTextEmail: {
      ...getDetails("plainTextEmail"),
    },
    secureInbox: {
      ...getDetails("secureInbox"),
    },
    sms: {
      ...getDetails("sms"),
    },
    push: {
      ...getDetails("push"),
    }
  });

  const changeValueHandler = (val, name, type) => {
    setDetails(d => {
      const newObj = {
        ...d[type],
        [name]: val
      };
      return {
        ...d,
        [type]: {
          ...newObj
        }
      }
    });
    dispatch(
      TemplateDataChanged({
        inputValue: val,
        name: name,
        type
      })
    );
  }

  const duplicateFields = (type) => {
    dispatch(
      MassTemplateDataChanged({
        type
      })
    )
    setDetails(d => {
      const obj = {};
      const data = d[type];
      Object.keys(d).forEach(el => {
        obj[el] = {...data};
      });
      return obj;
    })
  }

  return (
    <div>
      <Accordion defaultExpanded TransitionProps={{ unmountOnExit: true }}>
        <AccordionSummary>HTML EMAIL</AccordionSummary>
        <AccordionDetails>
          <SingleTemplate value={details.htmlEmail} type="htmlEmail" setValue={changeValueHandler} duplicateFields={duplicateFields} />
        </AccordionDetails>
      </Accordion>
      <Accordion TransitionProps={{ unmountOnExit: true }}>
        <AccordionSummary>PLAIN TEXT EMAIL</AccordionSummary>
        <AccordionDetails>
          <SingleTemplate value={details.plainTextEmail} type="plainTextEmail" setValue={changeValueHandler} duplicateFields={duplicateFields} />
        </AccordionDetails>
      </Accordion>
      <Accordion TransitionProps={{ unmountOnExit: true }}>
        <AccordionSummary>SECURE INBOX</AccordionSummary>
        <AccordionDetails>
          <SingleTemplate value={details.secureInbox} type="secureInbox" setValue={changeValueHandler} duplicateFields={duplicateFields} />
        </AccordionDetails>
      </Accordion>
      <Accordion TransitionProps={{ unmountOnExit: true }}>
        <AccordionSummary>SMS</AccordionSummary>
        <AccordionDetails>
          <SingleTemplate value={details.sms} type="sms" setValue={changeValueHandler} duplicateFields={duplicateFields} />
        </AccordionDetails>
      </Accordion>
      <Accordion TransitionProps={{ unmountOnExit: true }}>
        <AccordionSummary>PUSH</AccordionSummary>
        <AccordionDetails>
          <SingleTemplate value={details.push} type="push" setValue={changeValueHandler} duplicateFields={duplicateFields} />
        </AccordionDetails>
      </Accordion>
    </div>
  )  
}
export default TemplateInfo;
