import React, { useState } from 'react';
import { Form, Row, Col, Button } from 'react-bootstrap';
import { NormalizationDataChanged } from '../store/actions';
import { useSelector, useDispatch } from 'react-redux';
import NormalizationForm from './normalizationForm';
function NormalizationTab() {
  const Rstate = useSelector((state) => state.Normalization);
  // const dispatch = useDispatch();
  // const [FieldName, setFieldName] = useState(Rstate.FieldName);
  // const [Order, setOrder] = useState(Rstate.Order);
  const [Forms, setForms] = useState([
    {
      id: 1,
      FieldName: '',
      Order: '',
    },
    {
      id: 2,
      FieldName: '',
      Order: '',
    },
  ]);
  const stateData = useSelector((state) => state);
  const [Edited, setEdited] = useState(stateData.History.Edited);
  const Submit = (e) => {
    e.preventDefault();
    const url = Edited ? '/api/updateData' : '/api/createData';
    try {
      response = fetch(url, {
        method: Edited ? 'put' : 'post',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(stateData),
      });
    } catch (err) {
      return false;
    }
  };
  const increment = (e) => {
    let form = Forms;
    form.push({
      id: Forms.length + 1,
      FieldName: '',
      Order: '',
    });
    setForms(form);
    console.log(Forms);
  };
  const remove = (e) => {
    console.log(e.target);
  };
  return (
    <Form>
      {Forms &&
        Forms.map((form) => {
          return (
            <NormalizationForm
              key={form.id}
              id={form.id}
              values={form}
              increment={increment}
              remove={remove}
            />
          );
        })}
      <Row className='text-center'>
        <Col sm={12}>
          <Button onClick={Submit} variant='primary' type='submit'>
            Submit
          </Button>
        </Col>
      </Row>
    </Form>
  );
}
export default NormalizationTab;
