import React, {useState} from 'react';
// import { Tab, Tabs, TabList, TabPanel } from 'react-tabs';
import {
  makeStyles,
  AppBar,
  Tabs,
  Tab
} from '@material-ui/core';
import { 
  TabPanel,
  TabContext
} from '@material-ui/lab';

import ValidatorContext from './context/ValidatorContext';
import BasicInfoTab from './Tabs/BasicInfoTab';
import TemplateInfoTab from './Tabs/templateInfoTab';
import NormalizationTab from './Tabs/normalizationab';
import TopInfo from './Tabs/TopInfo';
import SubmitAndReview from './Tabs/SubmitAndReview';

const useStyles = makeStyles((theme) => ({
  tabs: {
    backgroundColor: '#ffffff',
    color: "#222222"
  },
  tab: {
    outline: '0px !important'
  }
})); 

function Create() {
  const classes = useStyles();
  const [tabIndex, selectTabIndex] = useState('1');
  const [isValidateForm, setValidateForm] = useState(false);
  const tabChangeHandler = (e,v) => selectTabIndex(v);

  return (
    <ValidatorContext.Provider value={{isValidateForm, setValidateForm}}>
      <div>
        <TabContext value={tabIndex}>
          <AppBar position="static" className={classes.tabs}>
            <Tabs value={tabIndex} onChange={tabChangeHandler} aria-label="Create Tabs" indicatorColor="primary">
              <Tab label="Basic Data" value="1" className={classes.tab} />
              <Tab label="Content Template" value="2" className={classes.tab} />
              <Tab label="Normalization" value="3" className={classes.tab} />
            </Tabs>
          </AppBar>
          <TabPanel value="1">
            <TopInfo />
            <BasicInfoTab />
            <SubmitAndReview />
          </TabPanel>
          <TabPanel value="2">
            <TopInfo />
            <TemplateInfoTab />
            <SubmitAndReview />
          </TabPanel>
          <TabPanel value="3">
            <TopInfo />
            <NormalizationTab />
            <SubmitAndReview />
          </TabPanel>
        </TabContext>
      </div>
    </ValidatorContext.Provider>
  );
}
export default Create;
