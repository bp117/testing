import {
    DEFAULTS
} from '../../utils/defaults';


const Normalization = (state = JSON.parse(JSON.stringify(DEFAULTS.Normalization)), action) => {
    switch (action.type) {
        case "NormalizationFormAdded":
            return action.payload
            break;
        case "NormalizationDataChanged":
            state.map((item) => {
                if (item.id === action.payload.id) {
                    item[action.payload.name] = action.payload.inputValue
                }

            })
            return state
            break;
        case "NORMALIZATIONDATAFOUNDFROMYAML":
            return action.payload
            break;
        default:
            return state
            break;
    }
}
export default Normalization