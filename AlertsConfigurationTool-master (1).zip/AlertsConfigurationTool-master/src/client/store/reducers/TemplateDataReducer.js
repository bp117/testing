import {
    DEFAULTS
} from '../../utils/defaults';


const TemplateData = (state = JSON.parse(JSON.stringify(DEFAULTS.TemplateData)), action) => {
    switch (action.type) {
        case "TemplateDataChanged":
            const {payload} = action;
            const newObj = {
                ...state[payload.type],
                [payload.name]: payload.inputValue
            };
            return { ...state, [payload.type]: {...newObj} }
            break;
        case "MassTemplateDataChanged":
            const data = state[action.payload.type];
            const obj = {};
            Object.keys(state).forEach(el => {
                obj[el] = {...data};
            });
            return obj;
        case "TEMPLATEDATAFOUNDFROMYAML":
            return action.payload
            break;
        default:
            return state
            break;
    }

}
export default TemplateData