import {
    DEFAULTS
} from '../../utils/defaults';

const BasicData = (state = {
    ...DEFAULTS.BasicData
}, action) => {
    switch (action.type) {
        case "BasicDataChanged":
            return { ...state, [action.payload.name]: action.payload.inputValue }
            break;
        case "BASICDATAFOUNDFROMYAML":
            return action.payload
            break;
        default:
            return state
            break;
    }

}
export default BasicData