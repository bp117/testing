const NON_EMPTY_NUMBERS = /^[0-9]+$/;

const NON_EMPTY_NUMBERS_VALIDATIONS = [
    {
        handler: (val) => val.length > 0,
        message: 'This field can not be empty'
    },
    {
        handler: (val) => val.match(NON_EMPTY_NUMBERS),
        message: 'This is a numeric field'
    }
];

export const VALIDATORS = {
    MessageTypeID: [...NON_EMPTY_NUMBERS_VALIDATIONS],
    SORApplicationID: [...NON_EMPTY_NUMBERS_VALIDATIONS],
    MessageIdentifier: [...NON_EMPTY_NUMBERS_VALIDATIONS],
    TemplateID:[...NON_EMPTY_NUMBERS_VALIDATIONS],
    XSLTTemplateID:[...NON_EMPTY_NUMBERS_VALIDATIONS],
    order:[...NON_EMPTY_NUMBERS_VALIDATIONS],
}