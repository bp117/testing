import React, { Suspense } from "react";
import { Router, Switch, Route } from "react-router-dom";
import Loader from "../components/Loader/index";
import history from './History';
import Inbox from '../inbox';
import Create from '../create';
import { NotFound } from '../not_found';
const Routes = (
  <Suspense fallback={<div className="mt-100"><Loader /></div>}>
    <Router history={history}>
      <Switch>
        <Route path="/" exact>
          <Inbox />
        </Route>
        <Route path="/inbox" exact>
          <Inbox />
        </Route>
        <Route path="/create" exact>
          <Create />
        </Route>
        
        <NotFound path="**" title="This page doesn't exist..." exact />
      </Switch>
    </Router>
  </Suspense>
);

export default Routes;
