import React from 'react';
import {
    TextField
} from '@material-ui/core';
import ValidatorContext from '../../context/ValidatorContext';
import { VALIDATORS } from '../../utils/validators';
const OverriddenTextField = (props) => {
    const {isValidateForm} = React.useContext(ValidatorContext);
    const value = props.value;
    const [isDirty, setIsDirty] = React.useState(!!props.value);
    let helperText = "";
    if(isDirty || isValidateForm){
        if(VALIDATORS[props.name]){
            // Validation rules to be picked from validators.js
            const rules = VALIDATORS[props.name];
            if(Array.isArray(rules)){
                for(let index = 0; index < rules.length; index++){
                    if(!rules[index].handler(value)){
                        helperText = rules[index].message;
                        break;
                    }
                }
            }
        }
        else{
            // Do the usual validations
            if(value.length === 0){
                helperText = "This field can not be empty";
            }
            else if(value.length < 3) {
                helperText = "Minimum length should be 3";
            }
            else if(value.length > 20 ){
                helperText = "Maximum length should be 20";
            }
            else {
                helperText = "";
            }
        }
    }
    else {
        helperText = "";
    }
    return (
        <TextField 
            {...props}
            error = {helperText !== ""}
            onKeyUp={() => setIsDirty(true)}
            helperText={helperText}
        />
    )
}

export default OverriddenTextField;