import { PluginInitializerContext } from '../../../src/core/server';
import { BacktracerPlugin } from './plugin';

//  This exports static code and TypeScript types,
//  as well as, Kibana Platform `plugin()` initializer.

export function plugin(initializerContext: PluginInitializerContext) {
  return new BacktracerPlugin(initializerContext);
}

export { BacktracerPluginSetup, BacktracerPluginStart } from './types';
