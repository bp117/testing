// eslint-disable-next-line @typescript-eslint/no-empty-interface
export interface BacktracerPluginSetup {}
// eslint-disable-next-line @typescript-eslint/no-empty-interface
export interface BacktracerPluginStart {}
