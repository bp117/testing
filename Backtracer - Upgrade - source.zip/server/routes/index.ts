import { IRouter, RequestHandlerContext } from '../../../../src/core/server';
import { schema } from '@kbn/config-schema';
import { formatUrl, APM_INDEX_URL, ES_SCROLL_DELETE_URL, ES_SCROLL_POST_URL } from '../../common';

async function _fetchData(context: RequestHandlerContext, query: { [key: string]: any }, index: string, isAggregatedQuery: boolean) {
    let completeData: { [key: string]: any }[] = [];
    let size = isAggregatedQuery ? 5 : 10000, scrollId = "";

    const getTheData = async (url: string, body: { [key: string]: any }) => {
        // let resp = await callWithRequest(request, "transport.request", { path: url, index, body })
        const { transport } = context.core.elasticsearch.client.asCurrentUser;
        let { body: resp } = await transport.request({ path: url, body, method: "get" });

        scrollId = resp._scroll_id;
        if (isAggregatedQuery) {
            // scrollId &&  callWithRequest(request, "transport.request", { path: formatUrl(ES_SCROLL_DELETE_URL, null, { scrollId }), method: "DELETE" })
            const query = { path: formatUrl(ES_SCROLL_DELETE_URL, null, { scrollId }), method: "delete" };
            scrollId && transport.request(query)
            console.log("RESPONSE TO SEND IS ", resp)
            return resp;
        }

        if (resp.hits.hits.length) {
            const data = await getTheData(ES_SCROLL_POST_URL, {
                scroll_id: scrollId,
                scroll: "15m"
            });
            completeData.push(data);
        } else if (scrollId) {
            const query = { path: formatUrl(ES_SCROLL_DELETE_URL, null, { scrollId }), method: "delete" }
            transport.request(query)
        }
        return {}
    }

    return (await getTheData(formatUrl(APM_INDEX_URL, { scroll: "30s" }, { index }), { ...query, size })) || completeData;
}



export function defineRoutes(router: IRouter) {
    router.get(
        {
            path: '/api/backtracer/example',
            validate: false
        },
        router.handleLegacyErrors(
            async (context, request, response) => {
                return response.ok({
                    body: {
                        time: new Date().toISOString(),
                    },
                });
            }
        )
    );

    // const { callWithRequest } = server.plugins.elasticsearch.getCluster("data");
    // return callWithRequest(request, "transport.request", { path: "/_aliases" });
    router.post({
        path: "/backtracer/es-indexes",
        validate: false
    }, router.handleLegacyErrors(async (context, req, res) => {
        const query = { path: "/_aliases", method: "get" };
        const { body: results } = await context.core.elasticsearch.client.asCurrentUser.transport.request(query);

        return res.ok({
            body: results
        })

    }));

    router.post({
        path: "/backtracer/es-query",
        validate: {
            body: schema.object({
                query: schema.any(),
                index: schema.string(),
                isAggregatedQuery: schema.boolean(),
                // connectionId: schema.string()
            }),
        },
        options: { body: { parse: true } },
        // validate: false
    }, router.handleLegacyErrors(async (context, req, res) => {
        const { query, index, isAggregatedQuery } = req.body as any;
        try {
            // if(!reqServerUtils.isServerRunning())
            // reqServerUtils.startServer()
            let responseData: string | { [key: string]: any };
            if (isAggregatedQuery) {
                responseData = await _fetchData(context, query, index, true)
            } else {
                responseData = await _fetchData(context, query, index, false)
            }
            return res.ok({
                body: responseData
            })
        } catch (err) {
            return res.internalError({ body: `${err}` })
        }
    }));

    router.post({
        path: "/backtracer/es-scroll-delete",
        options: { body: { parse: true, maxBytes: 200 * 1024 * 1024 } },
        // validate: {
        //     body: schema.object({
        //         url: schema.string(),
        //     }),
        // }
        validate: false
    }, router.handleLegacyErrors(async (context, req, res) => {
        const { url } = req.body as any;
        const query = { path: url, method: "delete" };
        const { body: results } = await context.core.elasticsearch.client.asCurrentUser.transport.request(query);

        return res.ok({
            body: results
        })
    }))
}
