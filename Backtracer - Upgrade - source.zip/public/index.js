import './index.scss';

import { BacktracerPlugin } from './plugin';

// This exports static code and TypeScript types,
// as well as, Kibana Platform `plugin()` initializer.
export function plugin() {
  return new BacktracerPlugin();
}
console.log('\n\n\nPLUGIN INITIALIZATION\n\n\n');
export { BacktracerPluginSetup, BacktracerPluginStart } from './types';
