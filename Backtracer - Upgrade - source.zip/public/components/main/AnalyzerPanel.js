import React from 'react';
import ReactDOM from 'react-dom';
import { Block, FlexBlock, SuperDatePicker } from '../utils';
import {
  EuiButton,
  EuiFieldSearch,
  EuiSelectableList,
  EuiDatePicker,
  EuiOverlayMask,
  EuiConfirmModal,
  EuiLoadingChart,
  EuiSuggest,
  EuiSuperDatePicker,
} from '@elastic/eui';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import * as actions from '../../actions/index';
import moment from 'moment';
import { EuiIcon } from '@elastic/eui';
import { UNIQUE_COLORS } from '../../constants/colors';
import { EuiFieldText } from '@elastic/eui';
import { displayImpactGraph, displayBacktraceGraph } from './graphDisplayType';
import { CopyIcon } from './ErrorTypePanel';

function mapStateToProps(state) {
  return {
    traceDataMap: state.err_data.traceDataMap,
    serviceTraceListMap: state.app_data.serviceTraceListMap,
    indices: state.es_indices.data,
  };
}

function mapDispatchToProps(dispatch) {
  return bindActionCreators(actions, dispatch);
}

const Loader = ({ text }) => (
  <React.Fragment>
    <EuiLoadingChart size="xl" />
    <div style={{ marginTop: 10, color: '#E65100' }}>{text}</div>
  </React.Fragment>
);

class AnalyzerView extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      index: '',
      serviceName: '',
      startDatetime: moment().toISOString(),
      endDatetime: moment().toISOString(),
      error: '',
    };
    let traceColors = this._processData(props.serviceTraceListMap);
    this.state.traceColors = traceColors;
    this.backtraceViewRef = React.createRef();
    this.nullCompRef = React.createRef();
  }

  handleFetchData = (validateFields = true) => {
    if (!this.state.index) {
      if (!validateFields) return;
      return this.setState({ validationError: 'Please provide an index for the operation' });
    }
    if (!this.state.startDatetime || !this.state.endDatetime) {
      if (!validateFields) return;
      return this.setState({ validationError: 'Please provide a valid date-time range' });
    }
    if (!this.state.serviceName) {
      if (!validateFields) return;
      return this.setState({ validationError: 'Please provide a service name for the operation' });
    }
    this.setState({ error: null }, () => {
      const { index, serviceName, startDatetime, endDatetime } = this.state;
      this.setState({ loadingData: true });
      this.props.fetchAppData(
        index,
        serviceName,
        { from: startDatetime, to: endDatetime },
        (success, err) => {
          this.setState({ loadingData: false });
          if (!success) {
            let errorMsg =
              (((err.error || {}).root_cause || [])[0] || {}).reason || `${err}` || 'Unknown error';
            this.setState({ error: errorMsg });
          } else {
            // console.log("DATA ", err);
          }
        }
      );
    });
  };
  _processData = (serviceTraceListMap = {}) => {
    let traces = serviceTraceListMap[this.state.serviceName] || [],
      traceColors = {};

    traces.forEach((traceId, ind) => {
      traceColors[traceId] = UNIQUE_COLORS[ind];
    });
    return { traceColors };
  };
  handleTraceItemSelected = (traceId) => {
    this.setState({ selectedItem: traceId, errorLevel2: null, loadingGraph: true }, () => {
      let { serviceName, traceColors } = this.state;
      let traces = this.props.serviceTraceListMap[this.state.serviceName] || [];

      if (traceId == 'ALL_TRACES') {
        displayImpactGraph(
          serviceName,
          traces,
          traceColors,
          this.backtraceViewRef,
          true,
          (node) => true,
          (err) => {
            this.setState({ errorLevel2: err });
          },
          this.handleTraceItemSelected,
          () => this.setState({ loadingGraph: false })
        );
      } else {
        let traceData = this.props.traceDataMap[traceId];
        if (traceData) {
          displayBacktraceGraph(
            serviceName,
            traceData,
            traceColors,
            this.backtraceViewRef,
            (err) => {
              this.setState({ errorLevel2: err });
            },
            () => this.setState({ loadingGraph: false })
          );
        } else {
          this.props.fetchErrorTabTraceIdData(this.state.index, [traceId], (success, respData) => {
            if (success) {
              let traceData = this.props.traceDataMap[traceId];
              displayBacktraceGraph(
                serviceName,
                traceData,
                traceColors,
                this.backtraceViewRef,
                (err) => {
                  this.setState({ errorLevel2: err });
                },
                () => this.setState({ loadingGraph: false })
              );
            }
          });
        }
      }
    });
  };
  _filterIndexAutoComplete = () => {
    let text = this.state.index;
    let d = this.props.indices.filter(
      (t) => !text || t.toLowerCase().startsWith(text.toLowerCase())
    );
    return d.map((t) => ({
      label: t,
      description: '',
      type: { iconType: 'search', color: 'tint8' },
    }));
  };
  componentWillReceiveProps(props) {
    this.setState(
      {
        ...this._processData(props.serviceTraceListMap),
        selectedItem: this.state.selectedItem ? this.state.selectedItem : 'ALL_TRACES',
      },
      () => {
        this.handleTraceItemSelected(this.state.selectedItem);
      }
    );
  }
  componentDidMount() {
    this.props.fetchAllIndices();
  }
  render() {
    const { serviceTraceListMap } = this.props;
    const serviceTraces = serviceTraceListMap[this.state.serviceName] || [];
    return (
      <FlexBlock matchParent column>
        <Block>
          <FlexBlock alignCenter>
            <div style={{ marginRight: 20, flex: 1, maxWidth: 400 }}>
              <EuiSuggest
                suggestions={this._filterIndexAutoComplete()}
                value={this.state.index}
                onItemClick={(item) => {
                  this.setState({ index: item.label });
                  this.nullCompRef.current.click();
                }}
                placeholder="Index (required)"
                onInputChange={(e) => {
                  this.setState({ index: e.value });
                }}
              />
            </div>
            <div style={{ marginRight: 20, flex: 1, maxWidth: 400 }}>
              <EuiFieldText
                placeholder="Service Name (required)"
                onChange={(e) => {
                  this.setState({ serviceName: e.target.value });
                }}
              />
            </div>
            <div style={{ marginRight: 20, flex: 1, maxWidth: 450 }}>
              <SuperDatePicker
                isCustom={false}
                onTimeChange={(p) => this.setState({ endDatetime: p.end, startDatetime: p.start })}
                end={this.state.endDatetime}
                start={this.state.startDatetime}
                adjustDateOnChange={true}
                showTimeSelect={true}
                dateFormat="MMM D, YYYY @ HH:mm"
                refreshDataCallback={() => this.handleFetchData(false)}
                showUpdateButton={false}
              />
            </div>
            <EuiButton onClick={this.handleFetchData}> Search </EuiButton>
          </FlexBlock>
          <hr className="hr-divider" />
        </Block>
        {this.state.loadingData ? (
          <FlexBlock alignCenter justifyCenter matchParent column>
            <EuiLoadingChart size="xl" />
            <div style={{ marginTop: 10 }}>Loading Data...</div>
          </FlexBlock>
        ) : this.state.error ? (
          <Block matchParent>
            <FlexBlock alignCenter justifyCenter matchParent column>
              <EuiIcon type="faceSad" color="#BF360C" size="xl" />
              <h2 style={{ fontSize: 30, fontWeight: 'bold', color: '#BF360C' }}>Oops!</h2>
              <h4 style={{ color: '#1565C0', marginTop: 10 }}>{this.state.error}</h4>
            </FlexBlock>
          </Block>
        ) : serviceTraces.length ? (
          <FlexBlock flexOne>
            <div className="--list">
              <div className="--list-heading">All Trace IDs</div>
              <div style={{ marginTop: 10 }} className="--list-body">
                <div style={{ marginTop: 10 }} className="--list-body-content">
                  {serviceTraces.map((item) => (
                    <div
                      style={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                      }}
                    >
                      <div
                        key={item}
                        className={`--list-item ${this.state.selectedItem == item ? 'active' : ''}`}
                        onClick={() => this.handleTraceItemSelected(item)}
                        style={{ color: this.state.traceColors[item], flex: 1 }}
                      >
                        {item}
                      </div>
                      <CopyIcon text={item} />
                    </div>
                  ))}
                </div>
              </div>
            </div>
            <FlexBlock flexOne matchParent column style={{ position: 'relative' }}>
              {this.state.selectedItem != 'ALL_TRACES' && (
                <div style={{ position: 'absolute', top: 0, left: 50 }}>
                  <EuiButton
                    iconType="arrowLeft"
                    size="s"
                    fill
                    onClick={() => this.handleTraceItemSelected('ALL_TRACES')}
                  >
                    BACK
                  </EuiButton>
                </div>
              )}
              {this.state.errorLevel2 ? (
                <Block matchParent>
                  <FlexBlock alignCenter justifyCenter matchParent column>
                    <EuiIcon type="faceSad" color="#BF360C" size="xl" />
                    <h2 style={{ fontSize: 30, fontWeight: 'bold', color: '#BF360C' }}>Oops!</h2>
                    <h4 style={{ color: '#1565C0', marginTop: 10 }}>{this.state.errorLevel2}</h4>
                  </FlexBlock>
                </Block>
              ) : this.state.selectedItem ? (
                <React.Fragment>
                  {this.state.loadingGraph && (
                    <div
                      style={{
                        position: 'absolute',
                        top: 0,
                        left: 0,
                        bottom: 0,
                        right: 0,
                        display: 'flex',
                        flexDirection: 'column',
                        alignItems: 'center',
                        justifyContent: 'center',
                      }}
                    >
                      <Loader text="Loading Graph..." />
                    </div>
                  )}
                  <div style={{ width: '100%', flex: 1 }} ref={this.backtraceViewRef}></div>
                </React.Fragment>
              ) : (
                <Block matchParent>
                  <FlexBlock alignCenter justifyCenter matchParent column>
                    <h2 style={{ fontSize: 18, fontWeight: 'bold' }}>Nothing to compute!</h2>
                    <h4 style={{ color: '#1565C0', marginTop: 10 }}>
                      Select a transaction to view it's backward trace
                    </h4>
                  </FlexBlock>
                </Block>
              )}
              {this.state.selectedItem != 'ALL_TRACES' && (
                <div
                  style={{ marginTop: 15, display: 'flex', alignItems: 'center', marginLeft: 50 }}
                >
                  <div style={{ marginRight: 30, display: 'flex', alignItems: 'center' }}>
                    <div
                      style={{
                        display: 'inline-block',
                        width: 50,
                        height: 20,
                        background: '#4E342E',
                        marginRight: 10,
                      }}
                    />
                    <span style={{ color: '#4E342E' }}>Child</span>
                  </div>
                  <div style={{ marginRight: 30, display: 'flex', alignItems: 'center' }}>
                    <div
                      style={{
                        display: 'inline-block',
                        width: 50,
                        height: 20,
                        background: '#1565C0',
                        marginRight: 10,
                      }}
                    />
                    <span style={{ color: '#1565C0' }}>Parent</span>
                  </div>
                </div>
              )}
            </FlexBlock>
          </FlexBlock>
        ) : (
          <Block matchParent>
            <FlexBlock alignCenter justifyCenter matchParent column>
              <h2 style={{ fontSize: 18, fontWeight: 'bold' }}>Nothing to process!</h2>
              <h4 style={{ color: '#1565C0', marginTop: 10 }}>
                Enter the index, service name and datetime range to view all traces
              </h4>
            </FlexBlock>
          </Block>
        )}

        <div ref={this.nullCompRef} />
        {this.state.validationError && (
          <EuiOverlayMask>
            <EuiConfirmModal
              title="Validation Error"
              onCancel={() => this.setState({ validationError: null })}
              onConfirm={() => this.setState({ validationError: null })}
              confirmButtonText="OK"
            >
              {this.state.validationError}
            </EuiConfirmModal>
          </EuiOverlayMask>
        )}
      </FlexBlock>
    );
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(AnalyzerView);
