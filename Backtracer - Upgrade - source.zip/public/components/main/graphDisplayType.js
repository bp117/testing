import ReactDOM from "react-dom";
import { UNIQUE_COLORS } from "../../constants/colors";
import { constructServiceDepPath, constructBacktracePath } from "../../actions/dataCrunch";
import D3GraphManager from "./graphManager";
import { getAppStore } from "../../store/store_provider";

function _getTransactionIds(traceData, serviceName){
    traceData = traceData || [];
    let transactions = traceData.filter(t => (t["service.name"] == serviceName && t["transaction.id"]) ) || [];
    let transactionIds = []; 
    transactions.forEach(t=>{
        if(!transactionIds.find(t2=>t2["transaction.id"]===t["transaction.id"])){
            transactionIds.push(t["transaction.id"]);
        }
    });

    return [...new Set(transactionIds)];
}

function processBGraphData(serviceName, traceData, traceColors, onError=()=>{}){
    let solutionPath = {};
    let transactionIds = _getTransactionIds(traceData, serviceName);
    
    if(transactionIds.length){
        solutionPath = constructBacktracePath(traceData, transactionIds);
    }
    else {
        onError("Service name does not exist or have a corresponding transaction id in the trace.")
    }
    
    let {nodes, links} = solutionPath;
    if(nodes && nodes.length){
        let colorCount = Object.keys(traceColors||{}).length;
        nodes = nodes.map(node=>{
            if(!node["node.color"]){
                node["node.color"] = UNIQUE_COLORS[(colorCount++)%UNIQUE_COLORS.length];
            }
            return node;
        });
    }
    return {nodes, links};
}

function processServiceGraphData(serviceName, traces, traceColors, includeSelfCalls, countTracePredicate, onComplete=()=>{}){
    constructServiceDepPath(traces, serviceName, traceColors, countTracePredicate, ({nodes, links})=>{
        if(nodes && nodes.length){
            let colorCount = Object.keys(traceColors||{}).length;
            nodes = nodes.map(node=>{
                if(!node["node.color"]){
                    node["node.color"] = UNIQUE_COLORS[(colorCount++)%UNIQUE_COLORS.length];
                }
                if(includeSelfCalls){
                    traces.forEach(traceId=>{
                        let traceData = getAppStore().getState().err_data.traceDataMap[traceId];
                        let transactionIds = _getTransactionIds(traceData, node["service.name"]);
        
                        if(transactionIds.length>1){
                            node.traces = [...(node.traces||[]), ...(Array(transactionIds.length-1).fill("0"))];
                            links.push({source:node, target:node});
                        }
                    });
                }
                return node;
            });
        }
        onComplete({nodes, links});
    });
    
}

function _displayGraph(mountNodeRef, nodes, links, traceColors, graphType, onTraceIdSelected, _attemptCount=0, onGraphLoaded=()=>{}){
    let mountNode = ReactDOM.findDOMNode(mountNodeRef.current);
    if(mountNode){
        mountNode.innerHTML = "";
        let dagreManager = new D3GraphManager(mountNode, nodes, links, graphType, onTraceIdSelected, onGraphLoaded);
        dagreManager.setTraceColors(traceColors);
        dagreManager.drawGraph();
    } else if(_attemptCount<10) {
        setTimeout(() => {
            _displayGraph(mountNodeRef, nodes, links, traceColors, graphType, onTraceIdSelected, ++_attemptCount, onGraphLoaded);
        }, 250);
    }
}

export function displayImpactGraph(serviceName, traces, traceColors, mountNodeRef, includeSelfCalls=true, countTracePredicate=()=>true, onError=()=>{}, onTraceIdSelected, onGraphLoaded=()=>{}){
    new Promise((resolve)=>{
        processServiceGraphData(serviceName, traces, traceColors, includeSelfCalls, countTracePredicate, ({nodes, links})=>{
            resolve({nodes, links});
        });
    })
    .then(({links, nodes})=>{
        if(nodes && nodes.length){
            if(!links.length){
                links.push({source: nodes[0], target:nodes[0]});
            }
            onTraceIdSelected = onTraceIdSelected? onTraceIdSelected : (traceId)=>displayBacktraceGraph(serviceName, traceId, traces, traceColors, mountNodeRef, onError=()=>{}, onGraphLoaded);
            _displayGraph(mountNodeRef, nodes, links, traceColors, "ANALYZER", onTraceIdSelected, 0, onGraphLoaded);
        }
    });
}

export function displayBacktraceGraph(serviceName, traceData, traceColors, mountNodeRef, onError=()=>{}, onGraphLoaded=()=>{}){
    new Promise((resolve)=>{
        let {nodes, links} = processBGraphData(serviceName, traceData, traceColors, onError);
        resolve({nodes, links});
    })
    .then(({nodes, links})=>{
        if(nodes && nodes.length){
            _displayGraph(mountNodeRef, nodes, links, traceColors, "", null, 0, onGraphLoaded);
        }
    })
}
