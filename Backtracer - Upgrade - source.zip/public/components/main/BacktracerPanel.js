import React from 'react';
import ReactDOM from 'react-dom';
import { Block, FlexBlock } from '../utils';
import {
  EuiButton,
  EuiFieldSearch,
  EuiIcon,
  EuiLoadingChart,
  EuiSelectableList,
  EuiFieldText,
  EuiOverlayMask,
  EuiConfirmModal,
  EuiSuggest,
} from '@elastic/eui';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import * as actions from '../../actions/index';
import { constructBacktracePath } from '../../actions/dataCrunch';
import D3GraphManager from './graphManager';

function mapStateToProps(state) {
  return {
    rawData: state.bt_data.data,
    indices: state.es_indices.data,
  };
}

function mapDispatchToProps(dispatch) {
  return bindActionCreators(actions, dispatch);
}

const Loader = ({ text }) => (
  <React.Fragment>
    <EuiLoadingChart size="xl" />
    <div style={{ marginTop: 10, color: '#E65100' }}>{text}</div>
  </React.Fragment>
);

class BacktracerView extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      index: '',
      traceId: '',
      error: '',
      ...this._processData(props.rawData),
    };
    this.backtraceViewRef = React.createRef();
  }

  handleFetchData = () => {
    if (!this.state.index) {
      return this.setState({ validationError: 'Please provide an index for the operation' });
    }
    if (!this.state.traceId) {
      return this.setState({ validationError: 'Please provide a trace id for the operation' });
    }
    this.setState({ error: null, loadingData: true }, () => {
      const { index, traceId } = this.state;
      this.props.fetchBtAppData(index, traceId, (success, err) => {
        this.setState({ loadingData: false });

        if (!success) {
          let errorMsg =
            (((err.error || {}).root_cause || [])[0] || {}).reason || `${err}` || 'Unknown error';
          this.setState({ error: errorMsg });
        }
      });
    });
  };
  _processData = (data) => {
    let transactions = [],
      _temp = [];
    if (data) {
      data.forEach((d) => {
        if (!_temp.includes(d['transaction.id'])) {
          _temp.push(d['transaction.id']);
          let transaction = transactions.find((t) => t.name == d['service.name']);
          if (transaction) {
            transaction.ids.push(d['transaction.id']);
          } else {
            transactions.push({ name: d['service.name'], ids: [d['transaction.id']] });
          }
        }
      });
    }
    return { transactions, data };
  };
  _getListBindData = (processedData = {}) => {
    return Object.keys(processedData).map((key) => ({
      label: key,
    }));
  };
  handleTransactionItemSelected = (item) => {
    this.setState({ selectedItem: item.name, loadingGraph: true }, () => {
      new Promise(() => {
        let transactionIds = item.ids;
        let solutionPath = constructBacktracePath(this.state.data, transactionIds);
        let { nodes, links } = solutionPath;
        if (nodes.length) {
          let mountNode = ReactDOM.findDOMNode(this.backtraceViewRef.current);
          mountNode.innerHTML = '';
          let dagreManager = new D3GraphManager(mountNode, nodes, links, '', null, () =>
            this.setState({ loadingGraph: false })
          );
          dagreManager.drawGraph();
        }
      });
    });
  };
  componentWillReceiveProps(props) {
    this.setState({
      ...this._processData(props.rawData),
    });
  }
  _filterIndexAutoComplete = () => {
    let text = this.state.index;
    let d = this.props.indices.filter(
      (t) => !text || t.toLowerCase().startsWith(text.toLowerCase())
    );
    return d.map((t) => ({
      label: t,
      description: '',
      type: { iconType: 'search', color: 'tint8' },
    }));
  };
  componentDidMount() {
    this.props.fetchAllIndices();
  }
  render() {
    return (
      <FlexBlock matchParent column>
        <Block>
          <FlexBlock alignCenter>
            <div style={{ marginRight: 20, flex: 1, maxWidth: 400 }}>
              <EuiSuggest
                suggestions={this._filterIndexAutoComplete()}
                value={this.state.index}
                onItemClick={(item) => {
                  this.setState({ index: item.label });
                }}
                placeholder="Index (required)"
                onInputChange={(e) => {
                  this.setState({ index: e.value });
                }}
              />
            </div>
            <div style={{ marginRight: 20, flex: 1, maxWidth: 400 }}>
              <EuiFieldText
                placeholder="TraceId (required)"
                onChange={(e) => {
                  this.setState({ traceId: e.target.value });
                }}
              />
            </div>
            <EuiButton onClick={this.handleFetchData}> Search </EuiButton>
          </FlexBlock>
          <hr className="hr-divider" />
        </Block>
        {this.state.loadingData ? (
          <FlexBlock alignCenter justifyCenter matchParent column>
            <Loader text="Loading Data..." />
          </FlexBlock>
        ) : this.state.error ? (
          <Block matchParent>
            <FlexBlock alignCenter justifyCenter matchParent column>
              <EuiIcon type="faceSad" color="#BF360C" size="xl" />
              <h2 style={{ fontSize: 30, fontWeight: 'bold', color: '#BF360C' }}>Oops!</h2>
              <h4 style={{ color: '#1565C0', marginTop: 10 }}>{this.state.error}</h4>
            </FlexBlock>
          </Block>
        ) : this.state.transactions.length ? (
          <FlexBlock flexOne>
            <div className="--list">
              <div className="--list-heading">All Transactions</div>
              <div style={{ marginTop: 10 }} className="--list-body">
                <div style={{ marginTop: 10 }} className="--list-body-content">
                  {this.state.transactions.map((item) => (
                    <div
                      className={`--list-item ${
                        this.state.selectedItem == item.name ? 'active' : ''
                      }`}
                      onClick={() => this.handleTransactionItemSelected(item)}
                    >
                      {item.name}
                    </div>
                  ))}
                </div>
              </div>
            </div>
            <FlexBlock flexOne matchParent column>
              {this.state.selectedItem ? (
                <React.Fragment>
                  {this.state.loadingGraph && (
                    <div
                      style={{
                        position: 'absolute',
                        top: 0,
                        left: 0,
                        bottom: 0,
                        right: 0,
                        display: 'flex',
                        flexDirection: 'column',
                        alignItems: 'center',
                        justifyContent: 'center',
                      }}
                    >
                      <Loader text="Loading Graph..." />
                    </div>
                  )}
                  <div style={{ width: '100%', flex: 1 }} ref={this.backtraceViewRef} />
                </React.Fragment>
              ) : (
                <Block matchParent>
                  <FlexBlock alignCenter justifyCenter matchParent column>
                    <h2 style={{ fontSize: 18, fontWeight: 'bold' }}>Nothing to compute!</h2>
                    <h4 style={{ color: '#1565C0', marginTop: 10 }}>
                      Select a transaction to view it's backward trace
                    </h4>
                  </FlexBlock>
                </Block>
              )}
              <div style={{ marginTop: 15, display: 'flex', alignItems: 'center', marginLeft: 50 }}>
                <div style={{ marginRight: 30, display: 'flex', alignItems: 'center' }}>
                  <div
                    style={{
                      display: 'inline-block',
                      width: 50,
                      height: 20,
                      background: '#4E342E',
                      marginRight: 10,
                    }}
                  />
                  <span style={{ color: '#4E342E' }}>Child</span>
                </div>
                <div style={{ marginRight: 30, display: 'flex', alignItems: 'center' }}>
                  <div
                    style={{
                      display: 'inline-block',
                      width: 50,
                      height: 20,
                      background: '#1565C0',
                      marginRight: 10,
                    }}
                  />
                  <span style={{ color: '#1565C0' }}>Parent</span>
                </div>
              </div>
            </FlexBlock>
          </FlexBlock>
        ) : (
          <Block matchParent>
            <FlexBlock alignCenter justifyCenter matchParent column>
              <h2 style={{ fontSize: 18, fontWeight: 'bold' }}>Nothing to process!</h2>
              <h4 style={{ color: '#1565C0', marginTop: 10 }}>
                Enter the index and trace id to view all transactions
              </h4>
            </FlexBlock>
          </Block>
        )}
        {this.state.validationError && (
          <EuiOverlayMask>
            <EuiConfirmModal
              title="Validation Error"
              onCancel={() => this.setState({ validationError: null })}
              onConfirm={() => this.setState({ validationError: null })}
              confirmButtonText="OK"
            >
              {this.state.validationError}
            </EuiConfirmModal>
          </EuiOverlayMask>
        )}
      </FlexBlock>
    );
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(BacktracerView);
