import React from 'react';
import {
  EuiPage,
  EuiPageHeader,
  EuiTitle,
  EuiPageBody,
  EuiPageContent,
  EuiPageContentHeader,
  EuiPageContentBody,
  EuiText,
  EuiTab,
  EuiTabs,
} from '@elastic/eui';
import BacktracerPanel from './BacktracerPanel';
import AnalyzerPanel from './AnalyzerPanel';
import { Block } from '../utils';
import ErrorTypeView from './ErrorTypePanel';

export class Main extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      tabs: [
        {
          id: 'ANALYZER',
          name: 'BY SERVICE NAME',
        },
        {
          id: 'BACKTRACER',
          name: 'BY TRACE ID',
        },
        {
          id: 'ERROR_ANALYSIS',
          name: 'BY ERROR TYPE',
        },
      ],
      selectedTab: localStorage.getItem('CRT_ACT_TB') || 'BACKTRACER',
    };
  }

  onSelectedTabChanged = (tab) => {
    this.setState({ selectedTab: tab.id });
    localStorage.setItem('CRT_ACT_TB', tab.id);
  };
  render() {
    const { basename, notifications, http, navigation } = this.props;
    return (
      <EuiPage style={{ flex: 1 }}>
        <EuiPageBody>
          <EuiPageContent>
            <Block style={{ marginTop: -15 }}>
              <EuiTabs display="condensed">
                {this.state.tabs.map((tab, index) => (
                  <EuiTab
                    key={tab.id}
                    onClick={() => this.onSelectedTabChanged(tab)}
                    isSelected={this.state.selectedTab == tab.id}
                  >
                    {tab.name}
                  </EuiTab>
                ))}
              </EuiTabs>
            </Block>
            <EuiPageContentBody style={{ height: '100%' }}>
              <Block matchParent style={{ paddingTop: 15, paddingBottom: 10 }}>
                <Block
                  matchParent
                  style={{ display: this.state.selectedTab == 'ANALYZER' ? 'block' : 'none' }}
                >
                  <AnalyzerPanel />
                </Block>
                <Block
                  matchParent
                  style={{ display: this.state.selectedTab == 'BACKTRACER' ? 'block' : 'none' }}
                >
                  <BacktracerPanel />
                </Block>
                <Block
                  matchParent
                  style={{ display: this.state.selectedTab == 'ERROR_ANALYSIS' ? 'block' : 'none' }}
                >
                  <ErrorTypeView />
                </Block>
              </Block>
            </EuiPageContentBody>
          </EuiPageContent>
        </EuiPageBody>
      </EuiPage>
    );
  }
}
