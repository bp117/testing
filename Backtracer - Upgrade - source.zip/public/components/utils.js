import React, { useState, Fragment } from 'react';

import { EuiSuperDatePicker } from '@elastic/eui';

export const FlexBlock = ({
  column,
  justifyCenter,
  justifyContent,
  alignCenter,
  alignItems,
  children,
  matchParent,
  flexOne,
  flex,
  wrap,
  style,
  ...restProps
}) => (
  <div
    style={{
      display: 'flex',
      flexDirection: column ? 'column' : 'row',
      justifyContent: justifyCenter ? 'center' : justifyContent,
      alignItems: alignCenter ? 'center' : alignItems,
      flex: flexOne ? 1 : flex,
      flexWrap: wrap ? 'wrap' : undefined,
      ...(matchParent ? { width: '100%', height: '100%' } : {}),
      ...style,
    }}
    {...restProps}
  >
    {children}
  </div>
);

export const Block = ({ children, flexOne, flex, matchParent, style, ...restProps }) => (
  <div
    style={{
      display: 'block',
      flex: flexOne ? 1 : flex,
      ...(matchParent ? { width: '100%', height: '100%' } : {}),
      ...style,
    }}
    {...restProps}
  >
    {children}
  </div>
);

export const SuperDatePicker = ({ onTimeChange, refreshDataCallback, ...props }) => {
  const [recentlyUsedRanges, setRecentlyUsedRanges] = useState([]);
  const [isPaused, setIsPaused] = useState(true);
  const [refreshInterval, setRefreshInterval] = useState();

  const handleTimeChange = ({ start, end }) => {
    const recentlyUsedRange = recentlyUsedRanges.filter((recentlyUsedRange) => {
      const isDuplicate = recentlyUsedRange.start === start && recentlyUsedRange.end === end;
      return !isDuplicate;
    });
    recentlyUsedRange.unshift({ start, end });
    onTimeChange({ start, end });
    setRecentlyUsedRanges(
      recentlyUsedRange.length > 10 ? recentlyUsedRange.slice(0, 9) : recentlyUsedRange
    );
  };

  const onRefresh = ({ start, end, refreshInterval }) => {
    refreshDataCallback();
  };

  const onRefreshChange = ({ isPaused, refreshInterval }) => {
    setIsPaused(isPaused);
    setRefreshInterval(refreshInterval);
  };

  return (
    <EuiSuperDatePicker
      onTimeChange={handleTimeChange}
      recentlyUsedRanges={recentlyUsedRanges}
      onRefresh={onRefresh}
      isPaused={isPaused}
      refreshInterval={refreshInterval}
      onRefreshChange={onRefreshChange}
      {...props}
    />
  );
};
