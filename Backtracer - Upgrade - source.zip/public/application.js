import React from 'react';
import ReactDOM from 'react-dom';
import { AppMountParameters, CoreStart } from '../../../src/core/public';
import { AppPluginStartDependencies } from './types';
import { Main } from './components/main';

import createAppStore from './store/store_config';
import { initStoreProvider } from './store/store_provider';
import { Provider } from 'react-redux';
import { initCore, initHTTPClient } from './actions';
import './app.scss';

const store = createAppStore({});
initStoreProvider(store);

export const renderApp = (
  { notifications, http },
  { navigation },
  { appBasePath, element },
  core
) => {
  initCore(core);
  initHTTPClient(http);

  ReactDOM.render(
    <Provider store={store}>
      <Main
        basename={appBasePath}
        fake={console.log('THE MAIN COMPONENT WAS RENDERED')}
        notifications={notifications}
        http={http}
        navigation={navigation}
      />
    </Provider>,
    element
  );

  return () => ReactDOM.unmountComponentAtNode(element);
};
