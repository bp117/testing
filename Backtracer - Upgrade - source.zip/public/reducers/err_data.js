import { createReducer } from "../utils/misc";
import { 
    FETCH_ERROR_DATA_REQUEST,
    FETCH_ERROR_DATA_SUCCESS,
    FETCH_ERROR_DATA_FAILURE,
    FETCH_ERR_SERVICES_AGG_DATA_REQUEST,
    FETCH_ERR_SERVICES_AGG_DATA_SUCCESS,
    FETCH_ERR_SERVICES_AGG_DATA_FAILURE,
    FETCH_THIS_SERVICE_AGG_DATA_SUCCESS,
    FETCH_THIS_SERVICE_AGG_DATA_REQUEST,
    FETCH_THIS_SERVICE_AGG_DATA_FAILURE,
    FETCH_THIS_EXCEPTION_AGG_DATA_REQUEST,
    FETCH_THIS_EXCEPTION_AGG_DATA_FAILURE,
    FETCH_THIS_EXCEPTION_AGG_DATA_SUCCESS,
    FETCH_ERR_TRACE_ID_DATA_REQUEST,
    FETCH_ERR_TRACE_ID_DATA_SUCCESS,
    FETCH_ERR_TRACE_ID_DATA_FAILURE,
    FETCH_SERVICE_TRACES_REQUEST,
    FETCH_SERVICE_TRACES_SUCCESS,
    FETCH_SERVICE_TRACES_FAILURE,
    // FETCH_TRACE_ID_DATA_REQUEST,
    // FETCH_TRACE_ID_DATA_SUCCESS,
    // FETCH_TRACE_ID_DATA_FAILURE
} 
from "../constants";

const initialState = {
    isFetchingData: false,
    isLoadedData: false,
    isFetchingServices: false,
    isFetchingTraceIdList: false,
    isLoadedServices: false,
    fetchingServiceAgg: false,
    fetchingExceptionAgg: false,
    fetchingTraceId: false,
    data: [],
    serviceAggs: {},
    exceptionAggs: {},
    serviceMetadata: {},
    traceDataMap: {},
    serviceTraceListMap: {},
};

export default createReducer(initialState, {
    [FETCH_ERROR_DATA_REQUEST]: state => ({
        ...state,
        isFetchingData: true,
        isLoadedData: false
    }),
    [FETCH_ERROR_DATA_SUCCESS]: (state, payload) => ({
        ...state,
        isFetchingData: false,
        isLoadedData: true,
        data: payload
    }),
    [FETCH_ERROR_DATA_FAILURE]: state => ({
        ...state,
        isFetchingData: false,
        isLoadedData: false
    }),

    [FETCH_ERR_SERVICES_AGG_DATA_REQUEST]: state => ({
        ...state,
        isFetchingServices: true,
        isLoadedServices: false
    }),
    [FETCH_ERR_SERVICES_AGG_DATA_SUCCESS]: (state, payload) => ({
        ...state,
        isFetchingServices: false,
        isLoadedServices: true,
        serviceAggs: payload.services,
        serviceMetadata: {...state.serviceMetadata, ...payload.metadata}
    }),
    [FETCH_ERR_SERVICES_AGG_DATA_FAILURE]: state => ({
        ...state,
        isFetchingData: false,
        isLoadedData: false
    }),

    [FETCH_THIS_SERVICE_AGG_DATA_REQUEST]: (state, serviceName) => ({
        ...state,
        fetchingServiceAgg: serviceName
    }),
    [FETCH_THIS_SERVICE_AGG_DATA_SUCCESS]: (state, payload) => ({
        ...state,
        fetchingServiceAgg: false,
        serviceAggs: {...state.serviceAggs, [payload["serviceName"]]: payload.data}
    }),
    [FETCH_THIS_SERVICE_AGG_DATA_FAILURE]: state => ({
        ...state,
        fetchingServiceAgg: false
    }),

    [FETCH_THIS_EXCEPTION_AGG_DATA_REQUEST]: (state, exceptionName) => ({
        ...state,
        fetchingExceptionAgg: exceptionName
    }),
    [FETCH_THIS_EXCEPTION_AGG_DATA_SUCCESS]: (state, payload) => ({
        ...state,
        fetchingExceptionAgg: false,
        exceptionAggs: {...state.exceptionAggs, [payload["exceptionName"]]: payload.data}
    }),
    [FETCH_THIS_EXCEPTION_AGG_DATA_FAILURE]: state => ({
        ...state,
        fetchingExceptionAgg: false
    }),

    [FETCH_ERR_TRACE_ID_DATA_REQUEST]: (state, traceId) => ({
        ...state,
        fetchingTraceId: traceId
    }),
    [FETCH_ERR_TRACE_ID_DATA_SUCCESS]: (state, payload) => ({
        ...state,
        fetchingTraceId: false,
        traceDataMap: {...state.traceDataMap, ...payload}
    }),
    [FETCH_ERR_TRACE_ID_DATA_FAILURE]: state => ({
        ...state,
        fetchingTraceId: false
    }),

    [FETCH_SERVICE_TRACES_REQUEST]: (state) => ({
        ...state,
        isFetchingTraceIdList: true
    }),
    [FETCH_SERVICE_TRACES_SUCCESS]: (state, payload) => ({
        ...state,
        isFetchingTraceIdList: false,
        serviceTraceListMap: {
            ...state.serviceTraceListMap, 
            [payload.serviceName]: [...new Set([
                ...(state.serviceTraceListMap[payload.serviceName]||[]),
                ...payload.data
            ]) ]
        }
    }),
    [FETCH_SERVICE_TRACES_FAILURE]: state => ({
        ...state,
        isFetchingTraceIdList: false
    })
});

