import { createReducer } from "../utils/misc";
import { 
    FETCH_APP_DATA_REQUEST,
    FETCH_APP_DATA_SUCCESS,
    FETCH_APP_DATA_FAILURE
} 
from "../constants";

const initialState = {
    isFetchingData: false,
    isLoadedData: false,
    serviceTraceListMap: {},
    // data: []
};

export default createReducer(initialState, {
    [FETCH_APP_DATA_REQUEST]: state => ({
        ...state,
        isFetchingData: true,
        isLoadedData: false
    }),
    [FETCH_APP_DATA_SUCCESS]: (state, payload) => ({
        ...state,
        isFetchingData: false,
        isLoadedData: true,
        // data: payload,
        serviceTraceListMap: {
            ...state.serviceTraceListMap, 
            [payload.serviceName]: [...new Set([
                ...(state.serviceTraceListMap[payload.serviceName]||[]),
                ...payload.data
            ]) ]
        }
    }),
    [FETCH_APP_DATA_FAILURE]: state => ({
        ...state,
        isFetchingData: false,
        isLoadedData: false
    })
});
