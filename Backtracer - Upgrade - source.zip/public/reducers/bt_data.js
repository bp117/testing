import { createReducer } from "../utils/misc";
import { 
    FETCH_BT_APP_DATA_REQUEST,
    FETCH_BT_APP_DATA_SUCCESS,
    FETCH_BT_APP_DATA_FAILURE
} 
from "../constants";

const initialState = {
    isFetchingData: false,
    isLoadedData: false,
    data: []
};

export default createReducer(initialState, {
    [FETCH_BT_APP_DATA_REQUEST]: state => ({
        ...state,
        isFetchingData: true,
        isLoadedData: false
    }),
    [FETCH_BT_APP_DATA_SUCCESS]: (state, payload) => ({
        ...state,
        isFetchingData: false,
        isLoadedData: true,
        data: payload
    }),
    [FETCH_BT_APP_DATA_FAILURE]: state => ({
        ...state,
        isFetchingData: false,
        isLoadedData: false
    })
});
