import { createReducer } from "../utils/misc";
import { 
    FETCH_ES_INDEXES_REQUEST,
    FETCH_ES_INDEXES_SUCCESS,
    FETCH_ES_INDEXES_FAILURE,
} 
from "../constants";

const initialState = {
    isFetchingData: false,
    isLoadedData: false,
    data: []
};

export default createReducer(initialState, {
    [FETCH_ES_INDEXES_REQUEST]: state => ({
        ...state,
        isFetchingData: true,
        isLoadedData: false
    }),
    [FETCH_ES_INDEXES_SUCCESS]: (state, payload) => ({
        ...state,
        isFetchingData: false,
        isLoadedData: true,
        data: payload
    }),
    [FETCH_ES_INDEXES_FAILURE]: state => ({
        ...state,
        isFetchingData: false,
        isLoadedData: false
    })
});
