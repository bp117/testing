import { combineReducers } from 'redux';
import app_data from "./app_data";
import es_indices from "./es_indices";
import bt_data from "./bt_data";
import err_data from "./err_data";

const rootReducer = combineReducers({
    app_data,
    es_indices,
    bt_data,
    err_data
});

export default rootReducer;