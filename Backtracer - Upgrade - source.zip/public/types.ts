import { NavigationPublicPluginStart } from '../../../src/plugins/navigation/public';

export interface BacktracerPluginSetup {
  getGreeting: () => string;
}
// eslint-disable-next-line @typescript-eslint/no-empty-interface
export interface BacktracerPluginStart {}

export interface AppPluginStartDependencies {
  navigation: NavigationPublicPluginStart;
}
