import { genericRequest } from './__utils__';
import {
  FETCH_THIS_SERVICE_AGG_DATA_REQUEST,
  FETCH_THIS_SERVICE_AGG_DATA_SUCCESS,
  FETCH_THIS_SERVICE_AGG_DATA_FAILURE,
  FETCH_APP_DATA_REQUEST,
  FETCH_APP_DATA_SUCCESS,
  FETCH_APP_DATA_FAILURE,
  APM_INDEX_URL,
  ES_SCROLL_POST_URL,
  ES_SCROLL_DELETE_URL,
  FETCH_BT_APP_DATA_REQUEST,
  FETCH_BT_APP_DATA_SUCCESS,
  FETCH_BT_APP_DATA_FAILURE,
  FETCH_ES_INDEXES_REQUEST,
  FETCH_ES_INDEXES_FAILURE,
  FETCH_ES_INDEXES_SUCCESS,
  ALL_INDEX_URL,
  FETCH_ERROR_DATA_REQUEST,
  FETCH_ERROR_DATA_SUCCESS,
  FETCH_ERROR_DATA_FAILURE,
  WEBSOCKET_CLIENT_URL,
  WEBSOCKET_PORT,
  WEBSOCKET_SCHEME,
  FETCH_ERR_SERVICES_AGG_DATA_FAILURE,
  FETCH_ERR_SERVICES_AGG_DATA_SUCCESS,
  FETCH_ERR_SERVICES_AGG_DATA_REQUEST,
  FETCH_THIS_EXCEPTION_AGG_DATA_REQUEST,
  FETCH_THIS_EXCEPTION_AGG_DATA_SUCCESS,
  FETCH_THIS_EXCEPTION_AGG_DATA_FAILURE,
  FETCH_ERR_TRACE_ID_DATA_REQUEST,
  FETCH_ERR_TRACE_ID_DATA_SUCCESS,
  FETCH_ERR_TRACE_ID_DATA_FAILURE,
  FETCH_SERVICE_TRACES_REQUEST,
  FETCH_SERVICE_TRACES_SUCCESS,
  FETCH_SERVICE_TRACES_FAILURE,
  FETCH_TRACE_ID_DATA_REQUEST,
  FETCH_TRACE_ID_DATA_SUCCESS,
  FETCH_TRACE_ID_DATA_FAILURE,
} from '../constants';
import { Promise as BPromise } from 'bluebird';

let httpClient = null;
let core = null;

export function initHTTPClient(hClient) {
  httpClient = hClient;
}

export function initCore(_core) {
  core = _core;
}

export const fetchAppData = (index, serviceName, dateRange, callback) => {
  const query = {
    _source: ['parent', 'trace', 'service', 'transaction', 'span', 'error', '@timestamp'],
    query: {
      bool: {
        must: [
          {
            match: {
              'service.name.keyword': serviceName,
            },
          },
          {
            range: {
              '@timestamp': {
                from: dateRange.from,
                to: dateRange.to,
              },
            },
          },
        ],
      },
    },
    aggs: {
      _traces: {
        terms: {
          field: 'trace.id.keyword',
          size: 999999,
        },
      },
    },
    size: 0,
  };

  return (dispatch) => {
    dispatch({ type: FETCH_APP_DATA_REQUEST });
    _fetchData(
      query,
      index,
      (success, data) => {
        if (success) {
          dispatch({
            type: FETCH_APP_DATA_SUCCESS,
            payload: {
              serviceName,
              data: data.aggregations['_traces'].buckets.map((d) => d['key']),
            },
          });
          // dispatch({type: FETCH_APP_DATA_SUCCESS, payload: data });
        } else {
          dispatch({ type: FETCH_APP_DATA_FAILURE, payload: data });
        }
        callback(success, data);
      },
      true
    );
  };
};

let cachedIndex = null;
export const updateCachedIndex = (index) => {
  cachedIndex = index;
};
function _fetchData(query, index, callback = () => {}, isAggregatedQuery = false) {
  index = index ? index : cachedIndex;
  cachedIndex = index;
  // let completeData = [], currentHits = [];

  core.http
    .post('/backtracer/es-query', {
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        query,
        index,
        isAggregatedQuery,
        // connectionId: 'zsc',
      }),
    })
    .then((respData) => {
      if (isAggregatedQuery) {
        // console.log("AGG DATATA ", respData)
        callback(true, respData);
      } else console.log('NOT AN AGGREGATED QUERY.');
    })
    .catch((err) => {
      console.log('ERROR IS ', err);
      callback(false, `${err}`);
    });
}

function parseAggregatedServiceData(data) {
  return data.aggregations['_services'].buckets.reduce((acc, d) => {
    acc[d.key] = {
      hasErrCount: d.doc_count,
    };
    return acc;
  }, {});
}

function parseAggregatedExceptionsData(data) {
  return data.aggregations['_exceptions'].buckets.reduce((acc, d) => {
    acc[d.key] = {
      hasErrCount: d.doc_count,
    };
    return acc;
  }, {});
}

function processThisServiceAggData(data) {
  let finalData = {
    errors: [],
    traces: [],
    totalErrors: data.aggregations['_number_of_exceptions'].value,
  };
  data.aggregations['_exceptions'].buckets.forEach((d) => {
    finalData.errors.push({ name: d['key'], count: d['doc_count'] });
  });
  data.aggregations['_traces'].buckets.forEach((d) => {
    finalData.traces.push({ name: d['key'], count: d['doc_count'] });
  });

  return finalData;
}

function processThisExceptionAggData(data) {
  let finalData = {
    services: [],
    traces: [],
    totalErrors: data.aggregations['_number_of_exceptions'].value,
  };
  data.aggregations['_services'].buckets.forEach((d) => {
    finalData.services.push({ name: d['key'], count: d['doc_count'] });
  });
  data.aggregations['_traces'].buckets.forEach((d) => {
    finalData.traces.push({ name: d['key'], count: d['doc_count'] });
  });

  return finalData;
}

export const fetchThisServiceAggsData = (index, dateRange, serviceName, callback = () => {}) => {
  const query = {
    _source: ['parent', 'trace', 'service', 'transaction', 'span', 'error', '@timestamp'],
    query: {
      bool: {
        must: [
          {
            match: {
              'service.name.keyword': serviceName,
            },
          },
          {
            exists: {
              field: 'error.exception.type.keyword',
            },
          },
          {
            range: {
              '@timestamp': {
                from: dateRange.from,
                to: dateRange.to,
              },
            },
          },
        ],
      },
    },
    aggs: {
      _exceptions: {
        terms: {
          field: 'error.exception.type.keyword',
          size: 999999,
        },
      },
      _traces: {
        terms: {
          field: 'trace.id.keyword',
          size: 999999,
        },
      },
      _number_of_exceptions: {
        value_count: {
          field: 'error.exception.type.keyword',
        },
      },
    },
    size: 0,
  };

  return (dispatch) => {
    dispatch({ type: FETCH_THIS_SERVICE_AGG_DATA_REQUEST });
    _fetchData(
      query,
      index,
      (success, data) => {
        if (success) {
          dispatch({
            type: FETCH_THIS_SERVICE_AGG_DATA_SUCCESS,
            payload: { serviceName, data: processThisServiceAggData(data) },
          });
          // dispatch({type: FETCH_ERROR_DATA_SUCCESS, payload: data });
        } else {
          dispatch({ type: FETCH_THIS_SERVICE_AGG_DATA_FAILURE, payload: data });
        }
        callback(success, data);
      },
      true
    );
  };
};

function extractTraceIDs(data) {
  return (data['aggregations']['_traces'].buckets || []).map((d) => d.key);
}

export const fetchServiceTraces = (index, serviceName, dateRange, callback = () => {}) => {
  const query = {
    _source: ['parent', 'trace', 'service', 'transaction', 'span', 'error', '@timestamp'],
    query: {
      bool: {
        must: [
          {
            match: {
              'service.name.keyword': serviceName,
            },
          },
          {
            range: {
              '@timestamp': {
                from: dateRange.from,
                to: dateRange.to,
              },
            },
          },
        ],
      },
    },
    aggs: {
      _traces: {
        terms: {
          field: 'trace.id.keyword',
          size: 999999,
        },
      },
    },
    size: 0,
  };

  return (dispatch) => {
    dispatch({ type: FETCH_SERVICE_TRACES_REQUEST });
    _fetchData(
      query,
      index,
      (success, data) => {
        if (success) {
          data = extractTraceIDs(data);
          dispatch({ type: FETCH_SERVICE_TRACES_SUCCESS, payload: { serviceName, data } });
          // dispatch({type: FETCH_ERROR_DATA_SUCCESS, payload: data });
        } else {
          dispatch({ type: FETCH_SERVICE_TRACES_FAILURE, payload: data });
        }
        callback(success, data);
      },
      true
    );
  };
};

export const fetchThisExceptionsAggsData = (
  index,
  dateRange,
  exceptionName,
  callback = () => {}
) => {
  const query = {
    _source: ['parent', 'trace', 'service', 'transaction', 'span', 'error', '@timestamp'],
    query: {
      bool: {
        must: [
          {
            match: {
              'error.exception.type.keyword': exceptionName,
            },
          },
          // {
          //   "exists": {
          //     "field": "error.exception.type.keyword"
          //   }
          // },
          {
            range: {
              '@timestamp': {
                from: dateRange.from,
                to: dateRange.to,
              },
            },
          },
        ],
      },
    },
    aggs: {
      _services: {
        terms: {
          field: 'service.name.keyword',
          size: 999999,
        },
      },
      _traces: {
        terms: {
          field: 'trace.id.keyword',
          size: 999999,
        },
      },
      _number_of_exceptions: {
        value_count: {
          script: {
            source: `doc['error.exception.type.keyword'] == '${exceptionName}'`,
          },
        },
      },
    },
    size: 0,
  };

  return (dispatch) => {
    dispatch({ type: FETCH_THIS_EXCEPTION_AGG_DATA_REQUEST });
    _fetchData(
      query,
      index,
      (success, data) => {
        if (success) {
          dispatch({
            type: FETCH_THIS_EXCEPTION_AGG_DATA_SUCCESS,
            payload: { exceptionName, data: processThisExceptionAggData(data) },
          });
          // dispatch({type: FETCH_ERROR_DATA_SUCCESS, payload: data });
        } else {
          dispatch({ type: FETCH_THIS_EXCEPTION_AGG_DATA_FAILURE, payload: data });
        }
        callback(success, data);
      },
      true
    );
  };
};

export const fetchErrorTabServicesAggsData = (index, dateRange, callback) => {
  const query = {
    _source: ['parent', 'trace', 'service', 'transaction', 'span', 'error', '@timestamp'],
    query: {
      bool: {
        must: [
          {
            exists: {
              field: 'error.exception.type.keyword',
            },
          },
          {
            range: {
              '@timestamp': {
                from: dateRange.from,
                to: dateRange.to,
              },
            },
          },
        ],
      },
    },
    aggs: {
      _exceptions: {
        terms: {
          field: 'error.exception.type.keyword',
          size: 999999,
        },
      },
      _traces: {
        terms: {
          field: 'trace.id.keyword',
          size: 999999,
        },
      },
      _services: {
        terms: {
          field: 'service.name.keyword',
          size: 999999,
        },
      },
      _number_of_exceptions: {
        value_count: {
          field: 'error.exception.type.keyword',
        },
      },
    },
    size: 0,
  };

  return (dispatch) => {
    dispatch({ type: FETCH_ERR_SERVICES_AGG_DATA_REQUEST });
    _fetchData(
      query,
      index,
      (success, data) => {
        if (success) {
          let parsedServices = parseAggregatedServiceData(data);
          let parsedErrors = parseAggregatedExceptionsData(data);
          let servicesPayload = {
            services: parsedServices,
            metadata: { totalErrors: data.aggregations['_number_of_exceptions'].value || 0 },
          };
          dispatch({ type: FETCH_ERR_SERVICES_AGG_DATA_SUCCESS, payload: servicesPayload });
          // dispatch({type: FETCH_ERROR_DATA_SUCCESS, payload: data });
          Object.keys(parsedServices || {}).forEach((serviceName) => {
            dispatch(fetchThisServiceAggsData(index, dateRange, serviceName));
          });
          Object.keys(parsedErrors || {}).forEach((exceptionName) => {
            dispatch(fetchThisExceptionsAggsData(index, dateRange, exceptionName));
          });
        } else {
          dispatch({ type: FETCH_ERR_SERVICES_AGG_DATA_FAILURE, payload: data });
        }
        callback(success, data);
      },
      true
    );
  };
};

export const fetchErrorTabTraceIdData = (index, traceIdList, callback) => {
  console.log('ABOUT TO FETCH ', traceIdList.length, ' TRACES');
  let allTraceSlices = [];
  let allTraceData = {};
  const MAX_TRACES_FETCH = 500;
  if (traceIdList.length <= MAX_TRACES_FETCH) {
    allTraceSlices.push(traceIdList);
  } else {
    let groupCount = Math.round(traceIdList.length / MAX_TRACES_FETCH);
    for (let i = 0; i < groupCount; i++) {
      allTraceSlices.push(traceIdList.slice(i * MAX_TRACES_FETCH, (i + 1) * MAX_TRACES_FETCH));
    }
  }

  return (dispatch) => {
    dispatch({ type: FETCH_ERR_TRACE_ID_DATA_REQUEST });
    BPromise.map(allTraceSlices, (traceIds, fetchIndex) => {
      const query = {
        _source: ['parent', 'trace', 'service', 'transaction', 'span', 'error', '@timestamp'],
        query: {
          terms: {
            'trace.id.keyword': traceIds,
          },
        },
        aggs: {
          'AGG-HITS': {
            scripted_metric: {
              init_script: 'state.result = []',
              map_script: `
                  HashMap map=new HashMap();
                  def item = params._source;
                  map.put("parent.id", item.containsKey("parent")?item.parent.id:null);
                  map.put("trace.id", item.containsKey("trace")?item.trace.id:null);
                  map.put("service.name", item.containsKey("service")?item.service.name:null);
                  map.put("transaction.id", item.containsKey("transaction")?item.transaction.id:null);
                  map.put("span.id", item.containsKey("span")?item.span.id:null);
                  map.put("span.name", item.containsKey("span")?item.span.name:null);
                  map.put("timestamp", item['@timestamp']);
                  map.put("error", item.error);
                  state.result.add(map);
              `,
              combine_script: 'return state.result',
              reduce_script: `
                Map responseList = new HashMap();
                for(t in states){ 
                  for(r in t){ 
                    if(!responseList.containsKey(r['trace.id'])){
                      responseList.put(r['trace.id'], new ArrayList())
                    }
                    responseList[r['trace.id']].add(r); 
                  } 
                } 
                return responseList`,
              params: {
                response: traceIds.reduce((acc, t) => {
                  acc[t] = [];
                  return acc;
                }, {}),
              },
            },
          },
        },
      };

      return new BPromise.Promise((resolve, reject) => {
        console.log('NOW FETCHING ', traceIds.length, ' TRACES, FETCH INDEX: ', fetchIndex);
        _fetchData(
          query,
          index,
          (success, data) => {
            if (success) {
              allTraceData = { ...allTraceData, ...data.aggregations['AGG-HITS'].value };
              resolve();
            } else {
              reject();
            }
          },
          true
        );
      });
    })
      .then((r) => {
        dispatch({ type: FETCH_ERR_TRACE_ID_DATA_SUCCESS, payload: allTraceData });
        callback(true, allTraceData);
      })
      .catch((r) => {
        dispatch({ type: FETCH_ERR_TRACE_ID_DATA_SUCCESS, payload: allTraceData });
        dispatch({ type: FETCH_ERR_TRACE_ID_DATA_FAILURE });
        callback(false, `${r}`);
      });
  };
};

export const fetchExceptionTraces = (
  index,
  selectedExceptions,
  serviceName,
  dateRange,
  callback = () => {}
) => {
  const query = {
    _source: ['parent', 'trace', 'service', 'transaction', 'span', 'error', '@timestamp'],
    query: {
      bool: {
        must: [
          {
            bool: {
              should: (selectedExceptions || []).map((t) => ({
                match: {
                  'error.exception.type.keyword': t,
                },
              })),
            },
          },
          {
            match: {
              'service.name.keyword': serviceName,
            },
          },
          {
            range: {
              '@timestamp': {
                from: dateRange.from,
                to: dateRange.to,
              },
            },
          },
        ],
      },
    },
    aggs: {
      _traces: {
        terms: {
          field: 'trace.id.keyword',
          size: 999999,
        },
      },
    },
    size: 0,
  };

  _fetchData(
    query,
    index,
    (success, data) => {
      if (success) {
        callback(
          success,
          data.aggregations['_traces'].buckets.map((t) => t.key)
        );
      } else {
        callback(success, data);
      }
    },
    true
  );
};

export const fetchBtAppData = (index, traceId, callback) => {
  const query = {
    _source: ['parent', 'trace', 'service', 'transaction', 'span', 'error', '@timestamp'],
    query: {
      match: {
        'trace.id': traceId,
      },
    },
    aggs: {
      'AGG-HITS': {
        scripted_metric: {
          init_script: 'state.result = []',
          map_script: `
              HashMap map=new HashMap();
              def item = params._source;
              map.put("parent.id", item.containsKey("parent")?item.parent.id:null);
              map.put("trace.id", item.containsKey("trace")?item.trace.id:null);
              map.put("service.name", item.containsKey("service")?item.service.name:null);
              map.put("transaction.id", item.containsKey("transaction")?item.transaction.id:null);
              map.put("span.id", item.containsKey("span")?item.span.id:null);
              map.put("span.name", item.containsKey("span")?item.span.name:null);
              map.put("timestamp", item['@timestamp']);
              map.put("error", item.error);
              state.result.add(map);
          `,
          combine_script: 'return state.result',
          reduce_script: `
            for(t in states){ 
              for(r in t){ 
                  params.response.add(r); 
              } 
            } 
            return params.response`,
          params: {
            response: [],
          },
        },
      },
    },
  };

  return (dispatch) => {
    dispatch({ type: FETCH_BT_APP_DATA_REQUEST });
    _fetchData(
      query,
      index,
      (success, data) => {
        if (success) {
          dispatch({
            type: FETCH_BT_APP_DATA_SUCCESS,
            payload: data.aggregations['AGG-HITS'].value,
          });
          callback(success, data);
        } else {
          dispatch({ type: FETCH_BT_APP_DATA_FAILURE, payload: data });
          callback(success, data);
        }
      },
      true
    );
  };
};

export const fetchAllIndices = (callback = () => {}) => {
  return (dispatch) => {
    dispatch({ type: FETCH_ES_INDEXES_REQUEST });
    httpClient
      .post('/backtracer/es-indexes')
      .then((respData) => {
        dispatch({ type: FETCH_ES_INDEXES_SUCCESS, payload: Object.keys(respData || {}) });
        callback(true, respData);
      })
      .catch((err) => {
        dispatch({ type: FETCH_ES_INDEXES_FAILURE });
        callback(false, err);
      });
  };
};
