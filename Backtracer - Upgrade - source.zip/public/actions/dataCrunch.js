import {Promise as BPromise} from "bluebird";
import { MAX_CONCURRENT_HANDLERS } from "../constants";
import { getAppStore } from "../store/store_provider";
import { fetchTraceIdData, fetchErrorTabTraceIdData } from ".";

function _getTransactionIds(traceData, serviceName){
    traceData = traceData || [];
    let transactions = traceData.filter(t => (t["service.name"] == serviceName && t["transaction.id"]) ) || [];
    let transactionIds = []; 
    transactions.forEach(t=>{
        if(!transactionIds.find(t2=>t2["transaction.id"]===t["transaction.id"])){
            transactionIds.push(t["transaction.id"]);
        }
    });

    return [...new Set(transactionIds)];
}

function getSpanId(span){
    return span["span.id"]+span["span.name"]+span["transaction.id"]+span["parent.id"];
}

function linkIsEqual(link1, link2){
    return getSpanId(link1.source) == getSpanId(link2.source) && getSpanId(link1.target) == getSpanId(link2.target);
}

/**
 * 
 * @param {Array} inputData 
 * @param {string|Array} initialTransactionId 
 */
export function findBacktraceTarget(inputData, initialTransactionIds){
    if(Array.isArray(initialTransactionIds)){
        for(let initialTransactionId of initialTransactionIds){
            let { links, nodes } = findBacktraceTarget(inputData, initialTransactionId);    
            for (let i=0; i<nodes.length; i++){
                if(nodes[i].isTarget) return nodes[i];
            }
        }
    }else {
        let {links, nodes} = _constructBacktracePath(inputData, initialTransactionIds);
        for (let i=0; i<nodes.length; i++){
            if(nodes[i].isTarget) return nodes[i];
        }
    }

    return null
}


/**
 * 
 * @param {Array} inputData 
 * @param {string|Array} initialTransactionId 
 */
export function constructBacktracePath(inputData, initialTransactionIds){
    let links = [], nodes = [];
    if(Array.isArray(initialTransactionIds)){
        for(let initialTransactionId of initialTransactionIds){
            let { links:l, nodes:n } = constructBacktracePath(inputData, initialTransactionId);
            l = l.filter(link=>{
                return !links.find(mLink=>linkIsEqual(mLink, link));
            });
            n = n.filter(node=>{
                return !nodes.find(mNode=>getSpanId(mNode)==getSpanId(node));
            });
            links.push(...l);
            nodes.push(...n);
        }
        return {links, nodes};
    }else {
        return _constructBacktracePath(inputData, initialTransactionIds);
    }
}

function _constructBacktracePath(inputData, initialTransactionId){
    let links = [], nodes = [];

    function constructBacktrace(transactionId) {
        //0. Get all the spans for this transaction from the input data.
        let transactionSpans = inputData.filter(t=>t["transaction.id"] == transactionId);

        //1. Find the service or initial span of this transaction
        let serviceSpans = transactionSpans.filter( t => t["span.id"] == null );
        
        serviceSpans.forEach(serviceSpan=>{
            //2. Find other spans participating in this transaction (excluding the service span above)
            let otherSpans = transactionSpans.filter( t => t["span.id"] != null );
    
            //3. Connect particpating (other) spans to the service span (in 1)
            otherSpans.forEach(span=>{
                links.push({
                    target: serviceSpan,
                    source: {...span, isSpan:true}
                    //you might want to differentiate other the transactions from here
                });
                nodes.push({...span, isSpan:true});
            });
    
            if(serviceSpan && serviceSpan["parent.id"]){
                nodes.push({...serviceSpan, isSource:transactionId==initialTransactionId});
                //4. Locate a span in the input data who's span id is the parent id of the service span
                let linkSpan = inputData.find(t=> t["span.id"] == serviceSpan["parent.id"] && t["transaction.id"] !== serviceSpan["transaction.id"]);
                if(linkSpan){
                    links.push({
                        target: {...linkSpan, isSpan:true},
                        source: serviceSpan,
                        // isResultLink: true
                    });
                    
                    let nextTransactioId = linkSpan["transaction.id"];
                    constructBacktrace(nextTransactioId);
                }
            } else if(serviceSpan){
                nodes.push({...serviceSpan, isTarget:true});
            }
        })
    }

    constructBacktrace(initialTransactionId)

    return {links, nodes};
}

export function constructServiceDepPath(traces, serviceName, traceColors={}, countTracePredicate=()=>true, onComplete) {
    let links = [], nodes = [], nodesTraceCount={};
    
    function _handleTraceData(traceId, traceData, resolve){
        // console.log("HANDLING TRACE ID ", traceId, ", TRACE DATA ", traceData)
        let serviceTrans = ((traceData||[]).find(t=>t["service.name"]==serviceName)||{});
        let serviceTransId = serviceTrans["transaction.id"];
        // let serviceTransId = _getTransactionIds(traceData, serviceName)
        // console.log("SERVICE TRANSACTION IDS ", serviceTransId)
        if(serviceTransId){
            // let backtrace = constructBacktracePath(traceData, serviceTransId); 
            let targetNode = findBacktraceTarget(traceData, serviceTransId); 
            let backtrace = {};
            if(targetNode){
                backtrace = {links:[{ target: targetNode, source: serviceTrans }], nodes:[serviceTrans, targetNode]}
                if(countTracePredicate(backtrace.links[0], traceId)){
                    nodesTraceCount[serviceTrans["service.name"]] = [...(nodesTraceCount[serviceTrans["service.name"]]||[]), traceId];
                    nodesTraceCount[serviceTrans["service.name"]] = [...new Set(nodesTraceCount[serviceTrans["service.name"]])];  //Remove duplicate trace ids.
                    
                    nodesTraceCount[targetNode["service.name"]] = [...(nodesTraceCount[targetNode["service.name"]]||[]), traceId];
                    nodesTraceCount[targetNode["service.name"]] = [...new Set(nodesTraceCount[targetNode["service.name"]])];  //Remove duplicate trace ids.
                }
                targetNode["node.color"] = traceColors[traceId]
                
                links.push(...backtrace.links);
                nodes.push(...backtrace.nodes);
            }
        } 
        resolve();
    }

    let unFetchedTraces = traces.filter(traceId=>!getAppStore().getState().err_data.traceDataMap[traceId]);
    let fetchedTraces = traces.filter(traceId=>!!getAppStore().getState().err_data.traceDataMap[traceId]);

    
    BPromise.all([
        new BPromise.Promise((resolve, reject)=>{
            if(unFetchedTraces.length){
                getAppStore().dispatch(
                    fetchErrorTabTraceIdData(null, unFetchedTraces, (success, respData)=>{
                        if(success){
                            BPromise.map(unFetchedTraces, (traceId)=>{
                                return new BPromise.Promise((resolve2)=>{
                                    let traceData = getAppStore().getState().err_data.traceDataMap[traceId];
                                    _handleTraceData(traceId, traceData, resolve2);
                                });
                            }, {concurrency: MAX_CONCURRENT_HANDLERS})
                            .then(resolve)
                            .catch(reject);
                        }
                        else reject()
                    })
                );
            } 
            else resolve();
        }),

        BPromise.map(fetchedTraces, (traceId)=>{
            return new Promise((resolve)=>{
                let traceData = getAppStore().getState().err_data.traceDataMap[traceId];
                _handleTraceData(traceId, traceData, resolve);
            })
        }, {concurrency: MAX_CONCURRENT_HANDLERS}),
    ])
    .then(()=>{
        nodes = nodes.map(node=>{
            node.traces = nodesTraceCount[node["service.name"]] || [];
            return node;
        });
        onComplete({links, nodes})
    })
}