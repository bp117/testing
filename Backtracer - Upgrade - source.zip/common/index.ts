export const PLUGIN_ID = 'backtracer';
export const PLUGIN_NAME = 'backtracer';

/**
 * API Endpoints
 */
export const ES_BASE_URL = ""//`http://localhost:9200`;
export const APM_INDEX_URL = `${ES_BASE_URL}/{index}/_search`;
export const ES_SCROLL_DELETE_URL = `${ES_BASE_URL}/_search/scroll/{scrollId}`;
export const ES_SCROLL_POST_URL = `${ES_BASE_URL}/_search/scroll`;
export const ALL_INDEX_URL = `${ES_BASE_URL}/_aliases`;

export function formatUrl(endpoint: string, queryStrings: { [key: string]: string } | null, dynamicContent: { [key: string]: string } | null) {
    let qs = "";
    queryStrings = queryStrings ? queryStrings : {};
    dynamicContent = dynamicContent ? dynamicContent : {};

    Object.keys(queryStrings).forEach(key => {
        if (queryStrings!.hasOwnProperty(key)) {
            qs = qs + `${qs.length > 0 ? "&" : ""}` + key + "=" + queryStrings![key];
        }
    });

    Object.keys(dynamicContent).forEach(key => {
        if (dynamicContent!.hasOwnProperty(key)) {
            const re = RegExp(`{${key}}`);
            endpoint = endpoint.replace(re, dynamicContent![key]);
        }
    });

    if (qs.length > 0) {
        endpoint = endpoint + "?" + qs;
    }

    return endpoint;
}