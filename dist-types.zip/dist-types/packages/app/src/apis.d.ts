import { AnyApiFactory } from '@backstage/core-plugin-api';
export declare const apis: AnyApiFactory[];
