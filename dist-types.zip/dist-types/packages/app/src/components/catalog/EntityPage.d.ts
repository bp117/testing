/// <reference types="react" />
export declare const entityPage: JSX.Element;
