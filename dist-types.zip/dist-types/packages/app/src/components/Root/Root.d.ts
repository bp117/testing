import { PropsWithChildren } from 'react';
export declare const Root: ({ children }: PropsWithChildren<{}>) => JSX.Element;
