import React, { useState, useEffect } from 'react';
import { Table, Row, Col, Button, Modal, OverlayTrigger, Tooltip } from 'react-bootstrap';
import dayjs from 'dayjs';
import { useSelector, useDispatch } from 'react-redux';
import Axios from 'axios';
import {
  BasicDataLoaded,
  NormalizationDataLoaded,
  TemplateDataLoaded,
  historyDataLoaded,
} from '../store/actions';
import {responseToDownload} from '../download';

function NormalizationTab(props) {
  const {
    selectTabIndex
  } = props;
  const [history, setHistory] = useState({});
  const [show, setShow] = useState(false);
  const [responsedata, setResponseData] = useState({});
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  const dispatch = useDispatch();

  async function fetchMyAPI() {
    let response = await fetch('api/getyamlfiles');
    response = await response.json();
    setHistory(response);
  }

  useEffect(() => {
    fetchMyAPI();
  }, []);

  const DeleteFile = (e, itemName) => {
    const url = '/api/' + itemName;
    try {
      response = fetch(url, {
        method: 'delete',
        headers: {
          'Content-Type': 'application/json',
        },
      })
      .then((response) => response.json())
      .then((data) => {
        console.log(data);
        fetchMyAPI();
      }).catch((err) => {
        console.log(err);
      });
    }
    catch (err) {
      return false;
    }
  };

  function FindID(e, type, itemName) {
    e.preventDefault();
    const url = '/api/' + itemName;
    const FileName = itemName
    try {
      response = fetch(url, {
        method: 'get',
        headers: {
          'Content-Type': 'application/json',
        },
      })
      .then((response) => response.json())
      .then((data) => {
        dispatch(BasicDataLoaded(data.BasicData));
        dispatch(TemplateDataLoaded(data.TemplateData));
        dispatch(NormalizationDataLoaded(data.Normalization));
        dispatch(
          historyDataLoaded({
            ...data.History,
            Edited: true,
            EditedAt: new Date().toLocaleDateString(),
            FileName: FileName,
            sessionData: {
              editType: type,
              fileName: itemName
            }
          })
        );
        selectTabIndex(0)
      })
      .catch((err) => {
        console.log(err);
      });
    } catch (err) {
      return false;
    }
  }

  

  async function Downloadyaml(e, fileName, extension) {
    e.preventDefault();
    const url = '/api/download/'+extension+'/' + fileName;
    fetch(url, {
      method: 'get',
      headers: {
        'Content-Type': 'application/json',
      },
    })
    .then((response) => response.json())
    .then((data) => {
      if(extension === "yaml"){
        responseToDownload(data.yaml, fileName);
      }
      if(extension === "sql"){
        responseToDownload(data.sql, fileName.replace('.yaml', '.sql'));
      }
    });
  }

  const svgHeight = '16px';
  const Pencil = ({style = {}}) => (<svg style={{height: svgHeight, ...style}} viewBox="0 0 8 8" xmlns="http://www.w3.org/2000/svg"><path d="m6 0-1 1 2 2 1-1zm-2 2-4 4v2h2l4-4z"/></svg>);
  const Person = ({style = {}}) => (<svg xmlns="http://www.w3.org/2000/svg" style={{height: svgHeight, ...style}} viewBox="0 0 8 8">
    <path d="M4 0c-1.1 0-2 1.12-2 2.5s.9 2.5 2 2.5 2-1.12 2-2.5-.9-2.5-2-2.5zm-2.09 5c-1.06.05-1.91.92-1.91 2v1h8v-1c0-1.08-.84-1.95-1.91-2-.54.61-1.28 1-2.09 1-.81 0-1.55-.39-2.09-1z" />
  </svg>);
  const Trash = ({style = {}}) => (
    <svg xmlns="http://www.w3.org/2000/svg" style={{height: svgHeight, ...style}} viewBox="0 0 8 8">
      <path d="M3 0c-.55 0-1 .45-1 1h-1c-.55 0-1 .45-1 1h7c0-.55-.45-1-1-1h-1c0-.55-.45-1-1-1h-1zm-2 3v4.81c0 .11.08.19.19.19h4.63c.11 0 .19-.08.19-.19v-4.81h-1v3.5c0 .28-.22.5-.5.5s-.5-.22-.5-.5v-3.5h-1v3.5c0 .28-.22.5-.5.5s-.5-.22-.5-.5v-3.5h-1z" />
    </svg>
  );
  const Download = ({style = {}}) => (
    <svg xmlns="http://www.w3.org/2000/svg" style={{height: svgHeight, ...style}} viewBox="0 0 8 8">
      <path d="M3 0v3h-2l3 3 3-3h-2v-3h-2zm-3 7v1h8v-1h-8z" />
    </svg>
  );

  return (
    <Row className='text-center'>
      <Col>
        <Table striped bordered hover size='sm'>
          <thead>
            <tr>
              <th>#</th>
              <th>File Name</th>
              <th>Created At</th>
              <th>Size</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {history.length > 0 ? (
              history.map((item, index) => {
                return (
                  <tr key={index}>
                    <td>{index + 1}</td>
                    <td>{item.name}</td>
                    <td>{dayjs(item.birthtime).format('HH:mm:ss - DD, MMM YYYY')}</td>
                    <td>{item.size}</td>
                    <td>{item.fileInfo.status}</td>
                    <td id={item.name}>
                      {
                        item.fileInfo.status === "SENT_FOR_REVIEW" && (
                          <OverlayTrigger overlay={<Tooltip>Review</Tooltip>}>
                            <Button size="sm" onClick={(e) => FindID(e, "review", item.name)} variant='light'>
                              <Person />
                            </Button>
                          </OverlayTrigger>
                        )
                      }

                      <OverlayTrigger overlay={<Tooltip>Edit</Tooltip>}>
                        <Button size="sm" onClick={(e) => FindID(e, "edit", item.name)} variant='light'>
                          <Pencil />
                        </Button>
                      </OverlayTrigger>{' '}

                      <OverlayTrigger overlay={<Tooltip>Delete</Tooltip>}>
                        <Button size="sm" onClick={(e) => DeleteFile(e, item.name)} variant='danger'>
                          <Trash style={{fill: '#ffffff'}} />
                        </Button>
                      </OverlayTrigger>{' '}


                      <OverlayTrigger overlay={<Tooltip>Download .yaml file</Tooltip>}>
                        <Button
                          variant='info'
                          size="sm"
                          onClick={(e) => Downloadyaml(e, item.name, 'yaml')}
                        >
                          <Download style={{fill: '#ffffff'}} /> YAML
                        </Button>
                      </OverlayTrigger>


                      <OverlayTrigger overlay={<Tooltip>Download .sql DML file</Tooltip>}>
                        <Button
                          variant='info'
                          size="sm"
                          onClick={(e) => Downloadyaml(e, item.name, 'sql')}
                        >
                          <Download style={{fill: '#ffffff'}}/> SQL
                        </Button>
                      </OverlayTrigger>
                      
                      
                     
                    </td>
                  </tr>
                );
              })
            ) : (
              <tr></tr>
            )}
          </tbody>
        </Table>
      </Col>
      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Modal heading</Modal.Title>
        </Modal.Header>
        <Modal.Body>Woohoo, you're reading this text in a modal!</Modal.Body>
        <Modal.Footer>
          <Button variant='secondary' onClick={handleClose}>
            Close
          </Button>
          <Button variant='primary' onClick={handleClose}>
            Save Changes
          </Button>
        </Modal.Footer>
      </Modal>
    </Row>
  );

}
export default NormalizationTab;
