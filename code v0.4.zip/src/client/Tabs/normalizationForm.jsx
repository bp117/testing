import React, { useState, useEffect } from 'react';
import { Form, Row, Col, Button } from 'react-bootstrap';
import { NormalizationDataChanged } from '../store/actions';
import { useSelector, useDispatch } from 'react-redux';
function NormalizationForm(props) {
  //   const Rstate = useSelector((state) => state.Normalization);
  const dispatch = useDispatch();
  const [FieldName, setFieldName] = useState(props.values.FieldName || '');
  const [Order, setOrder] = useState(props.values.Order || '');
  const {
    index,
    formsLength
  } = props;
  //   const stateData = useSelector((state) => state);

  const removeHandler = (e,i) => {
    if(formsLength === 1) {
      return;
    }
    props.remove(e,i);
  }
  return (
    <Row className='text-center'>
      <Col sm={12} md={5}>
        <Form.Group controlId='exampleForm.ControlInput1'>
          <Form.Label>Field Name</Form.Label>
          <Form.Control
            name='fieldName'
            onChange={(e) => {
              setFieldName(e.target.value);
              dispatch(
                NormalizationDataChanged({
                  inputValue: e.target.value,
                  id: props.values.id,
                  name: e.target.name,
                })
              );
            }}
            value={props.values.fieldName}
            placeholder='Field Name'
          />
        </Form.Group>
      </Col>
      <Col sm={12} md={5}>
        <Form.Group controlId='exampleForm.ControlInput1'>
          <Form.Label>Order</Form.Label>
          <Form.Control
            name='order'
            onChange={(e) => {
              setOrder(e.target.value);
              dispatch(
                NormalizationDataChanged({
                  inputValue: e.target.value,
                  id: props.values.id,
                  name: e.target.name,
                })
              );
            }}
            value={props.values.order}
            placeholder='Order ID'
          />
        </Form.Group>
      </Col>
      <Col className='mt-2 pt-4'>
        <Button variant='primary' onClick={props.increment}>
          +
        </Button>{' '}
        <Button variant='info' disabled={formsLength === 1} onClick={(e) => removeHandler(e, index)}>
          -
        </Button>{' '}
      </Col>
    </Row>
  );
}
export default NormalizationForm;
