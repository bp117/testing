import React, { useState } from 'react';
import { Form, Row, Col } from 'react-bootstrap';
import { TemplateDataChanged } from '../store/actions';
import { useSelector, useDispatch } from 'react-redux';
function TemplateInfo() {
  const Rstate = useSelector((state) => state.TemplateData);
  const dispatch = useDispatch();
  const [TemplateID, setTemplateID] = useState(Rstate.TemplateID || '');
  const [XSLTTemplateID, setXSLTTemplateID] = useState(
    Rstate.XSLTTemplateID || ''
  );
  const [EngAddressLabel, setEngAddressLabel] = useState(
    Rstate.EngFromAddressLabel || ''
  );
  const [SpaAddressLabel, setSpaAddressLabel] = useState(
    Rstate.SpaFromAddressLabel || ''
  );
  const [SpaCustomerSegment, setSpaCustomerSegment] = useState(
    Rstate.SpaCustomerSegment || ''
  );
  const [EngCustomerSegment, setEngCustomerSegment] = useState(
    Rstate.EngCustomerSegment || ''
  );
  const [Language, setLanguage] = useState(Rstate.EngLanguage || 'Eng');
  return (
    <Form>
      <Row className='text-center'>
        <Col>
          <Form.Group controlId='id'>
            <Form.Label>Template ID</Form.Label>
            <Form.Control
              name='TemplateID'
              onChange={(e) => {
                setTemplateID(e.target.value);
                dispatch(
                  TemplateDataChanged({
                    inputValue: e.target.value,
                    name: e.target.name,
                  })
                );
              }}
              value={TemplateID}
              placeholder='Template ID'
            />
          </Form.Group>
        </Col>
        <Col>
          <Form.Group controlId='xsid'>
            <Form.Label>XSLT Template ID</Form.Label>
            <Form.Control
              name='XSLTTemplateID'
              onChange={(e) => {
                setXSLTTemplateID(e.target.value);
                dispatch(
                  TemplateDataChanged({
                    inputValue: e.target.value,
                    name: e.target.name,
                  })
                );
              }}
              value={XSLTTemplateID}
              placeholder='XSLT Template ID'
            />
          </Form.Group>
        </Col>
      </Row>
      <Row>
        <Col>
          <h3>English</h3>
          <Row>
            <Col>
              <Form.Group controlId='lable'>
                <Form.Label>From Address label</Form.Label>
                <Form.Control
                  name='EngFromAddressLabel'
                  onChange={(e) => {
                    setEngAddressLabel(e.target.value);
                    dispatch(
                      TemplateDataChanged({
                        inputValue: e.target.value,
                        name: e.target.name,
                      })
                    );
                  }}
                  value={EngAddressLabel}
                  placeholder='From Address'
                />
              </Form.Group>
            </Col>
            <Col>
              <Form.Group controlId='seng'>
                <Form.Label>Customer Segment</Form.Label>
                <Form.Control
                  name='EngCustomerSegment'
                  onChange={(e) => {
                    setEngCustomerSegment(e.target.value);
                    dispatch(
                      TemplateDataChanged({
                        inputValue: e.target.value,
                        name: e.target.name,
                      })
                    );
                  }}
                  value={EngCustomerSegment}
                  placeholder='Customer Segment'
                />
              </Form.Group>
            </Col>
            <Col>
              <Form.Group controlId='language'>
                <Form.Label>Language</Form.Label>
                <Form.Control
                  as='select'
                  name='EngLanguage'
                  onChange={(e) => {
                    setLanguage(e.target.value);
                    dispatch(
                      TemplateDataChanged({
                        inputValue: e.target.value,
                        name: e.target.name,
                      })
                    );
                  }}
                  value={Language}
                >
                  <option>Eng</option>
                  <option>Spa</option>
                </Form.Control>
              </Form.Group>
            </Col>
          </Row>
        </Col>
        <Col>
          <h3>Spanish</h3>
          <Row>
            <Col>
              <Form.Group controlId='exampleForm.ControlInput1'>
                <Form.Label>From Address label</Form.Label>
                <Form.Control
                  name='SpaFromAddressLabel'
                  onChange={(e) => {
                    setSpaAddressLabel(e.target.value);
                    dispatch(
                      TemplateDataChanged({
                        inputValue: e.target.value,
                        name: e.target.name,
                      })
                    );
                  }}
                  value={SpaAddressLabel}
                  placeholder='From Address'
                />
              </Form.Group>
            </Col>
            <Col>
              <Form.Group controlId='exampleForm.ControlInput1'>
                <Form.Label>Customer Segment</Form.Label>
                <Form.Control
                  name='SpaCustomerSegment'
                  onChange={(e) => {
                    setSpaCustomerSegment(e.target.value);
                    dispatch(
                      TemplateDataChanged({
                        inputValue: e.target.value,
                        name: e.target.name,
                      })
                    );
                  }}
                  value={SpaCustomerSegment}
                  placeholder='Customer Segment'
                />
              </Form.Group>
            </Col>
          </Row>
        </Col>
      </Row>
    </Form>
  );
}
export default TemplateInfo;
