import React, {useState, useEffect} from 'react';
import { connect } from 'react-redux';
import {
    Row,
    Col,
    Button,
    Form
} from 'react-bootstrap';
const SubmitAndReview = (props) => {
    const [history, setHistory] = useState({});
    const [reviewAction, setReviewAction] = useState('ADDED_REMARKS');
    const [review, setReview] = useState('');

    useEffect(() => {
        setHistory(props.History)
        const reviews = props.History && props.History.fileInfo && props.History.fileInfo.reviews ? props.History.fileInfo.reviews : "";
        setReview(reviews)
    }, []);

    const Submit = (e, historyArg) => {

        e.preventDefault();
        const url = props.History.Edited
          ? '/api/updateData'
          : '/api/createData';
        const method = props.History.Edited ? 'put' : 'post';
        const stateData = {
          BasicData: props.BasicData,
          History: historyArg,
          TemplateData: props.TemplateData,
          Normalization: props.Normalization,
        };
    
        delete stateData.History.sessionData;
    
        try {
          response = fetch(url, {
            method,
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify(stateData),
          });
        } catch (err) {
          return false;
        }
        
    };
    
    
    const submitInterceptor = (e, actionInput ,reviewInput) => {
        var obj = {...history};
        if(!obj.fileInfo) {
          obj.fileInfo = {};
        }
    
        if(!obj.fileInfo.reviews) {
          obj.fileInfo.reviews = "";
        }
    
        obj.fileInfo.status = actionInput;
        obj.fileInfo.reviews += reviewInput;
          
        Submit(e, obj);
    }
    
    const denyReview = () => {
        window.location.reload();
    }


    return (
        <div>
            <Row style={{marginTop: '40px'}}>
                <Col sm={6}>
                    {
                    (history && history.sessionData && history.sessionData.editType === "review") ? (
                        <div>
                        <Form>
                            
                            <Form.Group controlId="exampleForm.ControlTextarea1">
                            <Form.Label>Action</Form.Label>
                            <Form.Control as="select" value={reviewAction} onChange={(e) => setReviewAction(e.target.value)}>
                                <option value="APPROVED">Approve</option>
                                <option value="REJECTED">Reject</option>
                                <option value="ADDED_REMARKS">Add Remarks</option>
                            </Form.Control>
                            </Form.Group>
                            
                            {
                            reviewAction === "ADDED_REMARKS" && (
                                <Form.Group controlId="exampleForm.ControlTextarea1">
                                <Form.Label>Remarks</Form.Label>
                                <Form.Control as="textarea" rows="3" placeholder="Remarks" value={review} onChange={(e) => setReview(e.target.value)} />
                                </Form.Group>
                            )
                            }

                            <Button onClick={(e) => submitInterceptor(e, reviewAction, review)} variant='primary'>
                            Submit
                            </Button>
                            <Button onClick={denyReview} variant='secondary'>
                            Cancel
                            </Button>

                        </Form>
                        </div>
                    ) : (
                        <div>
                        {
                            ["ADDED_REMARKS", "APPROVED", "REJECTED"].includes(history.fileInfo && history.fileInfo.status) && (
                                <Form.Group controlId="exampleForm.ControlTextarea1">
                                <Form.Label>Added Remarks</Form.Label>
                                <Form.Control as="textarea" rows="3" placeholder="Remarks" readOnly value={review} />
                                </Form.Group>
                            )
                        }
                        <Button onClick={(e) => submitInterceptor(e, "SAVED", "")} variant='primary'>
                            Save
                        </Button>
                        <Button onClick={(e) => submitInterceptor(e, "SENT_FOR_REVIEW", "")} variant='primary'>
                            Save And Submit For Review
                        </Button>
                        <Button onClick={denyReview} variant='secondary'>
                            Cancel
                            </Button>
                        </div>
                    )
                    }
                </Col>
            </Row>
        </div>
    )
}

function mapStateToProps(state) {
    return state;
}

export default connect(mapStateToProps, null)(SubmitAndReview);