import React, {useState} from 'react';
import { Tab, Tabs, TabList, TabPanel } from 'react-tabs';
import BasicInfoTab from './Tabs/BasicInfoTab';
import TemplateInfoTab from './Tabs/templateInfoTab';
import NormalizationTab from './Tabs/normalizationab';
import HistoryTab from './Tabs/history';
import TopInfo from './Tabs/TopInfo';
import SubmitAndReview from './Tabs/SubmitAndReview';
function App() {

  const [tabIndex, selectTabIndex] = useState(0);
  return (
    <Tabs selectedIndex={tabIndex} onSelect={tabIndex => selectTabIndex(tabIndex)}>
      <TabList>
        <Tab>Basic Data</Tab>
        <Tab>Content Template</Tab>
        <Tab>Normalization</Tab>
        <Tab>History</Tab>
      </TabList>
      <TabPanel>
        <TopInfo />
        <BasicInfoTab />
        <SubmitAndReview />
      </TabPanel>
      <TabPanel>
        <TopInfo />
        <TemplateInfoTab />
        <SubmitAndReview />
      </TabPanel>
      <TabPanel>
        <TopInfo />
        <NormalizationTab />
        <SubmitAndReview />
      </TabPanel>
      <TabPanel>
        <HistoryTab selectTabIndex={selectTabIndex} />
      </TabPanel>
    </Tabs>
  );
}
export default App;
