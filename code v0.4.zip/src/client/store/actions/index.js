export const BasicDataChanged = (inputValue) => {
    return {
        type: 'BasicDataChanged',
        payload: inputValue
    }
}

export const TemplateDataChanged = (inputValue) => {
    return {
        type: 'TemplateDataChanged',
        payload: inputValue
    }
}
export const NormalizationDataChanged = (inputValue) => {
    return {
        type: 'NormalizationDataChanged',
        payload: inputValue
    }
}
export const NormalizationFormAdding = (formID) => {
    return {
        type: 'NormalizationFormAdded',
        payload: formID
    }
}
export const BasicDataLoaded = (BasicDataObject) => {
    return {
        type: 'BASICDATAFOUNDFROMYAML',
        payload: BasicDataObject
    }
}
export const NormalizationDataLoaded = (NormalizationDataObject) => {
    return {
        type: 'NORMALIZATIONDATAFOUNDFROMYAML',
        payload: NormalizationDataObject
    }
}
export const TemplateDataLoaded = (TemplateDataObject) => {
    return {
        type: 'TEMPLATEDATAFOUNDFROMYAML',
        payload: TemplateDataObject
    }
}
export const historyDataLoaded = (HistoryDataObject) => {
    return {
        type: 'HISTORYDATAFROMYAML',
        payload: HistoryDataObject
    }
}
