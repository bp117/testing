const Normalization = (state = [
    { id: 0, fieldName: '', order: '' }
], action) => {
    switch (action.type) {
        case "NormalizationFormAdded":
            return action.payload
            break;
        case "NormalizationDataChanged":
            state.map((item) => {
                if (item.id === action.payload.id) {
                    item[action.payload.name] = action.payload.inputValue
                }

            })
            return state
            break;
        case "NORMALIZATIONDATAFOUNDFROMYAML":
            return action.payload
            break;
        default:
            return state
            break;
    }
}
export default Normalization