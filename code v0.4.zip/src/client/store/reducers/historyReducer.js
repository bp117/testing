const BasicData = (state = {
    Edited: false,
    EditedAt: '',
    FileName: ''
}, action) => {
    switch (action.type) {
        case "HISTORYDATAFROMYAML":
            return action.payload
            break;

        default:
            return state
            break;
    }

}
export default BasicData