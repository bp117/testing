const TemplateData = (state = {
    // TemplateID: "",
    // XSLTTemplateID: "",
    // EngFromAddressLabel: "",
    // EngCustomerSegment: "",
    // EngLanguage: "",
    // SpaFromAddressLabel: "",
    // SpaCustomerSegment: "",
}, action) => {
    switch (action.type) {
        case "TemplateDataChanged":
            return { ...state, [action.payload.name]: action.payload.inputValue }
            break;
        case "TEMPLATEDATAFOUNDFROMYAML":
            return action.payload
            break;
        default:
            return state
            break;
    }

}
export default TemplateData