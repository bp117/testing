const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const fs = require('fs');
const app = express();
const YAML = require('yaml');
const { table } = require('console');
//joining path of directory 
// const directoryPath = path.join(__dirname, 'media');
//to handle JSON payloads
app.use(bodyParser.json());
/*
    Create a new file and dumping the yaml data into that file.
    and then returning the file path to the client.
 */
app.post('/api/createData', (req, res) => {
    function getDateString() {
        const date = new Date();
        const year = date.getFullYear();
        const month = `${date.getMonth() + 1}`.padStart(2, '0');
        const day = `${date.getDate()}`.padStart(2, '0');
        return `${year}${month}${day}`
    }
    let name = Math.random().toString(36).replace(/[^a-z]+/g, '').substr(0, 25) + getDateString()
    let dir = './media/' + name + '.yaml';
    const doc = new YAML.Document();
    doc.contents = req.body;
    // let yamlStr = yaml.safeDump(req.body);
    try {
        return new Promise(function (resolve, reject) {
            fs.writeFile(dir, doc.toString(), function (err) {
                if (err) reject(err);
                else resolve(dir);
            });
        }).then(data => {
            res.status(201).send(data)
        })
    } catch (err) {
        res.send(err);
    }

});
app.get("/api/getyamlfiles", (req, res) => {
    function createdDate(dir, file) {
        const { birthtime, size } = fs.statSync(dir + file)
        const FIlePath = dir + file;
        let fileData = {};
        if (fs.existsSync(FIlePath)) {
            const file = fs.readFileSync(FIlePath, 'utf8')
            let yml = YAML.parse(file)
            if(yml.History && yml.History.fileInfo){
                fileData = yml.History.fileInfo;
            }
        }
        if(!fileData.status){
            fileData.status = "SAVED";
        }
        return {
            name: file, 
            birthtime, 
            size: size / 1000 + 'kb',
            fileInfo: fileData
        }
    }
    let directoryPath = "./media/"
    //passsing directoryPath and callback function
    fs.readdir(directoryPath, function (err, files) {
        //handling error
        if (err) {
            return console.log('Unable to scan directory: ' + err);
        }
        let response = []
        //listing all files using forEach
        files.forEach(function (file) {
            // Do whatever you want to do with the file
            response.push(createdDate(directoryPath, file))
        });

        response = response.sort((a,b) => {
            return new Date(b.birthtime).getTime() - new Date(a.birthtime).getTime();
        });
        if (response.length > 0) {
            res.status(200).send(response)
        } else {
            res.status(300).send('no file found')
        }
    });
})
app.get('/api/:fileID', (req, res) => {
    var id = req.params.fileID
    let FIlePath = './media/' + id
    try {
        if (fs.existsSync(FIlePath)) {
            //file exists
            // res.status(200).send("file exists")
            const file = fs.readFileSync(FIlePath, 'utf8')
            let yml = YAML.parse(file)
            res.send(yml)
        }
    } catch (err) {
        res.status(400).send(err)
        console.error(err)
    }
})
app.delete('/api/:fileID', (req, res) => {
    var id = req.params.fileID
    let FIlePath = './media/' + id
    try {
        fs.unlinkSync(FIlePath)
        res.send({
            status: true,
            message: `File ${id} deleted successfully`
        })
    } catch (err) {
        res.status(400).send(err)
        console.error(err)
    }
})
app.put('/api/updateData', (req, res) => {
    // console.log(req.body.History)
    let FIlePath = './media/' + req.body.History.FileName
    if (fs.existsSync(FIlePath)) {
        const doc = new YAML.Document();
        doc.contents = req.body;
        try {
            return new Promise(function (resolve, reject) {
                fs.writeFile(FIlePath, doc.toString(), function (err) {
                    if (err) reject(err);
                    else resolve(FIlePath);
                });
            }).then(data => {
                res.status(201).send(data)
            })
        } catch (err) {
            res.send(err);
        }
    }

})
app.get('/api/download/yaml/:fileID', (req, res) => {
    var id = req.params.fileID
    let FIlePath = './media/' + id;
    try {
        if (fs.existsSync(FIlePath)) {
            const file = fs.readFileSync(FIlePath, 'utf8')
            let yml = YAML.parse(file);
            if(yml.History && yml.History.fileInfo){
                delete yml.History.fileInfo;
            }
            const doc = new YAML.Document();
            doc.contents = yml;
            res.send({yaml: doc.toString()})
        }
    } catch (err) {
        res.status(400).send(err)
        console.error(err)
    }
})

app.get('/api/download/sql/:fileID', (req, res) => {
    var id = req.params.fileID
    let FIlePath = './media/' + id;
    const pascalCaseToUnderscoreCase = (str) => str.replace(/\.?([A-Z]+)/g, function (x,y){return "_" + y.toLowerCase()}).replace(/^_/, "");
    try {
        if (fs.existsSync(FIlePath)) {
            const file = fs.readFileSync(FIlePath, 'utf8')
            let yml = YAML.parse(file)

            let allSqls = [];
            
            Object.keys(yml).forEach(tableName => {
                const column_names = [];
                const value_names = [];
                if(!["History", "Normalization"].includes(tableName)){
                    Object.entries(yml[tableName]).forEach(pairs => {
                        column_names.push(pascalCaseToUnderscoreCase(pairs[0]));
                        value_names.push(typeof pairs[1] === "string" ? `'${pairs[1]}'` : pairs[1]);
                    });

                    let finalSql = `INSERT into ${pascalCaseToUnderscoreCase(tableName)} (${column_names.join(", ")}) VALUES (${value_names.join(', ')});`
                    allSqls.push(finalSql);
                }

                if(tableName === "Normalization"){
                    yml[tableName].forEach((item, index) => {
                        Object.entries(item).forEach(pairs => {
                            column_names.push(pascalCaseToUnderscoreCase(pairs[0]+'_'+(index+1)));
                            value_names.push(typeof pairs[1] === "string" ? `'${pairs[1]}'` : pairs[1]);
                        });
                    });
                    let finalSql = `INSERT into ${pascalCaseToUnderscoreCase(tableName)} (${column_names.join(", ")}) VALUES (${value_names.join(', ')});`
                    allSqls.push(finalSql);
                }


            });


            res.send({sql: allSqls.join('\n\n\n')})
        }
    } catch (err) {
        res.status(400).send(err)
        console.error(err)
    }
})
app.use(express.static('public'));

app.use((req, res, next) => {
    res.sendFile(path.resolve(__dirname, '..', '..', 'public', 'index.html'));
});


module.exports = app;