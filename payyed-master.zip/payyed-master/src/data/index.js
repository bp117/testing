export default {
  defaultTitle: "Payyed - Quickly Send & Receive Money",
  logo: "",
  author: "",
  url: "",
  legalName: "",
  defaultDescription:
    "Quickly and easily send, receive and request money online with Payyed. Over 180 countries and 120 currencies supported.",
  socialLinks: {
    facebook: "http://www.facebook.com/",
    twitter: "http://www.twitter.com/",
    google: "http://google.com/",
    youtube: "http://youtube.com/"
  },
  googleAnalyticsID: "",
  themeColor: "#2dbe60",
  backgroundColor: "#ffffff",
  social: {
    facebook: "",
    twitter: "",
    google: "",
    youtube: ""
  },
  address: {
    city: "",
    region: "",
    country: "",
    zipCode: ""
  },
  contact: {
    email: "",
    phone: ""
  },
  foundingDate: "2019",
  recaptcha_key: ""
}
