import styled from "styled-components"

export const Wrapper = styled.div`
  position: relative;
  z-index: 4;
  background-color: #ffffff;
  width: 100%;
`