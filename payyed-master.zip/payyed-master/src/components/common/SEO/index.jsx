import React from "react"
import { Helmet } from "react-helmet"
import data from "data"

const {
  defaultTitle,
  defaultDescription,
  legalName,
  url,
  logo,
  themeColor,
  foundingDate,
  contact,
  address,
  socialLinks,
  social
} = data

export function SEO({
  title = defaultTitle,
  description = defaultDescription,
  location = ""
}) {
  const structuredDataOrganization = `{ 
		"@context": "http://schema.org",
		"@type": "Organization",
		"legalName": "${legalName}",
		"url": "${url}",
		"logo": "${logo}",
		"foundingDate": "${foundingDate}",
		"founders": [{
			"@type": "Person",
			"name": "${legalName}"
		}],
		"contactPoint": [{
			"@type": "ContactPoint",
			"email": "${contact.email}",
			"telephone": "${contact.phone}",
			"contactType": "customer service"
		}],
		"address": {
			"@type": "PostalAddress",
			"addressLocality": "${address.city}",
			"addressRegion": "${address.region}",
			"addressCountry": "${address.country}",
			"postalCode": "${address.zipCode}"
		},
		"sameAs": [
      "${socialLinks.facebook}",
			"${socialLinks.twitter}",
			"${socialLinks.google}",
			"${socialLinks.youtube}"
		]
  	}`
  return (
    <Helmet>
      <meta name="theme-color" content={themeColor} />
      <meta name="description" content={description} />
      <meta name="image" content="" />
      <meta property="og:url" content={`${url}${location}/?ref=victortavarez.dev`}/>
      <meta property="og:type" content="website" />
      <meta property="og:title" content={title} />
      <meta property="og:description" content={description} />
      <meta property="og:image" content="" />
      <meta property="fb:app_id" content={social.facebook} />
      <meta name="twitter:card" content="summary" />
      <meta name="twitter:creator" content={socialLinks.twitter} />
      <meta name="twitter:site" content={social.twitter} />
      <meta name="twitter:title" content={title} />
      <meta name="twitter:description" content={description} />
      <meta name="twitter:image:src" content="" />
      <script type="application/ld+json">{structuredDataOrganization}</script>
      <link rel="publisher" href={socialLinks.google} />
      <title>{title}</title>
      <html lang="en" dir="ltr" />
    </Helmet>
  )
}
