export default [
  {
    title: "Security",
    href: "#"
  },
  {
    title: "Terms",
    href: "#"
  },
  {
    title: "Privacy",
    href: "#"
  }
]