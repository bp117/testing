export default [
  {
    title: "About Us",
    href: "#"
  },
  {
    title: "Support",
    href: "#"
  },
  {
    title: "Help",
    href: "#"
  },
  {
    title: "Careers",
    href: "#"
  },
  {
    title: "Affiliate",
    href: "#"
  },
  {
    title: "Fees",
    href: "#"
  }
]