export default [
  {
    alt: "Facebook",
    icon: "facebook-f"
  },
  {
    alt: "Twitter",
    icon: "twitter"
  },
  {
    alt: "Google",
    icon: "google"
  },
  {
    alt: "Youtube",
    icon: "youtube"
  }
]
