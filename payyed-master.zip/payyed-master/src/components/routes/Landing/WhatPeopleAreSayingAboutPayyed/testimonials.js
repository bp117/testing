export default [
 {
  user: "De Mortel",
  review: "“Fast easy to use transfers to a different currency. Much better value that the banks.”",
  location: "Online Retail"
 },
 {
  user: "Chris Tom",
  review: "“I have used them twice now. Good rates, very efficient service and it denies high street banks an undeserved windfall. Excellent.”",
  location: "User from UK"
 },
 {
  user: "Mauri Lindberg",
  review: "“It's a real good idea to manage your money by payyed. The rates are fair and you can carry out the transactions without worrying!”",
  location: "Freelancer from Australia"
 },
 {
  user: "Dennis Jacques",
  review: "“Only trying it out since a few days. But up to now excellent. Seems to work flawlessly. I'm only using it for sending money to friends at the moment.”",
  location: "User from USA"
 },
 {
  user: "Jay Shah",
  review: "“Easy to use, reasonably priced simply dummy text of the printing and typesetting industry. Quidam lisque persius interesset his et, in quot quidam possim iriure.”",
  location: "Founder at Icomatic Pvt Ltd"
 },
 {
  user: "Patrick Cary",
  review: "“I am happy Working with printing and typesetting industry. Quidam lisque persius interesset his et, in quot quidam persequeris essent possim iriure.”",
  location: "Freelancer from USA"
 }
]