export default [
  {
    icon: "share-square",
    alt: "Send Money"
  },
  {
    icon: "check-square",
    alt: "Receive Money"
  },
  {
    icon: "user-friends",
    alt: "Pay a Friend"
  },
  {
    icon: "shopping-bag",
    alt: "Online Shopping"
  }
]