export default [
  {
    icon: "hand-pointer",
    title: "Easy to use",
    description: "Lisque persius interesset his et, in quot quidam persequeris vim, ad mea essent possim iriure.",
  },
  {
    icon: "reply",
    flipIcon: "horizontal",
    title: "Faster Payments",
    description: "Lisque persius interesset his et, in quot quidam persequeris vim, ad mea essent possim iriure.",
  },
  {
    icon: "dollar-sign",
    title: "Lower Fees",
    description: "Lisque persius interesset his et, in quot quidam persequeris vim, ad mea essent possim iriure.",
  },
  {
    icon: "lock",
    title: "100% secure",
    description: "Lisque persius interesset his et, in quot quidam persequeris vim, ad mea essent possim iriure.",
  }
]