import styled from "styled-components"

export const Title = styled.h2`
  font-family: "rubikregular", sans-serif;
  font-size: 2rem;
  margin-bottom: 1rem;
`