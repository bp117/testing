import React, { Fragment } from 'react'
import PersonalDetails from "./PersonalDetails"

export default function Account(){
    return (
        <Fragment>
            <PersonalDetails />
        </Fragment>
    )
}