# Payyed

## Money transfer & online payments application

### Features :
- Scores 100% on a11y/Performance/SEO
- Tablet and mobile friendly
- Form handling via Formik and Yup
- Functional components with React Hooks!
- State management via React Context!
- CSS with Styled Components
- Eslint configured
- Nice project structure





