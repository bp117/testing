const express = require("express");
var cors = require("cors");

const userRoutes = require("../routes/user");

const morganMiddleware = require("../middleware/morgan");

module.exports = function (app) {
  app.use(express.json());
  app.use(cors());
  app.use(morganMiddleware);
  app.use("/user/", userRoutes);
};
