const mongoose = require("mongoose");

const AccountSchema = new mongoose.Schema({
  rootKey: {
    type: mongoose.Schema.Types.Mixed,
    // required: true,
  },
  accountOnePrivateKey: {
    type: String,
    required: true,
  },
});

const Account = mongoose.model("Account", AccountSchema);

module.exports = Account;
