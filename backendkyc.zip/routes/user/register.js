const express = require("express");
const router = express.Router();

const bcrypt = require("bcryptjs");
const Account = require("../../models/account");
const {
  _generateMnemonic,
  _getHdRootKey,
  _generatePrivateKey,
} = require("../../utils");

router.post("/get-phrase", async (req, res, next) => {
  try {
    const { mnemonic, entropy } = _generateMnemonic();

    const hdRootKey = _getHdRootKey(entropy);

    const accountOneIndex = 0;
    const accountOnePrivateKey = _generatePrivateKey(
      hdRootKey,
      accountOneIndex
    );

    const user = new Account({
      accountOnePrivateKey,
    });

    await user.save();

    return res.status(200).json({
      success: true,
      mnemonic,
      message: "Phrase generated",
    });
  } catch (err) {
    console.log("err ", err);
    res.status(500).send({
      error: "Internal Server error",
      message: err?.message,
      detail: err.message || err,
    });
  }
});

module.exports = router;
