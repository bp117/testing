const express = require("express");
const router = express.Router();

const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const Account = require("../../models/account");

const { check, validationResult } = require("express-validator");
const { _generatePrivateKey, _getHdRootKey } = require("../../utils");

const { mnemonicToEntropy } = require("ethereum-cryptography/bip39");
const { wordlist } = require("ethereum-cryptography/bip39/wordlists/english");

router.post(
  "/",
  check("mnemonic", "Phrase not submitted").notEmpty(),
  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }

      const { mnemonic } = req.body;

      const entropy = mnemonicToEntropy(mnemonic, wordlist);
      const hdRootKey = _getHdRootKey(entropy);
      const privateKey = hdRootKey.deriveChild(0).privateKey;

      const privateKeyString = privateKey?.join(",");

      let user = await Account.findOne({
        accountOnePrivateKey: privateKeyString,
      });

      if (!user) {
        return res.status(400).json({ errors: [{ msg: "Wallet not found" }] });
      }

      const payload = {
        user: {
          id: user.id,
        },
      };

      const token = jwt.sign(payload, process.env.JWT_SECRET, {
        expiresIn: "1 day",
      });
      const refreshToken = jwt.sign(payload, process.env.JWT_REFRESH_SECRET, {
        expiresIn: "30 days",
      });

      if (token && refreshToken) {
        return res.status(200).json({
          message: "Account login successful",
          token,
          refreshToken,
        });
      } else {
        return res.status(400).json({
          error: "Error occured while signing token",
        });
      }
    } catch (err) {
      res.status(500).send({
        error: "Internal Server error",
        message: err?.message,
        detail: err.message || err,
      });
    }
  }
);

module.exports = router;
