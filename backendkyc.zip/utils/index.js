const {
  generateMnemonic,
  mnemonicToEntropy,
} = require("ethereum-cryptography/bip39");
const { wordlist } = require("ethereum-cryptography/bip39/wordlists/english");
const { HDKey } = require("ethereum-cryptography/hdkey");

const _generateMnemonic = () => {
  const strength = 128; // 256 bits, 24 words; default is 128 bits, 12 words
  const mnemonic = generateMnemonic(wordlist, strength);
  const entropy = mnemonicToEntropy(mnemonic, wordlist);
  return { mnemonic, entropy };
};

const _getHdRootKey = (_mnemonic) => {
  return HDKey.fromMasterSeed(_mnemonic);
};

function _generatePrivateKey(_hdRootKey, _accountIndex) {
  return _hdRootKey.deriveChild(_accountIndex).privateKey;
}

module.exports = {
  _generateMnemonic,
  _getHdRootKey,
  _generatePrivateKey,
};
