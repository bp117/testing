import * as React from 'react'

import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/Card';

import SuccessSvg from '../assets/svgs/verify-success.svg'

import { Link } from 'react-router-dom';
import ProgressBars from '../components/UI/ProgressBars';

const VerifySuccess = (props) => {

    return (
        <div className='h-100 w-100 px-3 py-3'>
            <div className='d-flex flex-column align-items-center'>
                <ProgressBars
                    totalProgress={3}
                />
                <h3 className='mt-4' ><strong>Success</strong></h3>
                <p>Your wallet successfully created.</p>
                <img className='my-5' src={SuccessSvg} />
            </div>

            <Card style={{
                width: '100%',
                borderColor: '#1D78D0',
                backgroundColor: '#F1F7FF',
                color: '#1D78D0'
            }} className='w-100 p-2'>
                <Card.Title className='text-center'>Information</Card.Title>
                <Card.Body className='text-center'>
                    You wallet is 100% safe and fully-encrypted.
                </Card.Body>
            </Card>
            <div className='d-flex flex-column align-items-center w-100 mt-5' >
                <Link className='w-100' style={{ maxWidth: 400 }} to='/dashboard/wallet'>
                    <Button
                        className='w-100'
                        variant="primary">Done</Button>
                </Link>
            </div>
        </div>
    )
}

export default VerifySuccess