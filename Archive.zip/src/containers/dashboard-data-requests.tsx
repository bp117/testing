import * as React from 'react'

import NewRequest from '../components/forms/NewRequest'
import DeleteRequest from '../components/items/DeleteRequest'

import CopyIcon from '../assets/svgs/copy-icon.svg'

const DataRequests = (props) => {
    const [showForm, setShowForm] = React.useState(false)

    const renderRequests = () => {
        return (
            <DeleteRequest />
        )
    }

    return (
        <div className='w-100'>
            {showForm ? <NewRequest
                onHide={() => setShowForm(false)}
            /> :
                <div className='w-100' >
                    <div className='d-flex align-items-center justify-content-between my-2 px-3'>
                        <div />
                        <div>All Data Delete Requests</div>
                        <img
                            role='button'
                            onClick={() => setShowForm(true)}
                            src={CopyIcon} />
                    </div>
                    {renderRequests()}
                </div>
            }
        </div>
    )
}

export default DataRequests