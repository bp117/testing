import * as React from 'react'
import Button from 'react-bootstrap/Button';
import { Link } from 'react-router-dom';

import classes from './home.module.css'

import KeyFinderSvg from '../../assets/svgs/key-finder.svg'

const Home = (props) => {

    return (
        <div className={classes['container']} >
            <div className='d-flex flex-column justify-content-center align-items-center flex-grow-1' >
                <img src={KeyFinderSvg} />
                <h3 className='text-light'>KYC Wallet</h3>
                <p className='text-light'>Interbank Data Sharing Platform</p>
            </div>
            <div className='d-flex flex-column justify-content-center align-items-center' >
                <Link
                    className={classes['button-container']}
                    to='/create-wallet'>
                    <Button className='w-100' style={{ color: '#021F65' }} variant="light">Create new wallet</Button>
                </Link>
                <p className='text-light mt-3'>Restore wallet</p>
            </div>
        </div>
    )
}

export default Home