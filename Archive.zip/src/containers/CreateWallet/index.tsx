import * as React from 'react'

import history from "history/browser";
import { Link, useNavigate } from 'react-router-dom';

import { toast } from 'react-toastify'

import ArrowLeft from '../../assets/svgs/arrow-left.svg'

import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/Card';

import ProgressBars from '../../components/UI/ProgressBars';

import classes from './createwallet.module.css'
import { useGetPhraseMutation } from '../../redux/rtk-query/user';

const CreateWallet = (props) => {
    const [getPhrase, getPhraseResult] = useGetPhraseMutation();

    const navigate = useNavigate()

    React.useEffect(() => {
        getPhrase(null)
    }, [])


    const mnemonic = getPhraseResult?.data?.mnemonic
    let words = []
    if (mnemonic) {
        words = mnemonic.split(' ')
    }

    const copyToClipboard = () => {
        const text = words.join(" ")
        navigator.clipboard.writeText(text);

        toast.success('Phrase copied!', {
            position: "top-right",
            autoClose: 800,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
        });
    }

    const goToNext = () => {
        navigate('/verify-key', {
            state: {
                words
            }
        })
    }

    const renderWords = () => {
        return (
            <div className='d-flex flex-wrap gap-1'>
                {words.map((word, index) => {
                    return (
                        <div
                            key={word}
                            className={classes['word-container']}>{index + 1}: {word}</div>
                    )
                })}
            </div>
        )
    }

    return (
        <div className='h-100 w-100 px-3 py-3'>
            <div className='d-flex align-items-center mb-2'>
                <img
                    onClick={() => history.back()}
                    role="button" src={ArrowLeft} />
                <div className='mx-auto'>
                    <ProgressBars
                        totalProgress={0.4}
                    />
                </div>
            </div>
            <div className='d-flex flex-column align-items-center'>
                <h3 ><strong>Create a wallet</strong></h3>
                <p className={classes['grey-text']}>Write down or save these words in the right order and place them somewhere safe.</p>
                {renderWords()}
                {getPhraseResult.isLoading && <div className='text-center'>Loading</div>}
                <div
                    onClick={copyToClipboard}
                    role='button'
                    style={{ color: '#1D78D0' }}
                    className='mt-5 mb-5'>COPY</div>
                <Card style={{
                    width: 'w-100',
                    color: '#E51111',
                    borderColor: '#E51111', backgroundColor: '#FFF8F8'
                }} className='mb-3'>

                    <Card.Body>
                        <Card.Title className='font-weight-bold text-center' >Warning</Card.Title>
                        <Card.Text className='text-center'>
                            Don’t share your key phrase.<br />
                            If somebody have your key phrase, they will able to control your wallet.
                        </Card.Text>
                    </Card.Body>
                </Card>
                <div className='d-flex flex-column align-items-center w-100 mt-4' >
                    <Button
                        style={{ maxWidth: 400 }}
                        onClick={goToNext}
                        className={'mt-4 w-100'} variant="primary">Continue</Button>

                </div>
            </div>


        </div>

    )
}

export default CreateWallet