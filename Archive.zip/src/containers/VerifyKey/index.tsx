import * as React from 'react'

import history from "history/browser";
import { Link, useLocation, useNavigate } from 'react-router-dom';

import { toast } from 'react-toastify'

import ArrowLeft from '../../assets/svgs/arrow-left.svg'

import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/Card';

import ProgressBars from '../../components/UI/ProgressBars';

import classes from './verify.module.css'
import { useLoginMutation } from '../../redux/rtk-query/user';
import { useDispatch } from 'react-redux';
import { loginSuccess } from '../../redux/userSlice';

function shuffle(originalArray) {
    var array = [].concat(originalArray);
    var currentIndex = array.length, temporaryValue, randomIndex;

    // While there remain elements to shuffle...
    while (0 !== currentIndex) {

        // Pick a remaining element...
        randomIndex = Math.floor(Math.random() * currentIndex);
        currentIndex -= 1;

        // And swap it with the current element.
        temporaryValue = array[currentIndex];
        array[currentIndex] = array[randomIndex];
        array[randomIndex] = temporaryValue;
    }

    return array;
}

const VerifyKey = (props) => {
    const location: any = useLocation();
    const navigate = useNavigate()

    const dispatch = useDispatch()

    const [login, loginResult] = useLoginMutation();

    const words = location?.state?.words || []

    const [pickedWords, setPickedWords] = React.useState([])

    const [unPickedWords, setUnpickedWords] = React.useState([])

    React.useEffect(() => {
        let shuffled = shuffle(words)
        setUnpickedWords(shuffled)
    }, [])

    const addToPicked = (word) => {
        let unpicked = [...unPickedWords];
        let picked = [...pickedWords]

        picked.push(word)
        unpicked = unpicked.filter((e) => { return e !== word })

        setUnpickedWords(unpicked)
        setPickedWords(picked)
    }

    const removeFromPicked = (word) => {
        let unpicked = [...unPickedWords];
        let picked = [...pickedWords]

        picked = picked.filter((e) => { return e !== word })
        unpicked.push(word)

        setUnpickedWords(unpicked)
        setPickedWords(picked)
    }

    const compareResult = () => {
        const original = location?.state?.words?.join(',')
        const answer = pickedWords?.join(',')

        if (answer != original) {
            toast.error('Phrase does not match!', {
                position: "top-right",
                autoClose: 900,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });

            return false
        }

        return true
    }

    const goToNext = async () => {
        // compare with phrase from previous page
        if (!compareResult()) return

        //login
        const body = {
            mnemonic: pickedWords.join(" ")
        }

        const res: any = await login(body)

        if (res?.data) {
            navigate('/verify-success')
            setTimeout(() => {
                dispatch(loginSuccess(res?.data))
            }, 1000)
        }


    }

    const renderPickedWords = () => {
        return (
            <div style={{ maxWidth: 600 }} className='mb-4 w-100'>
                <Card style={{
                    width: '100%',
                    borderColor: '#1D78D0', backgroundColor: '#F1F7FF'
                }} className='w-100'>

                    <Card.Body className='d-flex flex-wrap gap-1 w-1-'>
                        {pickedWords.map((word, index) => {
                            return (
                                <div
                                    key={word}
                                    onClick={() => removeFromPicked(word)}
                                    className={classes['word-container']}> {word}</div>
                            )
                        })}
                    </Card.Body>
                </Card>
                <div className={classes['grey-text']}>{pickedWords.length}/{words.length} completed</div>
            </div>
        )
    }

    const renderUnpickedWords = () => {
        return (
            <div className='d-flex flex-wrap gap-1'>
                {unPickedWords.map((word, index) => {
                    return (
                        <div
                            key={word}
                            onClick={() => addToPicked(word)} className={classes['word-container']}> {word}</div>
                    )
                })}
            </div>
        )
    }

    return (
        <div className='h-100 w-100 px-3 py-3'>
            <div className='d-flex align-items-center mb-2'>
                <img
                    onClick={() => history.back()}
                    role="button" src={ArrowLeft} />
                <div className='mx-auto'>
                    <ProgressBars
                        totalProgress={1.4}
                    />
                </div>
            </div>
            <div className='d-flex flex-column align-items-center'>
                <h3 ><strong>Verify Key Phrase</strong></h3>
                <p className={classes['grey-text']}>Tap the words to put them in the correct order.</p>
                {renderPickedWords()}
                {renderUnpickedWords()}


                <Button
                    onClick={goToNext}
                    className='w-100 mt-5'
                    style={{ maxWidth: 400 }}
                    disabled={pickedWords.length < 12}
                    variant="primary">Verify</Button>

            </div>


        </div>

    )
}

export default VerifyKey