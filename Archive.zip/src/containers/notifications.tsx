import * as React from 'react'
import history from "history/browser";

import classes from './notifications.module.css'

import ArrowLeft from '../assets/svgs/arrow-left-white.svg'
import BinIcon from '../assets/svgs/bin-icon.svg'

import NotificationItem from '../components/items/NotificationItem';


const Notifications = (props) => {

    const renderNotifications = () => {
        return (
            <div style={{ backgroundColor: '#F8F8F8D1' }}>
                <NotificationItem />
            </div>
        )
    }

    return (
        <div
            className={classes['container']}
        >
            <div className={classes['header']}>
                <div className='d-flex justify-content-between mx-4'>
                    <img
                        onClick={() => history.back()}
                        role='button'
                        className={classes['icon']} src={ArrowLeft} />
                </div>
                <div className='d-flex justify-content-between align-items-center mx-4'>
                    <h3>Notifications</h3>
                    <div
                        onClick={() => history.back()}
                        role='button'
                        className={classes['icon-wrapper']}>
                        <img

                            className={classes['icon']} src={BinIcon} />
                    </div>
                </div>
            </div>
            {renderNotifications()}
        </div>
    )
}

export default Notifications