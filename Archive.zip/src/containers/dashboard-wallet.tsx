import * as React from 'react'
import InfoItem from '../components/items/InfoItem'

const information = [
    {
        title: "Name",
        value: "Robert Arnold",
        date: "08/07/2022 10:15",
        verifier: "Wells Fargo"
    },
    {
        title: "Phone",
        value: "+1 205-435-3489",
        date: "08/07/2022 10:15",
        verifier: "Wells Fargo"
    },
    {
        title: "Email",
        value: "robert.arnold@gmail.com",
        date: "08/07/2022 10:15",
        verifier: "Wells Fargo"
    },
    {
        title: "Marital Status",
        value: "Married",
        date: "08/07/2022 10:15",
        verifier: "Wells Fargo"
    },
]


const Wallet = (props) => {

    const renderVerifiedInfo = () => {
        return (
            information.map((info,) => {
                return (
                    <InfoItem
                        key={info.title}
                        data={info}
                    />
                )
            })
        )
    }

    return (
        <div className='w-100'>
            <div className='text-center my-2'>
                Verified Information
            </div>
            {renderVerifiedInfo()}
        </div>
    )
}

export default Wallet