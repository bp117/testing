import * as React from 'react'

import Tab from 'react-bootstrap/Tab';
import Tabs from 'react-bootstrap/Tabs';
import Nav from 'react-bootstrap/Nav';

import KycRequest from '../components/items/KycRequest'

import classes from './kyc-requests.module.css'

const KycRequests = (props) => {
    const [activeKey, setActive] = React.useState('pending')

    const renderPending = () => {
        return (
            <KycRequest />
        )
    }

    const routes = [
        {
            eventKey: 'pending',
            count: 1,
        },
        {
            eventKey: 'approved'
        },
        {
            eventKey: "rejected"
        }
    ]

    const capitalize = (word) => {
        return word.charAt(0).toUpperCase() + word.slice(1);
    }

    return (
        <div className='w-100'>
            <Tab.Container
                defaultActiveKey='pending'>
                <div className={"d-flex align-items-center " + classes['tab-heading-container']}>
                    {routes.map((route) => {
                        const active = activeKey == route.eventKey
                        return (
                            <div
                                onClick={() => setActive(route.eventKey)}
                                key={route.eventKey}
                                style={active ? {
                                    border: '2px solid #355D9B',
                                    borderTop: 0,
                                    borderRight: 0,
                                    borderLeft: 0,
                                } : {}}
                            >
                                <Nav.Link eventKey={route.eventKey}>{capitalize(route.eventKey)}</Nav.Link>
                                <div className={classes['count-container']}>{route.count ? route.count : 0}</div>
                            </div>
                        )
                    })}
                </div>
                <Tab.Content>
                    <Tab.Pane eventKey="pending" title="Pending">
                        {renderPending()}
                    </Tab.Pane>
                    <Tab.Pane eventKey="approved" title="Approved">

                    </Tab.Pane>
                    <Tab.Pane eventKey="rejected" title="Rejected">

                    </Tab.Pane>
                </Tab.Content>
            </Tab.Container>
        </div>
    )
}

export default KycRequests