import * as React from "react";

import { Navigate, Route, Routes } from "react-router-dom";

import Welcome from "../containers/Welcome";
import CreateWallet from "../containers/CreateWallet";
import VerifyKey from "../containers/VerifyKey";
import VerifySuccess from "../containers/verify-success";
import Notifications from "../containers/notifications";

import DashboardKyc from '../containers/dashboard-kyc-requests'
import DashboardDataRequests from '../containers/dashboard-data-requests'
import DashboardWallet from '../containers/dashboard-wallet'

// layout
import DefaultLayout from "../layouts/default";
import DashboardLayout from "../layouts/dashboard";
import { useSelector } from "react-redux";

const RootRouter = (props) => {
    const userReducer = useSelector((state: any) => state.user)

    return (
        <Routes>
            <Route path="/" element={
                <LoggedOutRoutes
                    loggedIn={userReducer.loggedIn}
                >
                    <DefaultLayout />
                </LoggedOutRoutes>
            }>
                <Route path="" element={<Welcome />} />
                <Route path="create-wallet" element={<CreateWallet />} />
                <Route path="verify-key" element={<VerifyKey />} />

            </Route>
            <Route path="/verify-success" element={<VerifySuccess />} />
            <Route path="/dashboard" element={
                <LoggedInRoutes
                    loggedIn={userReducer.loggedIn}
                >
                    <DashboardLayout />
                </LoggedInRoutes>
            }>
                <Route path="kyc" element={<DashboardKyc />} />
                <Route path="wallet" element={<DashboardWallet />} />
                <Route path="data-requests" element={<DashboardDataRequests />} />
            </Route>
            <Route path="notifications" element={<Notifications />} />
            <Route
                path="*"
                element={
                    <main style={{ padding: "1rem" }}>
                        <p>There's nothing here!</p>
                    </main>
                }
            />
        </Routes>
    )
}

const LoggedInRoutes = ({ loggedIn, children }) => {
    if (!loggedIn) {
        return <Navigate to="/" replace />;
    }

    return children;
};

const LoggedOutRoutes = ({ loggedIn, children }) => {
    if (loggedIn) {
        return <Navigate to="/dashboard" replace />;
    }

    return children;
};

export default RootRouter