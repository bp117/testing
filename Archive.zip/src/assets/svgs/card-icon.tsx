import * as React from "react"

const SvgComponent = (props) => (
  <svg
    width={29}
    height={21}
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    {...props}
  >
    <path
      d="M24.904.78H4.716C2.165.78.83 2.047.83 4.466v1.017h27.96V4.465c0-2.419-1.323-3.684-3.886-3.684ZM5.768 16.749c-.697 0-1.17-.44-1.17-1.085v-2.09c0-.633.473-1.085 1.17-1.085h2.894c.685 0 1.157.452 1.157 1.085v2.09c0 .644-.472 1.085-1.157 1.085H5.768Zm-1.052 3.616h20.188c2.563 0 3.886-1.277 3.886-3.695V8.137H.83v8.532c0 2.43 1.335 3.695 3.886 3.695Z"
      fill={props.fill}
    />
  </svg>
)

export default SvgComponent
