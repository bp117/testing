import * as React from "react"

const SvgComponent = (props) => (
  <svg width={22} height={20} fill="none"
    xmlns="http://www.w3.org/2000/svg"
    {...props}
  >
    <path d="M19 11.995a1 1 0 0 0-1 1v4a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1v-9.59l5.88 5.89a3 3 0 0 0 4.24 0l1.64-1.64a1.004 1.004 0 1 0-1.42-1.42l-1.64 1.64a1 1 0 0 1-1.4 0l-5.89-5.88H10a1 1 0 1 0 0-2H3a3 3 0 0 0-3 3v10a3 3 0 0 0 3 3h14a3 3 0 0 0 3-3v-4a1 1 0 0 0-1-1Zm1.71-8.71-3-3a1 1 0 0 0-.33-.21 1 1 0 0 0-.76 0 1 1 0 0 0-.33.21l-3 3a1.004 1.004 0 0 0 1.42 1.42l1.29-1.3v5.59a1 1 0 0 0 2 0v-5.59l1.29 1.3a1 1 0 0 0 1.639-.325 1 1 0 0 0-.219-1.095Z" fill={props.fill} />
  </svg>
)

export default SvgComponent
