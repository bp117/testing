import * as React from 'react'

import classes from './item.module.css'

import Checkmark from '../../../assets/svgs/checkmark.svg'

const NotificationItem = (props) => {

    return (
        <div className={'d-flex align-items-center py-2 px-1 ' + classes['container']}>
            <div className={classes['icon']}>
                <img src={Checkmark} />
            </div>
            <div>
                <div className='font-italic'>Access Request</div>
                <div>JPMC request for KYC</div>
            </div>
        </div>
    )
}

export default NotificationItem