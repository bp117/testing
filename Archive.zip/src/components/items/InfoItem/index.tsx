import * as React from 'react'

import classes from './item.module.css'


const InfoItem = (props) => {
    const data = props?.data
    return (
        <div className={`mb-3 mx-3 py-2 px-2 ${classes['container']}`}>
            <div className={classes['heading']}>{data?.title}</div>
            <div className='d-flex align-items-center justify-content-between'>
                <div>{data?.value}</div>
                <div>Verified on</div>
            </div>
            <div className='d-flex align-items-center justify-content-between'>
                <div><strong>Verified by</strong> {data?.verifier}</div>
                <div>{data?.date}</div>
            </div>
        </div>
    )
}

export default InfoItem