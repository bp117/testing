import * as React from 'react'

import Accordion from 'react-bootstrap/Accordion';
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';

import { toast } from 'react-toastify';

import classes from './item.module.css'

const Item = props => {
    const defaultForm = {
        name: {
            label: 'NAME',
            checked: false,
        },
        phone: {
            label: 'PHONE',
            checked: false,
        },
        email: {
            label: 'EMAIL',
            checked: false,
        },
        marital: {
            label: 'MARITAL STATUS',
            checked: false,
        },
    }

    const selectAllRef = React.useRef<any>()
    const [form, setForm] = React.useState({})

    React.useEffect(() => {
        const newForm = { ...defaultForm }
        setForm(newForm)
    }, [])

    const selectAll = (checked) => {
        if (!checked) return;

        const newForm = { ...form }

        for (let key in newForm) {
            newForm[key].checked = true;
        }


        setForm(newForm)
    }


    const updateForm = (formKey, value) => {
        const newForm = { ...form }

        newForm[formKey].checked = value;

        if (!value && selectAllRef.current) {
            // reset general select all
            selectAllRef.current.checked = false

        }
        setForm(newForm)

    }

    const approve = async () => {
        toast.success('KYC request Approved successfully.', {
            position: "top-right",
            autoClose: 5000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
        });
    }

    return (
        <Accordion flush>
            <Accordion.Item eventKey="0">
                <Accordion.Header
                    as='div'
                >
                    <div className='d-flex gap-2 w-100'>
                        <div>432666</div>
                        <div>JPMC</div>
                    </div>
                </Accordion.Header>
                <Accordion.Body>
                    <div className='my-2'>Your KYC is being requested by <br /> JPMC</div>
                    <div className='my-2'>Requested on : 08/07/2022 11:41 AM</div>
                    <div className='d-flex  justify-content-between'>
                        <div >Requested Information</div>
                        <Form.Check
                            className={classes['checkbox-black']}
                            type={'checkbox'}
                            label={`SELECT ALL`}
                            ref={selectAllRef}
                            onChange={(e) => selectAll(e.currentTarget.checked)}
                        />
                    </div>
                    <div className={classes['checkbox-wrapper']}>
                        {Object.keys(form).map((key) => {
                            return (
                                <Form.Check
                                    key={key}
                                    type={'checkbox'}
                                    label={form[key].label}
                                    checked={form[key].checked}
                                    onChange={(e) => updateForm(key, e.currentTarget.checked)}
                                />
                            )
                        })}

                    </div>
                    <div className={'d-flex my-3 w-100 justify-content-around ' + classes['buttons-wrapper']}>
                        <Button style={{ color: '#021F65', borderColor: '#1D78D0' }} variant="light">Reject</Button>
                        <Button onClick={approve} variant="primary">Approve</Button>
                    </div>
                </Accordion.Body>
            </Accordion.Item>
        </Accordion>
    )
}

export default Item