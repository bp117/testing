import * as React from 'react'

import Accordion from 'react-bootstrap/Accordion';
import Form from 'react-bootstrap/Form';

import classes from './item.module.css'

const Item = props => {

    return (
        <Accordion flush>
            <Accordion.Item eventKey="0">
                <Accordion.Header
                    as='div'
                >
                    <div className='d-flex gap-2 w-100'>
                        <div>432666</div>
                        <div>JPMC</div>
                        <div className={classes['status']}>COMPLETED</div>
                    </div>
                </Accordion.Header>
                <Accordion.Body>
                    <div className='my-2'>Requested Information to Delete</div>
                    <div className={classes['checkbox-wrapper']}>
                        <Form.Check
                            type={'checkbox'}
                            label={`MARITAL STATUS`}
                            checked={true}
                            readOnly={true}
                        />
                    </div>
                    <div className='my-2'>Requested at: 08/08/2022 10:00 AM</div>
                    <div className='my-2'>Deleted at: 08/08/2022 11:00 AM</div>
                    <div className='my-2'>Remarks: Deleted as requested </div>
                    <div className='my-2'>Status: <span style={{ color: '#0C7853' }}>COMPLETE</span></div>
                </Accordion.Body>
            </Accordion.Item>
        </Accordion>
    )
}

export default Item