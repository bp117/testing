import React from "react";

import classes from "./progressbar.module.css";

const ProgressBar = (props) => {
  let { bgColor, completed } = props;
  if (parseFloat(completed) > 100) {
    completed = 100;
  }
  return (
    <div className={classes["container"]}>
      <div
        className={classes["filler"]}
        style={{ width: `${completed}%`, backgroundColor: bgColor }}
      >
        {/* <span
          className={classes["label-styles"]}
        >{`${completed}% staked`}</span> */}
      </div>
    </div>
  );
};

export default ProgressBar;
