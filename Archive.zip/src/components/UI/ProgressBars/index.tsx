import * as React from 'react'

import ProgressBar from '../ProgressBar'

import classes from './bars.module.css'

type Props = {
    totalProgress: number
}

const ProgressBars = (props: Props) => {
    const bgColor = "#1D78D0"
    const totalProgress = props.totalProgress

    const [percent1, setPercent1] = React.useState(0)
    const [percent2, setPercent2] = React.useState(0)
    const [percent3, setPercent3] = React.useState(0)

    React.useEffect(() => {
        if (totalProgress) {
            let totalPercent = 100 * totalProgress;
            //
            if (totalPercent <= 100) {
                setPercent1(totalPercent)
                setPercent2(0)
                setPercent3(0)
            }

            //
            if (totalPercent > 100 && totalPercent <= 200) {
                setPercent1(100)
                setPercent2(totalPercent % 100)
                setPercent3(0)
            }

            if (totalPercent > 200) {
                setPercent1(100)
                setPercent2(100)
                setPercent3(totalPercent % 200)
            }

        }
    }, [])

    return (
        <div
            style={{ maxWidth: 200, minWidth: 170 }}
            className={`d-flex align-items-center gap-2 w-100`}>
            <ProgressBar bgColor={bgColor} completed={percent1} />
            <ProgressBar bgColor={bgColor} completed={percent2} />
            <ProgressBar bgColor={bgColor} completed={percent3} />
        </div>
    )
}

export default ProgressBars