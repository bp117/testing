import * as React from 'react'
import { Link, useLocation } from 'react-router-dom'

import classes from './footer.module.css'

import InboxIn from '../../assets/svgs/inbox-in'
import InboxOut from '../../assets/svgs/inbox-out'
import CardIcon from '../../assets/svgs/card-icon'

const Footer = (props) => {
    const location = useLocation()
    const routes = [
        {
            title: 'Wallet',
            to: '/dashboard/wallet',
            svg: (color) => <CardIcon
                fill={color}
            />
        },
        {
            title: 'My Data Requests',
            to: '/dashboard/data-requests',
            svg: (color) => <InboxOut
                fill={color}
            />
        },
        {
            title: 'Bank KYC Requests',
            to: '/dashboard/kyc',
            svg: (color) => <InboxIn
                fill={color}
            />
        },
    ]

    return (
        <div className={classes['container']}>
            <div className='d-flex align-items-center justify-content-between'>
                {routes.map((route) => {
                    const active = location?.pathname?.includes(route.to);
                    const color = active ? '#1D78D0' : '#929DAE'
                    return (<Link
                        className={classes['link-item']}
                        to={route.to}
                        key={route.title}
                        style={{ color }}
                    >
                        {route.svg(color)}
                        <p>{route.title}</p>
                    </Link>)
                })}
            </div>
        </div>
    )
}

export default Footer