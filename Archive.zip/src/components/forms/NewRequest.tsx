import * as React from 'react';
import Button from 'react-bootstrap/Button';

import classes from './request.module.css'

import Accordion from 'react-bootstrap/Accordion';
import Form from 'react-bootstrap/Form';

import { toast } from 'react-toastify';

import { ElementType } from 'react';

const NewRequest = props => {
    const defaultForm = {
        marital: {
            wellsFargo: false,
            jpmc: false,
            selected: false,
            label: 'MARITAL STATUS',
            selectAllkey: 12
        },
        phone: {
            wellsFargo: false,
            jpmc: false,
            selected: false,
            label: 'PHONE NUMBER',
            selectAllkey: 11
        },
    }

    const selectAllRef = React.useRef<any>()
    const [form, setForm] = React.useState({})

    React.useEffect(() => {
        const newForm = { ...defaultForm }
        setForm(newForm)
    }, [])

    const selectAll = (checked, key) => {
        if (!checked) return;

        const newForm = { ...form }

        // if key is provided, select for just that entry
        if (key) {
            newForm[key].wellsFargo = true;
            newForm[key].jpmc = true;
        }
        else {
            // select across all entries
            for (let key in newForm) {
                newForm[key].selected = true;
            }
        }

        setForm(newForm)
    }

    const updateForm = (formKey, subKey, value) => {
        const newForm = { ...form }

        newForm[formKey][subKey] = value;

        if (!value && selectAllRef.current) {
            // reset general select all
            if (subKey == 'selected') {
                selectAllRef.current.checked = false
            }
            // reset local select all
            newForm[formKey]['selectAllkey'] = Math.floor(Math.random() * 1000)
        }
        setForm(newForm)

    }


    const deleteRequest = async () => {
        toast.success('Delete request sent succesfully.', {
            position: "top-right",
            autoClose: 5000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
        });

        setTimeout(() => {
            props.onHide()
        }, 1500)
    }

    const renderEntries = () => {

        return (
            <div>

                {Object.keys(form).map((key, index) => {
                    return (
                        <Accordion
                            key={key}
                            defaultActiveKey={key} flush>
                            <Accordion.Item
                                eventKey={key}>

                                <div
                                    className='d-flex align-items-center px-3'
                                >
                                    <div className='d-flex gap-3 flex-grow-1'>
                                        <Form.Check
                                            key={form[key].selectAllkey}
                                            className={classes['checkbox-black']}
                                            type={'checkbox'}
                                            label={form[key].label}
                                            checked={form[key].selected}
                                            onChange={(e) => updateForm(key, 'selected', e.currentTarget.checked)}
                                        />
                                    </div>

                                    <Accordion.Button
                                        as='div'
                                        onClick={() => {
                                            console.log('clicked')
                                        }}
                                        style={{
                                            borderWidth: 0,
                                            flex: 0.5,
                                            boxShadow: 'none'
                                        }}
                                    >

                                    </Accordion.Button>
                                </div>
                                <Accordion.Body>
                                    <div className='d-flex  justify-content-between'>
                                        <div>Shared To</div>
                                        <Form.Check
                                            key={form[key].selectAllkey}
                                            className={classes['checkbox-black']}
                                            type={'checkbox'}
                                            label={`SELECT ALL`}
                                            onChange={(e) => selectAll(e.currentTarget.checked, key)}
                                        />
                                    </div>
                                    <div className={classes['checkbox-wrapper']}>
                                        <Form.Check
                                            type={'checkbox'}
                                            label={`WELLS FARGO`}
                                            checked={form[key].wellsFargo}
                                            onChange={(e) => updateForm(key, 'wellsFargo', e.currentTarget.checked)}
                                        />
                                        <Form.Check
                                            type={'checkbox'}
                                            label={`JPMC`}
                                            checked={form[key].jpmc}
                                            onChange={(e) => updateForm(key, 'jpmc', e.currentTarget.checked)}
                                        />
                                    </div>
                                </Accordion.Body>
                            </Accordion.Item>
                        </Accordion>
                    )
                })}

            </div>
        )
    }

    return (
        <div className='w-100'>
            <div className='text-center'>
                Data Delete Requests
            </div>
            <div className={`${classes['heading']} my-2`} >New Request</div>
            <div className='p-3'>
                <div className='font-italic mb-2'>Create a new request for deletion</div>
                <div className='d-flex justify-content-between'>
                    <Form.Check
                        className={classes['checkbox-black']}
                        type={'checkbox'}
                        label={`SELECT ALL`}
                        onChange={(e) => selectAll(e.currentTarget.checked, null)}
                        ref={selectAllRef}
                    />
                </div>
            </div>
            {renderEntries()}
            <div className='d-flex flex-column align-items-center w-100 mt-3' >
                <Button
                    onClick={deleteRequest}
                    variant='primary' className='w-75 mx-auto'>
                    Request for Deletion
                </Button>
            </div>
        </div>
    )
}

export default NewRequest