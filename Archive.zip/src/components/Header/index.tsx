import * as React from 'react'
import { useDispatch } from 'react-redux'

import classes from './header.module.css'

import HeaderIcon from '../../assets/svgs/header-icon.svg'
import ChevronDown from '../../assets/svgs/chevron-down.svg'
import FilterIcon from '../../assets/svgs/filter.svg'
import BellIcon from '../../assets/svgs/bell.svg'
import { Link } from 'react-router-dom'
import { logoutSuccess } from '../../redux/userSlice'

const Header = (props) => {
    const dispatch = useDispatch()

    const logout = () => {
        dispatch(logoutSuccess())
    }

    return (
        <div className={classes['container']}>
            <div className='d-flex justify-content-between mx-4'>
                <img
                    role='button'
                    className={classes['icon']} src={FilterIcon} />
                <div className={classes['center-heading']}>
                    <div className={' d-flex align-items-center gap-1'}>
                        <div>Primary Wallet</div>
                        <img src={ChevronDown} />
                    </div>
                </div>
                <div className='d-flex gap-2'>
                    <Link to="/notifications">
                        <img
                            role='button'
                            src={BellIcon} className={classes['icon']} />
                    </Link>
                    <img
                        onClick={logout}
                        role='button'
                        src={HeaderIcon} className={classes['icon']} />
                </div>
            </div>
            <div className='mx-auto'>
                IDSP ID: IDSP43556
            </div>
        </div>
    )
}

export default Header