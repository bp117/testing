import React, { Component } from "react";
import { Outlet } from "react-router-dom";

import Header from "../components/Header";
import Footer from "../components/Footer";

import classes from "./dashboard.module.css";

class DefaultLayout extends Component {
    render() {
        return (
            <div className={classes["container"]}>
                <Header />
                <main>
                    <Outlet />
                </main>
                <Footer />
            </div>
        );
    }
}

export default DefaultLayout;
