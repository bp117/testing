import React, { Component } from "react";
import { Outlet } from "react-router-dom";


import classes from "./default.module.css";

class DefaultLayout extends Component {
    render() {
        return (
            <div className={classes["container"]}>
                <main>
                    <Outlet />
                </main>
            </div>
        );
    }
}

export default DefaultLayout;
