import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";

import { baseQueryWithReauth } from "./customUserBaseQuery";

export const userApi = createApi({
  reducerPath: "userApi",
  baseQuery: baseQueryWithReauth,
  tagTypes: ["Profile"],
  endpoints: (builder) => ({
    getPhrase: builder.mutation({
      query: () => {
        return {
          url: "user/get-phrase",
          method: "POST",
        };
      },
    }),
    login: builder.mutation({
      query: (body) => {
        return {
          url: "user/login",
          method: "POST",
          body,
        };
      },
    }),
  }),
});

export const { useLoginMutation, useGetPhraseMutation } = userApi;
