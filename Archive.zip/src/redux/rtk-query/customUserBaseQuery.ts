// @ts-nocheck
import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";
import axios from "axios";

const BASE_URL = "http://localhost:5000/";

// import { logoutSuccess, refreshTokenSuccess } from "../userSlice";

const logoutSuccess = () => {
  return {
    type: "userReducer/logoutSuccess",
  };
};

const refreshTokenSuccess = (payload) => {
  return {
    type: "userReducer/refreshTokenSuccess",
    payload,
  };
};

const baseQuery = fetchBaseQuery({
  baseUrl: BASE_URL,
  prepareHeaders: (headers, { getState }) => {
    // if (access_token) {
    // headers.set("Authorization", `Bearer ${access_token}`);
    // }
    return headers;
  },
});

export const baseQueryWithReauth = async (args, api, extraOptions) => {
  let result = await baseQuery(args, api, extraOptions);
  const { dispatch, getState } = api;
  if (result.error && result.error.originalStatus === 401) {
    const refreshToken = getState().user.userData?.refresh_token;

    const body = {
      refresh_token: refreshToken,
    };
    // try to get a new token
    const refreshResult = await axios
      .post(`${BASE_URL}/refresh-token`, body)
      .then((res) => {
        return res;
      })
      .catch((err) => err);
    if (refreshResult.data?.data) {
      dispatch(refreshTokenSuccess(refreshResult?.data?.data));
      // store the new token
      // retry the initial query
      result = await baseQuery(args, api, extraOptions);
    } else {
      dispatch(logoutSuccess());
    }
  }
  return result;
};
