import { createSlice, createAction, createStore } from "@reduxjs/toolkit";

import axios from "axios";

export type userState = {
  loggedIn: boolean;
  userData: undefined | userData;
};

export type userData = {};

let initialState: userState = {
  loggedIn: false,
  userData: undefined,
};

// custom created actions
export const appStarted = createAction("appStarted");
// export const updateDutyStartTime = createAction("updateDutyStartTime");

export const userSlice = createSlice({
  name: "userReducer",
  initialState,
  reducers: {
    loginSuccess: (state, action) => {
      state.loggedIn = true;
      state.userData = action.payload;
    },
    logoutSuccess: (state) => {
      state.loggedIn = false;
      state.userData = undefined;
    },
    //
    refreshTokenSuccess: (state, action) => {
      let newUserData = action.payload;

      state.userData = {
        ...state.userData,
        ...newUserData,
      };
    },
  },
});

export const { loginSuccess, logoutSuccess, refreshTokenSuccess } =
  userSlice.actions;
