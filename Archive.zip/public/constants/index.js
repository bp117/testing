
/**
 * Redux actions
 */
export const FETCH_APP_DATA_REQUEST = "FETCH_APP_DATA_REQUEST";
export const FETCH_APP_DATA_SUCCESS = "FETCH_APP_DATA_SUCCESS";
export const FETCH_APP_DATA_FAILURE = "FETCH_APP_DATA_FAILURE";

/**
 * API Endpoints
 */
export const ES_BASE_URL = `http://localhost:9200`;
export const APM_INDEX_URL = `${ES_BASE_URL}/{index}/_search`;