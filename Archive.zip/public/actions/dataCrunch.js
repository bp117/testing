// /**
//  * helper function which constructs graph data in a particular direction.
//  * 
//  * @param {Array} rData 
//  * @param {object} sId 
//  * @param {string} direction 
//  */
// function constructData(rData, sId, direction="up"){
//     console.log("RDATA ", rData)
//     let data = [], sourceId = sId, maxLoopIt=/*5000000*/500, maxLoopItCount=0;
    
//     let sourceIndex = direction == "up"? "parent.id" : "span.id";
//     let sourceIndex2 = sourceIndex == "span.id"? "transaction.id" : "";

//     let targetIndex = direction == "up"? "span.id" : "parent.id";
//     let targetIndex2 = direction === "span.id"? "transaction.id" : "";

//     console.log("SOURCE INDEX ", sourceIndex, ", DEST INDEX ", targetIndex)

//     while (maxLoopItCount<maxLoopIt){
//         let sourceNode = rData.find(t=>t[sourceIndex2] == sourceId || t[sourceIndex] == sourceId );
//         if(sourceNode){
//             let targetNode = rData.find(t=>t[targetIndex2] == sourceId || t[targetIndex] == sourceId);
//             if(targetNode){
//                 data.push({
//                     source: sourceNode,
//                     target: targetNode
//                 });
//                 sourceId = targetNode[sourceIndex];
//             } 
//             else break;
//         } 
//         else break;

//         maxLoopItCount++;  //Just in case anything is wrong with the data, we don't endup with a locked loop.
//     }

//     return data;
// }

// /**
//  * structures the provided array data for easy rendering by a graphing ui library.
//  * @param {Array} rData 
//  */
// export function processGraphData(rData) {
//     let data = [];
//     let firstNode = rData.find(t=>t["parent.id"] == null && t["span.id"]);
//     if(firstNode) {
//         data = constructData(rData, firstNode["span.id"], "down");
//     }
//     else {
//         firstNode = rData.find(t=>t["span.id"] == null && t["parent.id"]);
//         if(firstNode){
//             data = constructData(rData, firstNode["parent.id"], "up");
//         }
//         else {
//             firstNode = rData[0];
//             let subData1 = constructData(rData, firstNode["span.id"], "down");
//             let subData2 = constructData(rData, firstNode["parent.id"], "up");
//             data = [...subData1, ...subData2];
//         }
//     }

//     return data;
// }


// /**
//  * structures the provided object of arrays which is generally a map of all transactions in the form
//  * {
//  *   transactionId: Array,
//  *   transactionId: Array,
//  *   transactionId: Array
//  * }
//  * 
//  * It then returns a data structure suitable for rendering by a graphing ui engine
//  * @param {object} transData 
//  */
// export function processAllGraphData(transData) {
//     let data = [];
//     let transactionIds = Object.keys(transData);

//     transactionIds.forEach(transactionId=>{
//         let subData = processGraphData(transData[transactionId]);
//         data = [...data, ...subData];
//     });

//     return data;
// }   


/**
 * 
 * @param {Array} inputData 
 * @param {string} initialTransactionId 
 */
export function constructBacktracePath(inputData, initialTransactionId){
    let links = [], nodes = [], nextLinkSpan;

    function constructBacktrace(transactionId, prevParentId) {
        //0. Get all the spans for this transaction from the input data.
        let transactionSpans = inputData.filter(t=>t["transaction.id"] == transactionId);

        //1. Find the service or initial span of this transaction
        let serviceSpan = transactionSpans.find( t => t["span.id"] == null );
        
        //2. Find other spans participating in this transaction (excluding the service span above)
        let otherSpans = transactionSpans.filter( t => t["span.id"] != null );

        //3. Connect particpating (other) spans to the service span (in 1)
        otherSpans.forEach(span=>{
            links.push({
                target: serviceSpan,
                source: span
                //you might want to differentiate other the transactions from here
            });
            nodes.push(span);
        });
        
        if(serviceSpan["parent.id"]){
            nodes.push({...serviceSpan, isSource:transactionId==initialTransactionId});
            //4. Locate a span in the input data who's span id is the parent id of the service span
            let linkSpan = inputData.find(t=> t["span.id"] == serviceSpan["parent.id"] && t["transaction.id"] !== serviceSpan["transaction.id"]);
            if(linkSpan){
                links.push({
                    target: linkSpan,
                    source: serviceSpan,
                    // isResultLink: true
                });
                nextLinkSpan = linkSpan;
                
                let nextTransactioId = linkSpan["transaction.id"];
                constructBacktrace(nextTransactioId);
            }
        } else {
            nodes.push({...serviceSpan, isTarget:true});
        }
    }

    constructBacktrace(initialTransactionId, null)

    return {links, nodes};
}