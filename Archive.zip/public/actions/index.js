import { genericRequest } from "./__utils__";
import { FETCH_APP_DATA_REQUEST, FETCH_APP_DATA_SUCCESS, FETCH_APP_DATA_FAILURE, APM_INDEX_URL } from "../constants";
import { apiHttpGET } from "../utils/request_helper";
import { formatUrl } from "../utils/misc";
import { apiHttpPOST } from "../../../../my_first_plugin/public/utils/request_helper";

export const fetchAppData = (index, traceId, callback)=>{
    return genericRequest({
        request_action: FETCH_APP_DATA_REQUEST,
        success_action: FETCH_APP_DATA_SUCCESS,
        failure_action: FETCH_APP_DATA_FAILURE,
        callback: callback,
        requestMethod: apiHttpPOST,
        requestBody: {
            "query": {
              "match": {
                "trace.id": traceId
              }
            }
        },
        endpoint: formatUrl(APM_INDEX_URL, null, {index}) //TODO: Include traceid
    });
}