import { formatUrl } from "../utils/misc";
import { tokenConfig } from "../utils/request_helper";


export const createAction = (type, payload)=>{
    return {type, payload}
}

/**
 * Acts as an interface between api calls and redux store. 
 * Here is the structure of the config object passed to the function:
 * {
     request_action,
     success_action,
     failure_action,
     processData,
     callback,
     requestMethod,
     endpoint,
     queryStrings,
     dynamicParams,
     token,
     requestBody,
     requestActionData,
     reAuthIfNecessary
 }
 * @param {object} config 
 */
export function genericRequest(config) {
    function dispatchFailedRequest(dispatch, error) {
        dispatch(typeof config.failure_action == "function" ? config.failure_action(error) : createAction(config.failure_action, error));
        config.callback(false, error);
    }
    return (dispatch, getState) => {
        dispatch(typeof config.request_action == "function" ? config.request_action() : createAction(config.request_action, config.requestActionData));
        let token = getState().auth? getState().auth.token : "";
        config
            .requestMethod(formatUrl(config.endpoint, config.queryStrings, config.dynamicParams), tokenConfig(token), config.requestBody)
            .then(response => {
                if (response.status >= 200 && response.status <= 299) {
                    let data = typeof config.processData === "function" ? config.processData(response.data, dispatch) : response.data;
                    if (typeof response.data.success === "boolean" && !response.data.success) {
                        dispatch(createAction(config.failure_action, data));
                        config.callback(false, response.data.message);
                    } else {
                        dispatch(typeof config.success_action == "function" ? config.success_action(data) : createAction(config.success_action, data));
                        config.callback(true, data);
                    }
                } else if(response.status == 401){
                    window.browserHistory.push(LOGIN_ROUTE);
                    showErrorNotification("Authentication is required to proceed");
                } else {
                    dispatchFailedRequest(dispatch, `Request failed with Status Code ${response.status}`);
                }
            })
            .catch(error => {
                dispatchFailedRequest(
                    dispatch,
                    error.response && error.response.data
                        ? error.response.data.message? error.response.data.message 
                        : error.response.data
                        : error.message
                        ? `${JSON.stringify(error.message, null, 2)}`
                        : error
                        ? `${JSON.stringify(error, null, 2)}`
                        : "Something went wrong"
                );
            });
    };
}