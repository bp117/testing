import React from "react";

export const FlexBlock = ({
    column, 
    justifyCenter, 
    justifyContent, 
    alignCenter, 
    alignItems,
    children,
    matchParent,
    flexOne, flex,
    ...restProps
})=>(
    <div style={{
        display:"flex", 
        flexDirection: column?"column":"row", 
        justifyContent: justifyCenter?"center":justifyContent,
        alignItems:alignCenter?"center":alignItems,
        flex: flexOne? 1 : flex,
        ...(matchParent?{width:"100%", height:"100%"}:{})
    }} 
    {...restProps}>
        {children}
    </div>
)

export const Block = ({
    children,
    flexOne,
    flex,
    matchParent,
    ...restProps
}) => (
    <div style={{
        display:"block", 
        flex:flexOne?1:flex,
        ...(matchParent?{width:"100%", height:"100%"}:{})
    }} 
    {...restProps}>
        {children}
    </div>
)