import svgPanZoom from "svg-pan-zoom";
import * as d3 from "d3";
import dagreD3 from "dagre-d3";

function getSpanId(span){
    return span["span.id"]+span["span.name"]+span["transaction.id"];
}

/**
 * Renders the Directed Acyclic Graph for the experiment.
 */
export default class D3GraphManager {
    constructor(anchorNode, dataNodes, depNodes, state) {
        this.anchorNode = anchorNode;
        this.dataNodes = dataNodes;
        this.depNodes = depNodes;
        this.state = state;
        this.svgId = "svg_" + ("" + Math.random()).slice(2);
        this.isRunning = false;
    }

    /**
     * Generates a visual representation of a node (component including it's selected hosts)
     */
    getSVGNodeView = item => {
        let nodeContainer = document.createElementNS("http://www.w3.org/2000/svg", "g");

        let compNameNode = document.createElementNS("http://www.w3.org/2000/svg", "text");
        
        compNameNode.setAttribute("x", 15);
        compNameNode.setAttribute("y", 15);
        compNameNode.style = "fill:#0d47a1; font-size:14px; font-weight:bold;";
        let name = item["span.name"]? item["span.name"] : item["service.name"];
        compNameNode.textContent = name+ "\u2003".repeat(2);


        let transIdNode = document.createElementNS("http://www.w3.org/2000/svg", "text");
        transIdNode.setAttribute("x", 15);
        transIdNode.setAttribute("y", 40);
        transIdNode.style = "fill:#0d47a1; font-size:14px;";
        transIdNode.textContent = "transId: " + item["transaction.id"]+ "\u2003".repeat(2);


        let spanIdNode = document.createElementNS("http://www.w3.org/2000/svg", "text");
        spanIdNode.setAttribute("x", 15);
        spanIdNode.setAttribute("y", 55);
        spanIdNode.style = "fill:#0d47a1; font-size:14px;";
        spanIdNode.textContent = "spanId: " + item["span.id"]+ "\u2003".repeat(2);

        
        //  + "\n" + item["span.id"] + "\u2003".repeat(3);

        nodeContainer.append(compNameNode, transIdNode, spanIdNode);

        return nodeContainer;
    };

    /**
     * Manages the creation of a new Dagre-D3 instance, nodes and edges.
     */
    processDagre = () => {
        this.dagre = new dagreD3.graphlib.Graph({ compound: true })
            .setGraph({ rankdir: /*this.graphDirection === "column" ? "LR" :*/ "BT", marginy: 80 })
            .setDefaultEdgeLabel(function() {
                return {};
            });

        this.dataNodes.forEach(item => {
            this.dagre.setNode(getSpanId(item), {
                labelType: "svg",
                label: this.getSVGNodeView(item),
                class: item.isSource? "source-node" : item.isTarget? "target-node" : ""
            });
        });
        this.depNodes.forEach(item => {
            this.dagre.setEdge(getSpanId( item.source ), getSpanId( item.target ), { curve: d3.curveBasis, class: item.isResultLink?"result-link":"" /*, class: "animation animation-medium density-high weight-medium" */});
        });
    };

    /**
     * Sets up d3 and renders the configured graph
     */
    drawGraph = () => {
        this.processDagre();
        let render = new dagreD3.render();

        this.svgRoot = d3
            .select(this.anchorNode)
            .append("svg")
            .attr("width", "100%")
            .attr("height", "100%")
            .attr("id", this.svgId);

        let svgContainer = this.svgRoot
            .append("g")
            .attr("class", "main_graph")
            .attr("width", "100%")
            .attr("height", "100%");

        render(d3.select(`svg#${this.svgId}`).select("g.main_graph"), this.dagre);

        this.panZoomTrigger = svgPanZoom("#" + this.svgId, { controlIconsEnabled: true, maxZoom: 5 });
        this.panZoomTrigger.center().zoom(0.85);
        
        document.querySelectorAll("g.node rect.label-container").forEach(item => {
            item.setAttribute("rx", "5");
            item.setAttribute("ry", "5");
        });
    };
}
