import React from 'react';
import ReactDOM from "react-dom";
import { Block, FlexBlock } from '../utils';
import {
    EuiButton,
    EuiFieldSearch,
    EuiSelectableList
} from '@elastic/eui';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import * as actions from "../../actions/index";
import { constructBacktracePath } from '../../actions/dataCrunch';
import D3GraphManager from "./graphManager";


function mapStateToProps(state){
    return {
        rawData: state.app_data.data
    }
}

function mapDispatchToProps(dispatch){
    return bindActionCreators(actions, dispatch)
}

class MainContent extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            index: "",
            traceId: "",
            ...this._processData(props.rawData)
        };
        this.backtraceViewRef = React.createRef();
    }

    handleFetchData = ()=>{
        const {index, traceId} = this.state;
        this.props.fetchAppData(index, traceId, (success, err)=>{
            if(!success){
                console.error("error ", err);
            }
        });
    }
    _processData = (data)=>{
        let transactions = [], absData=[], _temp=[];
        if(data.hits){
            absData = data.hits.hits.map(t=>({...t._source}));
            absData.forEach(d=>{
                if(!_temp.includes(d["transaction.id"])){
                    _temp.push(d["transaction.id"]);
                    transactions.push({name: d["service.name"], id:d["transaction.id"]});
                }
            });
        }
        return {transactions, data: absData};
    }
    _getListBindData = (processedData={})=>{
        return Object.keys(processedData).map(key=>({
            label: key
        }));
    }
    handleTransactionItemSelected = (item)=>{
        let transactionId = item.id;
        let solutionPath = constructBacktracePath(this.state.data, transactionId);
        let {nodes, links} = solutionPath;
        console.log("SOLUTION PATH ", solutionPath);
        let mountNode = ReactDOM.findDOMNode(this.backtraceViewRef.current)
        mountNode.innerHTML = ""
        let dagreManager = new D3GraphManager(mountNode, nodes, links)
        dagreManager.drawGraph();
    }
    componentWillReceiveProps(props){
        console.log("DATA ", this._processData(props.rawData))
        this.setState({
            ...this._processData(props.rawData)
        });
    }
    render() {
        return (
            <FlexBlock matchParent column>
                <Block>
                    <FlexBlock alignCenter>
                        <div style={{marginRight:20, flex:1, maxWidth:400}}>
                            <EuiFieldSearch 
                                placeholder="Enter Index" 
                                // defaultValue="backtrace"  //TODO: REMOVE THIS
                                onChange={(e)=>{
                                    this.setState({index:e.target.value})
                                }}/>
                        </div>
                        <div style={{marginRight:20, flex:1, maxWidth:400}}>
                            <EuiFieldSearch 
                                placeholder="Enter TraceId"
                                // defaultValue="2d416232af1878c44a79f06116553da9" //TODO: REMOVE THIS
                                onChange={(e)=>{
                                    this.setState({traceId: e.target.value})
                                }}/>
                        </div>
                        <EuiButton onClick={this.handleFetchData}> Search </EuiButton>
                    </FlexBlock>
                    <hr className="hr-divider"/>
                </Block>
                {this.state.transactions.length?
                    <FlexBlock flexOne>
                        <EuiSelectableList 
                            options={this.state.transactions.map(t=>({label:t.name, id:t.id}))} 
                            style={{minWidth:300}}
                            onOptionClick={(e)=>{
                                this.handleTransactionItemSelected(e.find(t=>t.checked=="on"))
                            }}
                        />
                        <Block flexOne matchParent>
                            <div style={{width:"100%", height:"100%"}} ref={this.backtraceViewRef}>
                            </div>
                        </Block>
                    </FlexBlock>
                    :
                    <Block style={{height:300}}>
                        <FlexBlock alignCenter justifyCenter matchParent>
                            <h3>Nothing to process!</h3>
                        </FlexBlock>
                    </Block>
                }
            </FlexBlock>
        )
    }
}

export default connect(mapStateToProps, mapDispatchToProps)( MainContent )