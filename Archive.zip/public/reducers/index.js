import { combineReducers } from 'redux';
import app_data from "./app_data";

const rootReducer = combineReducers({
    app_data
});

export default rootReducer;