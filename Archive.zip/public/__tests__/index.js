import expect from '@kbn/expect';

describe('suite', () => {
  it('is a test', () => {
    expect(true).to.equal(true);
  });
});
