import React from 'react';
import { uiModules } from 'ui/modules';
import chrome from 'ui/chrome';
import { render, unmountComponentAtNode } from 'react-dom';

import { Main } from './components/main';
import createAppStore from './store/store_config';
import { initStoreProvider } from './store/store_provider';
import { Provider } from 'react-redux';

const app = uiModules.get('apps/backtracer');

const store = createAppStore({});
initStoreProvider(store);

app.config($locationProvider => {
  $locationProvider.html5Mode({
    enabled: false,
    requireBase: false,
    rewriteLinks: false,
  });
});
app.config(stateManagementConfigProvider => stateManagementConfigProvider.disable());

function RootController($scope, $element, $http) {
  const domNode = $element[0];

  // render react to DOM
  render(
    <Provider store={store}>
      <Main title="Backtracer" httpClient={$http} />
    </Provider>
    , 
    domNode);

  // unmount react on controller destroy
  $scope.$on('$destroy', () => {
    unmountComponentAtNode(domNode);
  });
}

chrome.setRootController('backtracer', RootController);
