let appStore = null;

export function initStoreProvider(store){
    appStore = store;
}

export function getAppStore(){
    return appStore;
}